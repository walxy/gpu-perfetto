# Third-party licenses

The v0.1.0 baseline does not vendor third-party runtime libraries.

Optional backend dependencies must retain their upstream license terms and should be discovered from installed SDKs rather than copied into the core library.


## Optional Perfetto SDK backend

The native Perfetto backend can be built from the external Perfetto amalgamated SDK. Perfetto source is licensed under Apache License 2.0. The SDK is not copied into the gpu-perfetto source tree; distributors of binaries containing the SDK should retain the applicable upstream license and notice terms.
