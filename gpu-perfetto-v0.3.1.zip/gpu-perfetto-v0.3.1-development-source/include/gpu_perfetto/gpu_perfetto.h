#ifndef GPU_PERFETTO_H
#define GPU_PERFETTO_H

#include "gpu_perfetto/status.h"
#include "gpu_perfetto/timestamp.h"
#include "gpu_perfetto/clock.h"
#include "gpu_perfetto/capabilities.h"
#include "gpu_perfetto/counter.h"
#include "gpu_perfetto/identity.h"
#include "gpu_perfetto/trace.h"
#include "gpu_perfetto/perfetto_json.h"
#include "gpu_perfetto/perfetto_sdk.h"

#define GPU_PERFETTO_VERSION_MAJOR 0
#define GPU_PERFETTO_VERSION_MINOR 3
#define GPU_PERFETTO_VERSION_PATCH 1

#endif
