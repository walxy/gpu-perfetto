#ifndef GPU_PERFETTO_PERFETTO_SDK_H
#define GPU_PERFETTO_PERFETTO_SDK_H

#include <stdint.h>

#include "gpu_perfetto/status.h"
#include "gpu_perfetto/trace.h"

#ifdef __cplusplus
extern "C" {
#endif

/*
 * Native Perfetto C++ SDK integration.
 *
 * The application owns Perfetto tracing initialization and trace-session
 * lifecycle. gpu-perfetto only registers TrackEvent and emits the semantic
 * events supplied through the generic sink interface.
 */
typedef struct gpu_trace_perfetto_sdk_sink {
    uint32_t size;
    uint32_t version;
    uint32_t initialized;
    uint32_t reserved0;
    gpu_trace_sink_t interface;
} gpu_trace_perfetto_sdk_sink_t;

/* Register the gpu-perfetto TrackEvent category with an already-initialized
 * Perfetto SDK. Safe to call more than once. */
gpu_trace_status_t gpu_trace_perfetto_sdk_register(void);

/* Initialize a native Perfetto sink. This does not initialize, start, stop, or
 * own a Perfetto tracing session. */
gpu_trace_status_t gpu_trace_perfetto_sdk_sink_init(
    gpu_trace_perfetto_sdk_sink_t *sink);

/* Return the generic sink interface used with gpu_trace_set_sink(). */
const gpu_trace_sink_t *gpu_trace_perfetto_sdk_sink_get_sink(
    const gpu_trace_perfetto_sdk_sink_t *sink);

/* Flush the native TrackEvent producer buffers. This does not stop tracing. */
gpu_trace_status_t gpu_trace_perfetto_sdk_flush(void);

#ifdef __cplusplus
}
#endif

#endif
