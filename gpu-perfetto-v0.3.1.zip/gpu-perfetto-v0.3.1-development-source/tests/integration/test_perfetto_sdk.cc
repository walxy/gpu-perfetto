#include <cstdint>

#include "gpu_perfetto/perfetto_sdk.h"
#include "perfetto.h"

#define CHECK(expr)            \
    do {                       \
        if (!(expr)) return 1; \
    } while (0)

int main() {
    perfetto::TracingInitArgs args;
    args.backends = perfetto::kInProcessBackend;
    perfetto::Tracing::Initialize(args);

    gpu_trace_perfetto_sdk_sink_t sink{};
    CHECK(gpu_trace_perfetto_sdk_sink_init(&sink) == GPU_TRACE_OK);
    CHECK(gpu_trace_perfetto_sdk_sink_get_sink(&sink) == nullptr);
    CHECK(gpu_trace_perfetto_sdk_register() == GPU_TRACE_OK);
    CHECK(gpu_trace_perfetto_sdk_register() == GPU_TRACE_OK);
    const gpu_trace_sink_t *generic =
        gpu_trace_perfetto_sdk_sink_get_sink(&sink);
    CHECK(generic != nullptr);

    gpu_trace_event_desc_t unsupported{};
    unsupported.size = static_cast<uint32_t>(sizeof(unsupported));
    unsupported.version = 1U;
    unsupported.type = GPU_TRACE_EVENT_INSTANT;
    unsupported.name = "raw-gpu-clock";
    unsupported.begin.value = 1000U;
    unsupported.begin.domain = GPU_TRACE_CLOCK_GPU;
    CHECK(generic->emit(generic->user_data, &unsupported) ==
          GPU_TRACE_ERROR_UNSUPPORTED);

    gpu_trace_event_desc_t too_large = unsupported;
    too_large.begin.domain = GPU_TRACE_CLOCK_CALIBRATED;
    too_large.value = UINT64_MAX;
    too_large.name = "counter-overflow";
    too_large.type = GPU_TRACE_EVENT_COUNTER;
    CHECK(generic->emit(generic->user_data, &too_large) ==
          GPU_TRACE_ERROR_UNSUPPORTED);

    gpu_trace_config_t config{};
    config.size = static_cast<uint32_t>(sizeof(config));
    config.version = 1U;
    config.enabled = 1U;
    config.capacity = 8U;

    gpu_trace_session_t *session = nullptr;
    CHECK(gpu_trace_create(&config, &session) == GPU_TRACE_OK);
    CHECK(gpu_trace_set_sink(session, generic) == GPU_TRACE_OK);
    CHECK(gpu_trace_start(session) == GPU_TRACE_OK);

    gpu_trace_event_desc_t event{};
    event.size = static_cast<uint32_t>(sizeof(event));
    event.version = 1U;
    event.type = GPU_TRACE_EVENT_EXECUTION;
    event.name = "matmul";
    event.event_id = 1U;
    event.correlation_id = 77U;
    event.device_id = 2U;
    event.queue_id = 5U;
    event.source = GPU_TRACE_SOURCE_USER;
    event.correlation_domain = GPU_TRACE_CORRELATION_LOCAL;
    event.begin.value = 1000U;
    event.begin.domain = GPU_TRACE_CLOCK_CALIBRATED;
    event.end.value = 2000U;
    event.end.domain = GPU_TRACE_CLOCK_CALIBRATED;

    CHECK(gpu_trace_record(session, &event) == GPU_TRACE_OK);
    CHECK(gpu_trace_flush(session) == GPU_TRACE_OK);
    CHECK(gpu_trace_perfetto_sdk_flush() == GPU_TRACE_OK);
    CHECK(gpu_trace_stop(session) == GPU_TRACE_OK);
    CHECK(gpu_trace_destroy(session) == GPU_TRACE_OK);
    return 0;
}
