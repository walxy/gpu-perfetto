# Native Perfetto SDK backend

The optional native backend emits gpu-perfetto semantic events through Perfetto's TrackEvent C++ SDK.

## Dependency model

The core library has no Perfetto dependency. The native backend is enabled separately with:

```bash
cmake -S . -B build \
  -DGPU_PERFETTO_BUILD_PERFETTO=ON \
  -DGPU_PERFETTO_PERFETTO_SDK_DIR=/path/to/perfetto/sdk
cmake --build build
```

The SDK directory must contain the amalgamated `perfetto.h` and `perfetto.cc` supplied by Perfetto.

The application owns Perfetto tracing initialization and session lifecycle. This backend does not silently choose in-process or system tracing, and it does not start or stop a trace session.

## Initialization

Initialize Perfetto and register TrackEvent in the application:

```cpp
perfetto::TracingInitArgs args;
args.backends = perfetto::kInProcessBackend;
perfetto::Tracing::Initialize(args);

GPU_TRACE_CHECK(gpu_trace_perfetto_sdk_register());
```

The current Perfetto SDK example similarly initializes `Tracing`, registers `TrackEvent`, creates a trace session, and controls start/stop separately. See the upstream SDK example.

## Lifecycle

Construct the sink first if convenient; construction does not require Perfetto to have been initialized. Call `gpu_trace_perfetto_sdk_register()` only after `perfetto::Tracing::Initialize()`. The generic sink becomes available through `gpu_trace_perfetto_sdk_sink_get_sink()` after registration.

## Timestamp contract

The native sink accepts only `GPU_TRACE_CLOCK_CALIBRATED` events. Those timestamps must already be expressed in Perfetto's active trace clock.

Raw GPU timestamps and uncalibrated host-monotonic timestamps are rejected. This prevents a trace that looks visually correct while having an invalid timebase.

## Track mapping

- Host semantic events with a supplied `thread_id` use the corresponding Perfetto `ThreadTrack`.
- GPU work with `queue_id` uses a process-scoped named `gpu.queue` track.
- Device-only GPU work uses a process-scoped `gpu.device` track.
- Events without an identity fall back to the process track.

Because Perfetto slice tracks represent nested slices on a monotonically increasing timeline, the producer must deliver events in timestamp order for each mapped track. Backend adapters must preserve or establish that ordering before recording. The current generic sink does not sort or allocate a second reorder buffer.

## Event mapping

| gpu-perfetto | Perfetto TrackEvent |
|---|---|
| scope | slice begin/end |
| submission | slice begin/end |
| execution | slice begin/end |
| memory | slice begin/end |
| instant | instant |
| sync | instant |
| metadata | instant |
| counter | CounterTrack / counter |

Correlation IDs are emitted using TrackEvent's native correlation field. Additional gpu-perfetto identity and provenance values are preserved as debug annotations.

## Important limitation

This backend intentionally does not synthesize Perfetto GPU protobuf `GpuRenderStageEvent` packets or `GpuCorrelation` packets. Those richer structures require backend/native GPU observations and will be added at the CUDA/ROCm/Level Zero integration stage where their semantics can be populated correctly.
