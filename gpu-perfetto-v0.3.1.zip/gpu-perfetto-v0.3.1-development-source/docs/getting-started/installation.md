# Installation

## From source

```bash
cmake -S . -B build -DGPU_PERFETTO_BUILD_TESTS=ON
cmake --build build
ctest --test-dir build --output-on-failure
```

The core currently has no third-party runtime dependency.

Vendor SDKs are intentionally optional and are not bundled.

## Perfetto-compatible JSON output

Build the optional JSON sink (enabled by default):

```bash
cmake -S . -B build -DGPU_PERFETTO_BUILD_PERFETTO_JSON=ON
cmake --build build
```

The sink emits Chrome Trace JSON, which Perfetto can open directly. Native `.pftrace`/protobuf emission through the Perfetto SDK is intentionally not vendored into this release. Perfetto currently documents Chrome JSON as a supported external format and its native SDK as a C++17 amalgamation. citeturn131444search0turn269560view1


## Native Perfetto SDK backend

The native backend is optional and uses the external Perfetto amalgamated SDK. Supply the directory containing `perfetto.h` and `perfetto.cc`:

```bash
cmake -S . -B build \
  -DGPU_PERFETTO_BUILD_PERFETTO=ON \
  -DGPU_PERFETTO_PERFETTO_SDK_DIR=/path/to/perfetto/sdk
cmake --build build
```

The application must initialize Perfetto first, then call `gpu_trace_perfetto_sdk_register()`. The gpu-perfetto sink does not select tracing backend mode or own trace-session start/stop.
