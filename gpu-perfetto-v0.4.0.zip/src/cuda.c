#if !defined(_WIN32) && !defined(__APPLE__) && !defined(_POSIX_C_SOURCE)
#define _POSIX_C_SOURCE 200809L
#endif

#include "gpu_perfetto/cuda.h"

#include <stdatomic.h>
#include <stddef.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#if defined(_WIN32)
#include <windows.h>
#elif defined(__APPLE__)
#include <mach/mach_time.h>
#include <mach/kern_return.h>
#endif

#include <cupti.h>
#include <cupti_activity.h>
#include <cupti_callbacks.h>

#define GPU_TRACE_CUDA_DEFAULT_BUFFER_SIZE (64U * 1024U)
#define GPU_TRACE_CUDA_VERSION 1U
#define GPU_TRACE_CUDA_STATE_CREATED 0U
#define GPU_TRACE_CUDA_STATE_RUNNING 1U
#define GPU_TRACE_CUDA_STATE_STOPPED 2U

struct gpu_trace_cuda {
    gpu_trace_session_t *session;
    uint32_t buffer_size_bytes;
    uint32_t enable_runtime_api;
    uint32_t enable_driver_api;
    uint32_t enable_kernel;
    uint32_t enable_memcpy;
    uint32_t enable_memset;
    uint32_t enable_synchronization;
    _Atomic uint64_t next_event_id;
    _Atomic uint32_t state;
    _Atomic uint64_t cupti_dropped_count;
    _Atomic uint64_t translation_error_count;
    gpu_trace_clock_mapping_t clock_mapping;
    gpu_trace_cuda_clock_now_fn clock_now;
    void *clock_user_data;
    _Atomic uint32_t clock_mapping_valid;
};

static _Atomic(gpu_trace_cuda_t *) g_active_cuda = ATOMIC_VAR_INIT(NULL);

static gpu_trace_status_t map_cupti(CUptiResult result) {
    if (result == CUPTI_SUCCESS) {
        return GPU_TRACE_OK;
    }
    if (result == CUPTI_ERROR_MAX_LIMIT_REACHED) {
        return GPU_TRACE_ERROR_BUFFER_FULL;
    }
    if (result == CUPTI_ERROR_NOT_SUPPORTED) {
        return GPU_TRACE_ERROR_UNSUPPORTED;
    }
    return GPU_TRACE_ERROR_INTERNAL;
}

static uint64_t host_monotonic_ns(void) {
#if defined(_WIN32)
    LARGE_INTEGER frequency;
    LARGE_INTEGER counter;
    if (!QueryPerformanceFrequency(&frequency) ||
        !QueryPerformanceCounter(&counter) ||
        frequency.QuadPart <= 0) {
        return 0U;
    }
    return (uint64_t)((counter.QuadPart * UINT64_C(1000000000)) /
                      frequency.QuadPart);
#elif defined(__APPLE__)
    static mach_timebase_info_data_t timebase;
    uint64_t ticks;
    if (timebase.denom == 0U &&
        mach_timebase_info(&timebase) != KERN_SUCCESS) {
        return 0U;
    }
    ticks = mach_absolute_time();
    return (uint64_t)((ticks * (uint64_t)timebase.numer) /
                      (uint64_t)timebase.denom);
#else
    struct timespec ts;
    if (clock_gettime(CLOCK_MONOTONIC, &ts) != 0) {
        return 0U;
    }
    return (uint64_t)ts.tv_sec * UINT64_C(1000000000) + (uint64_t)ts.tv_nsec;
#endif
}

static gpu_trace_status_t calibrate_clock(gpu_trace_cuda_t *cuda) {
    uint64_t gpu_before = 0U;
    uint64_t gpu_after = 0U;
    uint64_t target_before = 0U;
    uint64_t target_after = 0U;
    gpu_trace_clock_domain_t target_domain = GPU_TRACE_CLOCK_UNKNOWN;
    gpu_trace_clock_domain_t target_domain_after = GPU_TRACE_CLOCK_UNKNOWN;
    gpu_trace_clock_mapping_t mapping;
    gpu_trace_status_t target_status;
    CUptiResult result;

    if (cuda == NULL) {
        return GPU_TRACE_ERROR_INVALID_ARGUMENT;
    }

    if (cuda->clock_now != NULL) {
        target_status = cuda->clock_now(cuda->clock_user_data, &target_before,
                                        &target_domain);
        if (target_status != GPU_TRACE_OK) {
            return target_status;
        }
        if (target_domain == GPU_TRACE_CLOCK_GPU ||
            target_domain == GPU_TRACE_CLOCK_UNKNOWN) {
            return GPU_TRACE_ERROR_INVALID_ARGUMENT;
        }
    } else {
        target_domain = GPU_TRACE_CLOCK_HOST_MONOTONIC;
        target_before = host_monotonic_ns();
        if (target_before == 0U) {
            return GPU_TRACE_ERROR_UNSUPPORTED;
        }
    }

    result = cuptiGetTimestamp(&gpu_before);
    if (result != CUPTI_SUCCESS) {
        return map_cupti(result);
    }
    result = cuptiGetTimestamp(&gpu_after);
    if (result != CUPTI_SUCCESS) {
        return map_cupti(result);
    }

    if (cuda->clock_now != NULL) {
        target_status = cuda->clock_now(cuda->clock_user_data, &target_after,
                                        &target_domain_after);
        if (target_status == GPU_TRACE_OK && target_domain_after != target_domain) {
            return GPU_TRACE_ERROR_UNSUPPORTED;
        }
        if (target_status != GPU_TRACE_OK) {
            return target_status;
        }
    } else {
        target_after = host_monotonic_ns();
        if (target_after == 0U) {
            return GPU_TRACE_ERROR_UNSUPPORTED;
        }
    }

    if (gpu_after < gpu_before || target_after < target_before ||
        gpu_after == gpu_before) {
        return GPU_TRACE_ERROR_UNSUPPORTED;
    }

    memset(&mapping, 0, sizeof(mapping));
    mapping.size = (uint32_t)sizeof(mapping);
    mapping.version = 1U;
    mapping.source_domain = GPU_TRACE_CLOCK_GPU;
    mapping.destination_domain = target_domain;
    mapping.source_origin = gpu_before;
    mapping.destination_origin = target_before;
    mapping.numerator = target_after - target_before;
    mapping.denominator = gpu_after - gpu_before;
    mapping.uncertainty_ns = (uint32_t)((target_after - target_before) > UINT32_MAX
                                            ? UINT32_MAX
                                            : (target_after - target_before));
    if (gpu_trace_clock_mapping_validate(&mapping) != GPU_TRACE_OK) {
        return GPU_TRACE_ERROR_UNSUPPORTED;
    }

    cuda->clock_mapping = mapping;
    atomic_store_explicit(&cuda->clock_mapping_valid, 1U, memory_order_release);
    return GPU_TRACE_OK;
}

static gpu_trace_status_t convert_timestamp(
    const gpu_trace_cuda_t *cuda,
    uint64_t value,
    gpu_trace_timestamp_t *out) {
    gpu_trace_timestamp_t source;
    gpu_trace_status_t status;

    if (cuda == NULL || out == NULL) {
        return GPU_TRACE_ERROR_INVALID_ARGUMENT;
    }
    if (!atomic_load_explicit(&cuda->clock_mapping_valid, memory_order_acquire)) {
        return GPU_TRACE_ERROR_UNSUPPORTED;
    }
    memset(&source, 0, sizeof(source));
    source.value = value;
    source.domain = GPU_TRACE_CLOCK_GPU;
    source.resolution_ns = 1U;
    status = gpu_trace_clock_convert(&cuda->clock_mapping, &source, out);
    if (status == GPU_TRACE_OK) {
        out->domain = cuda->clock_mapping.destination_domain;
    }
    return status;
}

static const char *memcpy_name(uint8_t copy_kind) {
    switch ((CUpti_ActivityMemcpyKind)copy_kind) {
        case CUPTI_ACTIVITY_MEMCPY_KIND_HTOD: return "memcpy HtoD";
        case CUPTI_ACTIVITY_MEMCPY_KIND_DTOH: return "memcpy DtoH";
        case CUPTI_ACTIVITY_MEMCPY_KIND_DTOD: return "memcpy DtoD";
        case CUPTI_ACTIVITY_MEMCPY_KIND_HTOH: return "memcpy HtoH";
        case CUPTI_ACTIVITY_MEMCPY_KIND_HTOA: return "memcpy HtoA";
        case CUPTI_ACTIVITY_MEMCPY_KIND_ATOH: return "memcpy AtoH";
        case CUPTI_ACTIVITY_MEMCPY_KIND_ATOD: return "memcpy AtoD";
        case CUPTI_ACTIVITY_MEMCPY_KIND_DTOA: return "memcpy DtoA";
        case CUPTI_ACTIVITY_MEMCPY_KIND_ATOA: return "memcpy AtoA";
        case CUPTI_ACTIVITY_MEMCPY_KIND_PTOP: return "memcpy PtoP";
        default: return "memcpy";
    }
}

static const char *sync_name(CUpti_ActivitySynchronizationType type) {
    switch (type) {
        case CUPTI_ACTIVITY_SYNCHRONIZATION_TYPE_CONTEXT_SYNCHRONIZE:
            return "context synchronize";
        case CUPTI_ACTIVITY_SYNCHRONIZATION_TYPE_STREAM_SYNCHRONIZE:
            return "stream synchronize";
        case CUPTI_ACTIVITY_SYNCHRONIZATION_TYPE_EVENT_SYNCHRONIZE:
            return "event synchronize";
        case CUPTI_ACTIVITY_SYNCHRONIZATION_TYPE_STREAM_WAIT_EVENT:
            return "stream wait event";
        default:
            return "synchronize";
    }
}

static void base_event(gpu_trace_cuda_t *cuda,
                       gpu_trace_event_desc_t *event) {
    memset(event, 0, sizeof(*event));
    event->size = (uint32_t)sizeof(*event);
    event->version = 1U;
    event->source = GPU_TRACE_SOURCE_CUPTI;
    event->correlation_domain = GPU_TRACE_CORRELATION_CUDA;
    event->event_id = atomic_fetch_add_explicit(&cuda->next_event_id, 1U, memory_order_relaxed) + 1U;
}

static gpu_trace_status_t emit_api(gpu_trace_cuda_t *cuda,
                                   const CUpti_ActivityAPI *api) {
    gpu_trace_event_desc_t event;
    gpu_trace_status_t status;

    if (api == NULL || api->start == 0U || api->end == 0U) {
        return GPU_TRACE_ERROR_UNSUPPORTED;
    }
    base_event(cuda, &event);
    event.type = GPU_TRACE_EVENT_SCOPE;
    {
        const char *callback_name = NULL;
        CUpti_CallbackDomain domain =
            api->kind == CUPTI_ACTIVITY_KIND_DRIVER
                ? CUPTI_CB_DOMAIN_DRIVER_API
                : CUPTI_CB_DOMAIN_RUNTIME_API;
        if (cuptiGetCallbackName(domain, api->cbid, &callback_name) == CUPTI_SUCCESS &&
            callback_name != NULL) {
            event.name = callback_name;
        } else {
            event.name = api->kind == CUPTI_ACTIVITY_KIND_DRIVER
                ? "cuda_driver_api"
                : "cuda_runtime_api";
        }
    }
    event.correlation_id = (uint64_t)api->correlationId;
    event.thread_id = api->threadId;
    event.flags = GPU_TRACE_FLAG_HAS_THREAD_ID;
    status = convert_timestamp(cuda, api->start, &event.begin);
    if (status != GPU_TRACE_OK) return status;
    status = convert_timestamp(cuda, api->end, &event.end);
    if (status != GPU_TRACE_OK) return status;
    event.flags |= GPU_TRACE_FLAG_HAS_BEGIN | GPU_TRACE_FLAG_HAS_END;
    return gpu_trace_record(cuda->session, &event);
}

static gpu_trace_status_t emit_kernel(gpu_trace_cuda_t *cuda,
                                      const CUpti_ActivityKernel12 *kernel) {
    gpu_trace_event_desc_t event;
    gpu_trace_status_t status;

    if (kernel == NULL || kernel->start == 0U || kernel->end == 0U) {
        return GPU_TRACE_ERROR_UNSUPPORTED;
    }
    base_event(cuda, &event);
    event.type = GPU_TRACE_EVENT_EXECUTION;
    event.name = kernel->name != NULL ? kernel->name : "cuda_kernel";
    event.correlation_id = (uint64_t)kernel->correlationId;
    event.device_id = kernel->deviceId;
    event.context_id = kernel->contextId;
    event.queue_id = kernel->streamId;
    event.graph_id = kernel->graphId;
    event.graph_node_id = kernel->graphNodeId;
    status = convert_timestamp(cuda, kernel->start, &event.begin);
    if (status != GPU_TRACE_OK) return status;
    status = convert_timestamp(cuda, kernel->end, &event.end);
    if (status != GPU_TRACE_OK) return status;
    event.flags = GPU_TRACE_FLAG_HAS_BEGIN | GPU_TRACE_FLAG_HAS_END |
                  GPU_TRACE_FLAG_ASYNC | GPU_TRACE_FLAG_HAS_DEVICE_ID |
                  GPU_TRACE_FLAG_HAS_QUEUE_ID | GPU_TRACE_FLAG_HAS_CONTEXT_ID;
    if (kernel->graphId != 0U || kernel->graphNodeId != 0U) {
        event.flags |= GPU_TRACE_FLAG_HAS_GRAPH_ID | GPU_TRACE_FLAG_HAS_GRAPH_NODE_ID;
    }
    return gpu_trace_record(cuda->session, &event);
}

static gpu_trace_status_t emit_memcpy(gpu_trace_cuda_t *cuda,
                                      const CUpti_ActivityMemcpy6 *record) {
    gpu_trace_event_desc_t event;
    gpu_trace_status_t status;

    if (record == NULL || record->start == 0U || record->end == 0U) {
        return GPU_TRACE_ERROR_UNSUPPORTED;
    }
    base_event(cuda, &event);
    event.type = GPU_TRACE_EVENT_MEMORY;
    event.name = memcpy_name(record->copyKind);
    event.correlation_id = (uint64_t)record->correlationId;
    event.device_id = record->deviceId;
    event.context_id = record->contextId;
    event.queue_id = record->streamId;
    event.graph_id = record->graphId;
    event.graph_node_id = record->graphNodeId;
    event.value = record->bytes;
    event.counter_unit = GPU_TRACE_COUNTER_UNIT_BYTES;
    status = convert_timestamp(cuda, record->start, &event.begin);
    if (status != GPU_TRACE_OK) return status;
    status = convert_timestamp(cuda, record->end, &event.end);
    if (status != GPU_TRACE_OK) return status;
    event.flags = GPU_TRACE_FLAG_HAS_BEGIN | GPU_TRACE_FLAG_HAS_END |
                  GPU_TRACE_FLAG_ASYNC | GPU_TRACE_FLAG_HAS_DEVICE_ID |
                  GPU_TRACE_FLAG_HAS_QUEUE_ID | GPU_TRACE_FLAG_HAS_CONTEXT_ID;
    if (record->graphId != 0U || record->graphNodeId != 0U) {
        event.flags |= GPU_TRACE_FLAG_HAS_GRAPH_ID | GPU_TRACE_FLAG_HAS_GRAPH_NODE_ID;
    }
    return gpu_trace_record(cuda->session, &event);
}

static gpu_trace_status_t emit_memset(gpu_trace_cuda_t *cuda,
                                      const CUpti_ActivityMemset4 *record) {
    gpu_trace_event_desc_t event;
    gpu_trace_status_t status;

    if (record == NULL || record->start == 0U || record->end == 0U) {
        return GPU_TRACE_ERROR_UNSUPPORTED;
    }
    base_event(cuda, &event);
    event.type = GPU_TRACE_EVENT_MEMORY;
    event.name = "memset";
    event.correlation_id = (uint64_t)record->correlationId;
    event.device_id = record->deviceId;
    event.context_id = record->contextId;
    event.queue_id = record->streamId;
    event.graph_id = record->graphId;
    event.graph_node_id = record->graphNodeId;
    event.value = record->bytes;
    event.counter_unit = GPU_TRACE_COUNTER_UNIT_BYTES;
    status = convert_timestamp(cuda, record->start, &event.begin);
    if (status != GPU_TRACE_OK) return status;
    status = convert_timestamp(cuda, record->end, &event.end);
    if (status != GPU_TRACE_OK) return status;
    event.flags = GPU_TRACE_FLAG_HAS_BEGIN | GPU_TRACE_FLAG_HAS_END |
                  GPU_TRACE_FLAG_ASYNC | GPU_TRACE_FLAG_HAS_DEVICE_ID |
                  GPU_TRACE_FLAG_HAS_QUEUE_ID | GPU_TRACE_FLAG_HAS_CONTEXT_ID;
    if (record->graphId != 0U || record->graphNodeId != 0U) {
        event.flags |= GPU_TRACE_FLAG_HAS_GRAPH_ID | GPU_TRACE_FLAG_HAS_GRAPH_NODE_ID;
    }
    return gpu_trace_record(cuda->session, &event);
}

static gpu_trace_status_t emit_sync(gpu_trace_cuda_t *cuda,
                                    const CUpti_ActivitySynchronization2 *record) {
    gpu_trace_event_desc_t event;
    gpu_trace_status_t status;

    if (record == NULL || record->start == 0U) {
        return GPU_TRACE_ERROR_UNSUPPORTED;
    }
    base_event(cuda, &event);
    event.type = GPU_TRACE_EVENT_SYNC;
    event.name = sync_name(record->type);
    event.correlation_id = (uint64_t)record->correlationId;
    event.context_id = record->contextId;
    event.queue_id = record->streamId;
    status = convert_timestamp(cuda, record->start, &event.begin);
    if (status != GPU_TRACE_OK) return status;
    if (record->end != 0U) {
        status = convert_timestamp(cuda, record->end, &event.end);
        if (status != GPU_TRACE_OK) return status;
        event.flags = GPU_TRACE_FLAG_HAS_BEGIN | GPU_TRACE_FLAG_HAS_END |
                      GPU_TRACE_FLAG_HAS_QUEUE_ID | GPU_TRACE_FLAG_HAS_CONTEXT_ID;
    } else {
        event.end = event.begin;
        event.flags = GPU_TRACE_FLAG_HAS_BEGIN |
                      GPU_TRACE_FLAG_HAS_QUEUE_ID | GPU_TRACE_FLAG_HAS_CONTEXT_ID;
    }
    return gpu_trace_record(cuda->session, &event);
}

static gpu_trace_status_t process_record(gpu_trace_cuda_t *cuda,
                                         const CUpti_Activity *record) {
    if (record == NULL) {
        return GPU_TRACE_ERROR_INVALID_ARGUMENT;
    }
    switch (record->kind) {
        case CUPTI_ACTIVITY_KIND_RUNTIME:
            return cuda->enable_runtime_api
                ? emit_api(cuda, (const CUpti_ActivityAPI *)record)
                : GPU_TRACE_OK;
        case CUPTI_ACTIVITY_KIND_DRIVER:
            return cuda->enable_driver_api
                ? emit_api(cuda, (const CUpti_ActivityAPI *)record)
                : GPU_TRACE_OK;
        case CUPTI_ACTIVITY_KIND_KERNEL:
        case CUPTI_ACTIVITY_KIND_CONCURRENT_KERNEL:
            return cuda->enable_kernel
                ? emit_kernel(cuda, (const CUpti_ActivityKernel12 *)record)
                : GPU_TRACE_OK;
        case CUPTI_ACTIVITY_KIND_MEMCPY:
            return cuda->enable_memcpy
                ? emit_memcpy(cuda, (const CUpti_ActivityMemcpy6 *)record)
                : GPU_TRACE_OK;
        case CUPTI_ACTIVITY_KIND_MEMSET:
            return cuda->enable_memset
                ? emit_memset(cuda, (const CUpti_ActivityMemset4 *)record)
                : GPU_TRACE_OK;
        case CUPTI_ACTIVITY_KIND_SYNCHRONIZATION:
            return cuda->enable_synchronization
                ? emit_sync(cuda, (const CUpti_ActivitySynchronization2 *)record)
                : GPU_TRACE_OK;
        default:
            return GPU_TRACE_OK;
    }
}

static void buffer_requested(uint8_t **buffer,
                             size_t *size,
                             size_t *max_num_records) {
    gpu_trace_cuda_t *cuda = atomic_load_explicit(&g_active_cuda,
                                                   memory_order_acquire);
    size_t requested = GPU_TRACE_CUDA_DEFAULT_BUFFER_SIZE;
    if (cuda != NULL && cuda->buffer_size_bytes != 0U) {
        requested = (size_t)cuda->buffer_size_bytes;
    }
    *buffer = (uint8_t *)malloc(requested);
    *size = *buffer != NULL ? requested : 0U;
    *max_num_records = 0U;
}

static void buffer_completed(CUcontext context,
                             uint32_t stream_id,
                             uint8_t *buffer,
                             size_t size) {
    gpu_trace_cuda_t *cuda = atomic_load_explicit(&g_active_cuda,
                                                   memory_order_acquire);
    CUpti_Activity *record = NULL;
    CUptiResult result;
    size_t offset = 0U;
    uint64_t dropped = 0U;

    if (cuda == NULL || buffer == NULL) {
        free(buffer);
        return;
    }

    while (offset < size) {
        result = cuptiActivityGetNextRecord(buffer + offset, size - offset, &record);
        if (result == CUPTI_SUCCESS) {
            {
                gpu_trace_status_t translate_status = process_record(cuda, record);
                if (translate_status != GPU_TRACE_OK &&
                    translate_status != GPU_TRACE_ERROR_BUFFER_FULL) {
                    atomic_fetch_add_explicit(&cuda->translation_error_count, 1U, memory_order_relaxed);
                }
            }
            if (record->size == 0U) {
                break;
            }
            offset += record->size;
            continue;
        }
        if (result == CUPTI_ERROR_MAX_LIMIT_REACHED) {
            break;
        }
        break;
    }

    result = cuptiActivityGetNumDroppedRecords(context, stream_id, &dropped);
    if (result == CUPTI_SUCCESS && dropped != 0U) {
        atomic_fetch_add_explicit(&cuda->cupti_dropped_count, dropped,
                                  memory_order_relaxed);
    }
    free(buffer);
}

static uint32_t cfg_u32(const gpu_trace_cuda_config_t *config,
                        size_t offset,
                        uint32_t fallback) {
    uint32_t value = fallback;
    if (config->size >= (uint32_t)(offset + sizeof(value))) {
        memcpy(&value, (const unsigned char *)config + offset, sizeof(value));
    }
    return value;
}

static int config_valid(const gpu_trace_cuda_config_t *config) {
    return config != NULL &&
           config->size >= (uint32_t)offsetof(gpu_trace_cuda_config_t,
                                             buffer_size_bytes) &&
           config->version == GPU_TRACE_CUDA_VERSION;
}

gpu_trace_status_t gpu_trace_cuda_create(
    gpu_trace_session_t *session,
    const gpu_trace_cuda_config_t *config,
    gpu_trace_cuda_t **out_cuda) {
    gpu_trace_cuda_config_t defaults;
    gpu_trace_cuda_t *cuda;

    if (session == NULL || out_cuda == NULL) {
        return GPU_TRACE_ERROR_INVALID_ARGUMENT;
    }
    memset(&defaults, 0, sizeof(defaults));
    defaults.size = (uint32_t)sizeof(defaults);
    defaults.version = GPU_TRACE_CUDA_VERSION;
    defaults.buffer_size_bytes = GPU_TRACE_CUDA_DEFAULT_BUFFER_SIZE;
    defaults.enable_runtime_api = 1U;
    defaults.enable_driver_api = 1U;
    defaults.enable_kernel = 1U;
    defaults.enable_memcpy = 1U;
    defaults.enable_memset = 1U;
    defaults.enable_synchronization = 1U;
    if (config == NULL) {
        config = &defaults;
    }
    if (!config_valid(config)) {
        return GPU_TRACE_ERROR_INVALID_ARGUMENT;
    }

    cuda = (gpu_trace_cuda_t *)calloc(1U, sizeof(*cuda));
    if (cuda == NULL) {
        return GPU_TRACE_ERROR_NO_MEMORY;
    }
    cuda->session = session;
    cuda->buffer_size_bytes = cfg_u32(config, offsetof(gpu_trace_cuda_config_t, buffer_size_bytes), defaults.buffer_size_bytes);
    cuda->enable_runtime_api = cfg_u32(config, offsetof(gpu_trace_cuda_config_t, enable_runtime_api), defaults.enable_runtime_api);
    cuda->enable_driver_api = cfg_u32(config, offsetof(gpu_trace_cuda_config_t, enable_driver_api), defaults.enable_driver_api);
    cuda->enable_kernel = cfg_u32(config, offsetof(gpu_trace_cuda_config_t, enable_kernel), defaults.enable_kernel);
    cuda->enable_memcpy = cfg_u32(config, offsetof(gpu_trace_cuda_config_t, enable_memcpy), defaults.enable_memcpy);
    cuda->enable_memset = cfg_u32(config, offsetof(gpu_trace_cuda_config_t, enable_memset), defaults.enable_memset);
    cuda->enable_synchronization = cfg_u32(config, offsetof(gpu_trace_cuda_config_t, enable_synchronization), defaults.enable_synchronization);
    cuda->clock_now = NULL;
    cuda->clock_user_data = NULL;
    atomic_init(&cuda->next_event_id, 0U);
    atomic_init(&cuda->state, GPU_TRACE_CUDA_STATE_CREATED);
    atomic_init(&cuda->cupti_dropped_count, 0U);
    atomic_init(&cuda->translation_error_count, 0U);
    atomic_init(&cuda->clock_mapping_valid, 0U);

    if (config->size >= (uint32_t)(offsetof(gpu_trace_cuda_config_t, clock_mapping) + sizeof(config->clock_mapping)) &&
        config->clock_mapping != NULL) {
        if (gpu_trace_clock_mapping_validate(config->clock_mapping) != GPU_TRACE_OK ||
            config->clock_mapping->source_domain != GPU_TRACE_CLOCK_GPU ||
            config->clock_mapping->destination_domain == GPU_TRACE_CLOCK_GPU ||
            config->clock_mapping->destination_domain == GPU_TRACE_CLOCK_UNKNOWN) {
            free(cuda);
            return GPU_TRACE_ERROR_INVALID_ARGUMENT;
        }
        cuda->clock_mapping = *config->clock_mapping;
        atomic_store_explicit(&cuda->clock_mapping_valid, 1U, memory_order_release);
    }
    if (config->size >= (uint32_t)(offsetof(gpu_trace_cuda_config_t, clock_now) + sizeof(config->clock_now))) {
        cuda->clock_now = config->clock_now;
    }
    if (config->size >= (uint32_t)(offsetof(gpu_trace_cuda_config_t, clock_user_data) + sizeof(config->clock_user_data))) {
        cuda->clock_user_data = config->clock_user_data;
    }
    if (atomic_load_explicit(&cuda->clock_mapping_valid, memory_order_acquire) != 0U &&
        cuda->clock_now != NULL) {
        free(cuda);
        return GPU_TRACE_ERROR_INVALID_ARGUMENT;
    }

    *out_cuda = cuda;
    return GPU_TRACE_OK;
}

gpu_trace_status_t gpu_trace_cuda_start(gpu_trace_cuda_t *cuda) {
    uint32_t expected = GPU_TRACE_CUDA_STATE_CREATED;
    gpu_trace_cuda_t *current;
    CUptiResult result;

    if (cuda == NULL) {
        return GPU_TRACE_ERROR_INVALID_ARGUMENT;
    }
    if (!atomic_compare_exchange_strong_explicit(
            &cuda->state, &expected, GPU_TRACE_CUDA_STATE_RUNNING,
            memory_order_acq_rel, memory_order_acquire)) {
        return GPU_TRACE_ERROR_ALREADY_STARTED;
    }

    current = atomic_exchange_explicit(&g_active_cuda, cuda, memory_order_acq_rel);
    if (current != NULL) {
        atomic_store_explicit(&g_active_cuda, current, memory_order_release);
        atomic_store_explicit(&cuda->state, GPU_TRACE_CUDA_STATE_CREATED,
                              memory_order_release);
        return GPU_TRACE_ERROR_ALREADY_STARTED;
    }

    if (!atomic_load_explicit(&cuda->clock_mapping_valid,
                              memory_order_acquire)) {
        if (calibrate_clock(cuda) != GPU_TRACE_OK) {
            atomic_store_explicit(&g_active_cuda, NULL, memory_order_release);
            atomic_store_explicit(&cuda->state, GPU_TRACE_CUDA_STATE_CREATED,
                                  memory_order_release);
            return GPU_TRACE_ERROR_UNSUPPORTED;
        }
    }

    result = cuptiActivityRegisterCallbacks(buffer_requested, buffer_completed);
    if (result != CUPTI_SUCCESS) goto fail;

    if (cuda->enable_runtime_api) {
        result = cuptiActivityEnable(CUPTI_ACTIVITY_KIND_RUNTIME);
        if (result != CUPTI_SUCCESS) goto fail;
    }
    if (cuda->enable_driver_api) {
        result = cuptiActivityEnable(CUPTI_ACTIVITY_KIND_DRIVER);
        if (result != CUPTI_SUCCESS) goto fail;
    }
    if (cuda->enable_kernel) {
        result = cuptiActivityEnable(CUPTI_ACTIVITY_KIND_CONCURRENT_KERNEL);
        if (result != CUPTI_SUCCESS) goto fail;
    }
    if (cuda->enable_memcpy) {
        result = cuptiActivityEnable(CUPTI_ACTIVITY_KIND_MEMCPY);
        if (result != CUPTI_SUCCESS) goto fail;
    }
    if (cuda->enable_memset) {
        result = cuptiActivityEnable(CUPTI_ACTIVITY_KIND_MEMSET);
        if (result != CUPTI_SUCCESS) goto fail;
    }
    if (cuda->enable_synchronization) {
        result = cuptiActivityEnable(CUPTI_ACTIVITY_KIND_SYNCHRONIZATION);
        if (result != CUPTI_SUCCESS && result != CUPTI_ERROR_NOT_SUPPORTED) goto fail;
    }
    return GPU_TRACE_OK;

fail:
    (void)cuptiActivityDisable(CUPTI_ACTIVITY_KIND_RUNTIME);
    (void)cuptiActivityDisable(CUPTI_ACTIVITY_KIND_DRIVER);
    (void)cuptiActivityDisable(CUPTI_ACTIVITY_KIND_CONCURRENT_KERNEL);
    (void)cuptiActivityDisable(CUPTI_ACTIVITY_KIND_MEMCPY);
    (void)cuptiActivityDisable(CUPTI_ACTIVITY_KIND_MEMSET);
    (void)cuptiActivityDisable(CUPTI_ACTIVITY_KIND_SYNCHRONIZATION);
    atomic_store_explicit(&g_active_cuda, NULL, memory_order_release);
    atomic_store_explicit(&cuda->state, GPU_TRACE_CUDA_STATE_CREATED,
                          memory_order_release);
    return map_cupti(result);
}

gpu_trace_status_t gpu_trace_cuda_flush(gpu_trace_cuda_t *cuda) {
    uint32_t state;
    CUptiResult result;
    if (cuda == NULL) return GPU_TRACE_ERROR_INVALID_ARGUMENT;
    state = atomic_load_explicit(&cuda->state, memory_order_acquire);
    if (state != GPU_TRACE_CUDA_STATE_RUNNING && state != GPU_TRACE_CUDA_STATE_STOPPED) {
        return GPU_TRACE_ERROR_NOT_INITIALIZED;
    }
    result = cuptiActivityFlushAll(1);
    return map_cupti(result);
}

gpu_trace_status_t gpu_trace_cuda_stop(gpu_trace_cuda_t *cuda) {
    uint32_t expected = GPU_TRACE_CUDA_STATE_RUNNING;
    CUptiResult result;
    if (cuda == NULL) return GPU_TRACE_ERROR_INVALID_ARGUMENT;
    if (!atomic_compare_exchange_strong_explicit(
            &cuda->state, &expected, GPU_TRACE_CUDA_STATE_STOPPED,
            memory_order_acq_rel, memory_order_acquire)) {
        return expected == GPU_TRACE_CUDA_STATE_CREATED
            ? GPU_TRACE_ERROR_NOT_INITIALIZED : GPU_TRACE_ERROR_ALREADY_STARTED;
    }
    result = cuptiActivityFlushAll(1);
    (void)cuptiActivityDisable(CUPTI_ACTIVITY_KIND_RUNTIME);
    (void)cuptiActivityDisable(CUPTI_ACTIVITY_KIND_DRIVER);
    (void)cuptiActivityDisable(CUPTI_ACTIVITY_KIND_CONCURRENT_KERNEL);
    (void)cuptiActivityDisable(CUPTI_ACTIVITY_KIND_MEMCPY);
    (void)cuptiActivityDisable(CUPTI_ACTIVITY_KIND_MEMSET);
    (void)cuptiActivityDisable(CUPTI_ACTIVITY_KIND_SYNCHRONIZATION);
    atomic_store_explicit(&g_active_cuda, NULL, memory_order_release);
    return map_cupti(result);
}

gpu_trace_status_t gpu_trace_cuda_destroy(gpu_trace_cuda_t *cuda) {
    if (cuda == NULL) return GPU_TRACE_ERROR_INVALID_ARGUMENT;
    if (atomic_load_explicit(&cuda->state, memory_order_acquire) == GPU_TRACE_CUDA_STATE_RUNNING) {
        return GPU_TRACE_ERROR_ALREADY_STARTED;
    }
    if (atomic_load_explicit(&g_active_cuda, memory_order_acquire) == cuda) {
        return GPU_TRACE_ERROR_PENDING_EVENTS;
    }
    free(cuda);
    return GPU_TRACE_OK;
}

gpu_trace_status_t gpu_trace_cuda_get_capabilities(
    const gpu_trace_cuda_t *cuda,
    gpu_trace_capabilities_t *out_capabilities) {
    gpu_trace_capabilities_t value;
    if (cuda == NULL || out_capabilities == NULL ||
        out_capabilities->size < (uint32_t)offsetof(gpu_trace_capabilities_t, reserved0) ||
        out_capabilities->version != 1U) {
        return GPU_TRACE_ERROR_INVALID_ARGUMENT;
    }
    memset(&value, 0, sizeof(value));
    value.size = (uint32_t)sizeof(value);
    value.version = 1U;
    value.supported =
        GPU_TRACE_CAPABILITY_BIT(GPU_TRACE_CAP_HOST_EVENTS) |
        GPU_TRACE_CAPABILITY_BIT(GPU_TRACE_CAP_GPU_EXECUTION) |
        GPU_TRACE_CAPABILITY_BIT(GPU_TRACE_CAP_GPU_TIMESTAMPS) |
        GPU_TRACE_CAPABILITY_BIT(GPU_TRACE_CAP_CLOCK_CALIBRATION) |
        GPU_TRACE_CAPABILITY_BIT(GPU_TRACE_CAP_HOST_GPU_CORRELATION) |
        GPU_TRACE_CAPABILITY_BIT(GPU_TRACE_CAP_DEVICE_IDENTITY) |
        GPU_TRACE_CAPABILITY_BIT(GPU_TRACE_CAP_QUEUE_IDENTITY) |
        GPU_TRACE_CAPABILITY_BIT(GPU_TRACE_CAP_MEMORY) |
        GPU_TRACE_CAPABILITY_BIT(GPU_TRACE_CAP_SYNCHRONIZATION) |
        GPU_TRACE_CAPABILITY_BIT(GPU_TRACE_CAP_GRAPH_CAPTURE) |
        GPU_TRACE_CAPABILITY_BIT(GPU_TRACE_CAP_ASYNC_RECORDING);
    value.guaranteed =
        GPU_TRACE_CAPABILITY_BIT(GPU_TRACE_CAP_HOST_GPU_CORRELATION) |
        GPU_TRACE_CAPABILITY_BIT(GPU_TRACE_CAP_DEVICE_IDENTITY) |
        GPU_TRACE_CAPABILITY_BIT(GPU_TRACE_CAP_QUEUE_IDENTITY) |
        GPU_TRACE_CAPABILITY_BIT(GPU_TRACE_CAP_GRAPH_CAPTURE) |
        GPU_TRACE_CAPABILITY_BIT(GPU_TRACE_CAP_ASYNC_RECORDING);
    if (atomic_load_explicit(&cuda->clock_mapping_valid, memory_order_acquire)) {
        value.guaranteed |=
            GPU_TRACE_CAPABILITY_BIT(GPU_TRACE_CAP_GPU_TIMESTAMPS) |
            GPU_TRACE_CAPABILITY_BIT(GPU_TRACE_CAP_CLOCK_CALIBRATION);
    }
    if (cuda->enable_kernel) {
        value.guaranteed |= GPU_TRACE_CAPABILITY_BIT(GPU_TRACE_CAP_GPU_EXECUTION);
    }
    if (cuda->enable_memcpy || cuda->enable_memset) {
        value.guaranteed |= GPU_TRACE_CAPABILITY_BIT(GPU_TRACE_CAP_MEMORY);
    }
    if (cuda->enable_synchronization) {
        value.guaranteed |= GPU_TRACE_CAPABILITY_BIT(GPU_TRACE_CAP_SYNCHRONIZATION);
    }
    if (cuda->enable_runtime_api || cuda->enable_driver_api) {
        value.guaranteed |= GPU_TRACE_CAPABILITY_BIT(GPU_TRACE_CAP_HOST_EVENTS);
    }

    {
        size_t copy_size = out_capabilities->size;
        if (copy_size > sizeof(value)) copy_size = sizeof(value);
        memcpy(out_capabilities, &value, copy_size);
    }
    return GPU_TRACE_OK;
}

uint64_t gpu_trace_cuda_get_cupti_dropped_count(
    const gpu_trace_cuda_t *cuda) {
    return cuda == NULL ? 0U
                        : atomic_load_explicit(&cuda->cupti_dropped_count,
                                               memory_order_relaxed);
}

uint64_t gpu_trace_cuda_get_translation_error_count(
    const gpu_trace_cuda_t *cuda) {
    return cuda == NULL ? 0U
                        : atomic_load_explicit(&cuda->translation_error_count,
                                               memory_order_relaxed);
}
