#ifndef TEST_STUB_CUPTI_ACTIVITY_H
#define TEST_STUB_CUPTI_ACTIVITY_H
#include <stddef.h>
#include <stdint.h>
#include "cupti.h"
#ifdef __cplusplus
extern "C" {
#endif

typedef enum CUpti_ActivityKind {
    CUPTI_ACTIVITY_KIND_INVALID = 0,
    CUPTI_ACTIVITY_KIND_MEMCPY = 1,
    CUPTI_ACTIVITY_KIND_MEMSET = 2,
    CUPTI_ACTIVITY_KIND_KERNEL = 3,
    CUPTI_ACTIVITY_KIND_DRIVER = 4,
    CUPTI_ACTIVITY_KIND_RUNTIME = 5,
    CUPTI_ACTIVITY_KIND_CONCURRENT_KERNEL = 6,
    CUPTI_ACTIVITY_KIND_SYNCHRONIZATION = 7
} CUpti_ActivityKind;

typedef enum CUpti_ActivityMemcpyKind {
    CUPTI_ACTIVITY_MEMCPY_KIND_UNKNOWN = 0,
    CUPTI_ACTIVITY_MEMCPY_KIND_HTOD = 1,
    CUPTI_ACTIVITY_MEMCPY_KIND_DTOH = 2,
    CUPTI_ACTIVITY_MEMCPY_KIND_DTOD = 3,
    CUPTI_ACTIVITY_MEMCPY_KIND_HTOH = 4,
    CUPTI_ACTIVITY_MEMCPY_KIND_HTOA = 5,
    CUPTI_ACTIVITY_MEMCPY_KIND_ATOH = 6,
    CUPTI_ACTIVITY_MEMCPY_KIND_ATOD = 7,
    CUPTI_ACTIVITY_MEMCPY_KIND_DTOA = 8,
    CUPTI_ACTIVITY_MEMCPY_KIND_ATOA = 9,
    CUPTI_ACTIVITY_MEMCPY_KIND_PTOP = 10
} CUpti_ActivityMemcpyKind;

typedef enum CUpti_ActivitySynchronizationType {
    CUPTI_ACTIVITY_SYNCHRONIZATION_TYPE_UNKNOWN = 0,
    CUPTI_ACTIVITY_SYNCHRONIZATION_TYPE_CONTEXT_SYNCHRONIZE = 1,
    CUPTI_ACTIVITY_SYNCHRONIZATION_TYPE_STREAM_SYNCHRONIZE = 2,
    CUPTI_ACTIVITY_SYNCHRONIZATION_TYPE_EVENT_SYNCHRONIZE = 3,
    CUPTI_ACTIVITY_SYNCHRONIZATION_TYPE_STREAM_WAIT_EVENT = 4
} CUpti_ActivitySynchronizationType;

typedef struct CUpti_Activity {
    CUpti_ActivityKind kind;
    uint32_t size;
} CUpti_Activity;

typedef enum CUpti_CallbackDomain { CUPTI_CB_DOMAIN_DRIVER_API = 1, CUPTI_CB_DOMAIN_RUNTIME_API = 2 } CUpti_CallbackDomain;

typedef struct CUpti_ActivityAPI {
    CUpti_ActivityKind kind;
    uint32_t size;
    uint32_t cbid;
    uint64_t start;
    uint64_t end;
    uint32_t processId;
    uint64_t threadId;
    uint32_t correlationId;
    uint32_t returnValue;
} CUpti_ActivityAPI;

typedef struct CUpti_ActivityKernel12 {
    CUpti_ActivityKind kind;
    uint32_t size;
    uint64_t start;
    uint64_t end;
    uint64_t completed;
    uint32_t deviceId;
    uint32_t contextId;
    uint32_t streamId;
    int64_t gridId;
    const char *name;
    uint32_t correlationId;
    uint64_t graphNodeId;
    uint32_t graphId;
} CUpti_ActivityKernel12;

typedef struct CUpti_ActivityMemcpy6 {
    CUpti_ActivityKind kind;
    uint32_t size;
    uint8_t copyKind;
    uint8_t srcKind;
    uint8_t dstKind;
    uint8_t flags;
    uint64_t bytes;
    uint64_t start;
    uint64_t end;
    uint32_t deviceId;
    uint32_t contextId;
    uint32_t streamId;
    uint32_t correlationId;
    uint32_t runtimeCorrelationId;
    uint64_t graphNodeId;
    uint32_t graphId;
} CUpti_ActivityMemcpy6;

typedef struct CUpti_ActivityMemset4 {
    CUpti_ActivityKind kind;
    uint32_t size;
    uint32_t value;
    uint64_t bytes;
    uint64_t start;
    uint64_t end;
    uint32_t deviceId;
    uint32_t contextId;
    uint32_t streamId;
    uint32_t correlationId;
    uint16_t flags;
    uint16_t memoryKind;
    uint64_t graphNodeId;
    uint32_t graphId;
} CUpti_ActivityMemset4;

typedef struct CUpti_ActivitySynchronization2 {
    CUpti_ActivityKind kind;
    uint32_t size;
    CUpti_ActivitySynchronizationType type;
    uint64_t start;
    uint64_t end;
    uint32_t correlationId;
    uint32_t contextId;
    uint32_t streamId;
    uint64_t cudaEventId;
} CUpti_ActivitySynchronization2;

typedef void (*CUpti_BuffersCallbackRequestFunc)(uint8_t **buffer, size_t *size, size_t *maxNumRecords);
typedef void (*CUpti_BuffersCallbackCompleteFunc)(CUcontext context, uint32_t streamId, uint8_t *buffer, size_t size);

CUptiResult cuptiGetTimestamp(uint64_t *timestamp);
CUptiResult cuptiGetCallbackName(CUpti_CallbackDomain domain, uint32_t cbid, const char **name);
CUptiResult cuptiActivityRegisterCallbacks(CUpti_BuffersCallbackRequestFunc request, CUpti_BuffersCallbackCompleteFunc complete);
CUptiResult cuptiActivityEnable(CUpti_ActivityKind kind);
CUptiResult cuptiActivityDisable(CUpti_ActivityKind kind);
CUptiResult cuptiActivityEnableLatencyTimestamps(uint8_t enable);
CUptiResult cuptiActivityFlushAll(uint8_t flag);
CUptiResult cuptiActivityGetNextRecord(uint8_t *buffer, size_t validBufferSizeBytes, CUpti_Activity **record);
CUptiResult cuptiActivityGetNumDroppedRecords(CUcontext context, uint32_t streamId, uint64_t *dropped);

#ifdef __cplusplus
}
#endif
#endif
