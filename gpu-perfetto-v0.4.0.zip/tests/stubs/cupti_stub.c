#define _POSIX_C_SOURCE 200809L
#include "cupti_activity.h"
#include <string.h>
#include <time.h>

static CUpti_BuffersCallbackRequestFunc g_request;
static CUpti_BuffersCallbackCompleteFunc g_complete;
static uint64_t g_dropped;
static uint32_t g_enabled[16];

CUptiResult cuptiGetCallbackName(CUpti_CallbackDomain domain, uint32_t cbid, const char **name) {
    (void)domain; (void)cbid;
    if (name == NULL) return CUPTI_ERROR_UNKNOWN;
    *name = "cudaStubApi";
    return CUPTI_SUCCESS;
}

CUptiResult cuptiGetTimestamp(uint64_t *timestamp) {
    struct timespec ts;
    if (timestamp == NULL || clock_gettime(CLOCK_MONOTONIC, &ts) != 0) return CUPTI_ERROR_UNKNOWN;
    *timestamp = (uint64_t)ts.tv_sec * UINT64_C(1000000000) + (uint64_t)ts.tv_nsec;
    return CUPTI_SUCCESS;
}
CUptiResult cuptiActivityRegisterCallbacks(CUpti_BuffersCallbackRequestFunc request, CUpti_BuffersCallbackCompleteFunc complete) {
    g_request = request; g_complete = complete; return CUPTI_SUCCESS;
}
CUptiResult cuptiActivityEnable(CUpti_ActivityKind kind) { if ((unsigned)kind < 16U) g_enabled[kind] = 1U; return CUPTI_SUCCESS; }
CUptiResult cuptiActivityDisable(CUpti_ActivityKind kind) { if ((unsigned)kind < 16U) g_enabled[kind] = 0U; return CUPTI_SUCCESS; }
CUptiResult cuptiActivityEnableLatencyTimestamps(uint8_t enable) { (void)enable; return CUPTI_SUCCESS; }
CUptiResult cuptiActivityFlushAll(uint8_t flag) { (void)flag; return CUPTI_SUCCESS; }
CUptiResult cuptiActivityGetNextRecord(uint8_t *buffer, size_t validBufferSizeBytes, CUpti_Activity **record) {
    CUpti_Activity *candidate;
    if (record == NULL || buffer == NULL) return CUPTI_ERROR_UNKNOWN;
    if (validBufferSizeBytes < sizeof(CUpti_Activity)) return CUPTI_ERROR_MAX_LIMIT_REACHED;
    candidate = (CUpti_Activity *)buffer;
    if (candidate->size == 0U || candidate->size > validBufferSizeBytes) return CUPTI_ERROR_MAX_LIMIT_REACHED;
    *record = candidate;
    return CUPTI_SUCCESS;
}
CUptiResult cuptiActivityGetNumDroppedRecords(CUcontext context, uint32_t streamId, uint64_t *dropped) {
    (void)context; (void)streamId;
    if (dropped == NULL) return CUPTI_ERROR_UNKNOWN;
    *dropped = g_dropped; g_dropped = 0U; return CUPTI_SUCCESS;
}

void test_cupti_emit(uint8_t *buffer, size_t size) {
    if (g_complete) g_complete(NULL, 0U, buffer, size);
}
CUpti_BuffersCallbackRequestFunc test_cupti_request(void) { return g_request; }
