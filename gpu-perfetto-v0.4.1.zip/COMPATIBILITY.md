# Compatibility

This document distinguishes **build support** from **runtime validation**.

| Component | Status |
|---|---|
| ISO C11 core | Development target |
| C++ wrapper | Planned |
| Perfetto-compatible JSON sink | Implemented / host-clock only |
| Native Perfetto C++ SDK backend | Implemented / external SDK required |
| CUDA/CUPTI | Implemented / external CUDA + CUPTI required / stub-tested / real-GPU validation pending |
| HIP/ROCm | Adapter planned |
| Level Zero | Adapter planned |
| SYCL | Adapter planned |
| Vulkan | Adapter planned |
| WebGPU | Adapter planned |
| Linux | CI target |
| Windows | CI target |
| macOS | CI target |

No entry marked "planned" should be interpreted as runtime support.


## v0.2.0 development foundation

- C11 core API.
- C++17 public-header inclusion smoke-tested.
- Public structures use `size`/`version` extension semantics where explicitly documented.
- Event-source and correlation-domain fields are optional trailing extensions; callers using the v0.1.1 descriptor prefix remain valid.
- Clock mapping is a host-side utility and has no backend-specific timing guarantees.
- Real GPU/backend validation is not claimed until the corresponding adapters are implemented and tested on hardware.

## v0.3.0 Perfetto output

The v0.3 development tree provides a dependency-free Chrome Trace JSON sink. It is intended for direct opening in the Perfetto UI and Trace Processor. This is a compatibility/output path, not the native Perfetto protobuf SDK integration. The native SDK backend is implemented as an optional external-SDK target; actual SDK linkage and runtime validation require a supplied Perfetto SDK.

The JSON sink accepts `HOST_MONOTONIC` and `CALIBRATED` timestamps only. GPU-domain timestamps must be converted by a backend before being passed to this sink.


## v0.3.1 native Perfetto SDK backend

- Optional `gpu-perfetto-perfetto-sdk` target uses the Perfetto amalgamated C++ SDK (`perfetto.h` and `perfetto.cc`) supplied externally.
- The application owns `perfetto::Tracing::Initialize()` and the trace-session lifecycle.
- `gpu_trace_perfetto_sdk_register()` registers TrackEvent and is safe to call repeatedly after Perfetto initialization; sink construction itself is safe before registration.
- The native sink accepts only `GPU_TRACE_CLOCK_PERFETTO` timestamps already expressed in Perfetto's active trace clock.
- The sink emits TrackEvent slices, instants and counters, with native correlation IDs and preserved gpu-perfetto provenance as annotations. Events must be timestamp-ordered per mapped track because TrackEvent slices use a monotonically increasing timeline.
- Rich GPU protobuf packets such as `GpuRenderStageEvent` and `GpuCorrelation` are not synthesized by the generic native sink.
- CI in this environment uses an API-shaped Perfetto stub for compile/integration coverage; a real Perfetto SDK build is not claimed until the SDK is supplied and linked.


## v0.4.0 CUDA/CUPTI

- Requires an externally installed CUDA Toolkit/CUPTI matching the target application environment; the project does not vendor proprietary NVIDIA components. NVIDIA currently documents CUDA Toolkit 13.3 Update 1 with CUPTI 13.3.75.
- The CUDA adapter uses CUPTI activity buffering and registers process-wide activity buffer callbacks. Treat the adapter as process-global: one active `gpu_trace_cuda_t` instance at a time. Other tooling that also owns the same CUPTI activity callback registration may conflict and should be considered an unsupported composition until explicitly validated.
- Supported record families in this milestone: runtime API, driver API, concurrent kernel, memcpy, memset and synchronization.
- Automatic CUPTI clock calibration targets `HOST_MONOTONIC` unless `clock_now` is supplied. Native Perfetto output requires a mapping whose destination domain is `GPU_TRACE_CLOCK_PERFETTO`; raw GPU timestamps and generic host-monotonic timestamps are not silently accepted by the native sink.
- CUDA Graph IDs/node IDs are preserved when the CUPTI record exposes them.
- Stub/API validation is included; real CUDA-driver/GPU execution and long-running hardware validation remain a separate hardware tier.
