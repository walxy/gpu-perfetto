#include <fstream>
#include <memory>

#include "gpu_perfetto/perfetto_sdk.h"
#include "perfetto.h"

int main() {
    perfetto::TracingInitArgs args;
    args.backends = perfetto::kInProcessBackend;
    perfetto::Tracing::Initialize(args);

    if (gpu_trace_perfetto_sdk_register() != GPU_TRACE_OK) {
        return 1;
    }

    gpu_trace_perfetto_sdk_sink_t sink;
    if (gpu_trace_perfetto_sdk_sink_init(&sink) != GPU_TRACE_OK) {
        return 1;
    }

    gpu_trace_config_t config{};
    config.size = static_cast<uint32_t>(sizeof(config));
    config.version = 1U;
    config.enabled = 1U;
    config.capacity = 128U;

    gpu_trace_session_t *session = nullptr;
    if (gpu_trace_create(&config, &session) != GPU_TRACE_OK) {
        return 1;
    }
    if (gpu_trace_set_sink(session, gpu_trace_perfetto_sdk_sink_get_sink(&sink)) != GPU_TRACE_OK ||
        gpu_trace_start(session) != GPU_TRACE_OK) {
        return 1;
    }

    gpu_trace_event_desc_t event{};
    event.size = static_cast<uint32_t>(sizeof(event));
    event.version = 1U;
    event.type = GPU_TRACE_EVENT_EXECUTION;
    event.name = "matmul";
    event.event_id = 1U;
    event.correlation_id = 42U;
    event.device_id = 0U;
    event.queue_id = 7U;
    event.source = GPU_TRACE_SOURCE_USER;
    event.correlation_domain = GPU_TRACE_CORRELATION_LOCAL;
    event.begin.value = 1000000U;
    event.begin.domain = GPU_TRACE_CLOCK_CALIBRATED;
    event.end.value = 1250000U;
    event.end.domain = GPU_TRACE_CLOCK_CALIBRATED;

    if (gpu_trace_record(session, &event) != GPU_TRACE_OK ||
        gpu_trace_flush(session) != GPU_TRACE_OK ||
        gpu_trace_perfetto_sdk_flush() != GPU_TRACE_OK ||
        gpu_trace_stop(session) != GPU_TRACE_OK ||
        gpu_trace_destroy(session) != GPU_TRACE_OK) {
        return 1;
    }

    return 0;
}
