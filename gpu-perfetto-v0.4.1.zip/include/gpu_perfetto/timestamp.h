#ifndef GPU_PERFETTO_TIMESTAMP_H
#define GPU_PERFETTO_TIMESTAMP_H

#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

typedef enum gpu_trace_clock_domain {
    GPU_TRACE_CLOCK_HOST_MONOTONIC = 0,
    GPU_TRACE_CLOCK_GPU = 1,
    GPU_TRACE_CLOCK_CALIBRATED = 2,
    GPU_TRACE_CLOCK_UNKNOWN = 3,
    /* Timestamp in the active Perfetto TrackEvent trace clock. */
    GPU_TRACE_CLOCK_PERFETTO = 4
} gpu_trace_clock_domain_t;

typedef struct gpu_trace_timestamp {
    uint64_t value;
    gpu_trace_clock_domain_t domain;
    uint32_t resolution_ns;
    uint32_t uncertainty_ns;
} gpu_trace_timestamp_t;

#ifdef __cplusplus
}
#endif

#endif
