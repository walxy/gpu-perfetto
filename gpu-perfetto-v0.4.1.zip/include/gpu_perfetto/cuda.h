#ifndef GPU_PERFETTO_CUDA_H
#define GPU_PERFETTO_CUDA_H

#include <stddef.h>
#include <stdint.h>
#include "gpu_perfetto/capabilities.h"
#include "gpu_perfetto/clock.h"
#include "gpu_perfetto/status.h"
#include "gpu_perfetto/trace.h"

#ifdef __cplusplus
extern "C" {
#endif

typedef struct gpu_trace_cuda gpu_trace_cuda_t;

/* Read the destination clock used for automatic CUPTI timestamp calibration.
 * The callback should be cheap, non-blocking and side-effect free. Returning
 * GPU or UNKNOWN as the destination domain is invalid. */
typedef gpu_trace_status_t (*gpu_trace_cuda_clock_now_fn)(
    void *user_data,
    uint64_t *timestamp,
    gpu_trace_clock_domain_t *domain);

typedef struct gpu_trace_cuda_config {
    uint32_t size;
    uint32_t version;
    uint32_t buffer_size_bytes;
    uint32_t enable_runtime_api;
    uint32_t enable_driver_api;
    uint32_t enable_kernel;
    uint32_t enable_memcpy;
    uint32_t enable_memset;
    uint32_t enable_synchronization;
    uint32_t reserved0;
    const gpu_trace_clock_mapping_t *clock_mapping;
    gpu_trace_cuda_clock_now_fn clock_now;
    void *clock_user_data;
} gpu_trace_cuda_config_t;

gpu_trace_status_t gpu_trace_cuda_create(
    gpu_trace_session_t *session,
    const gpu_trace_cuda_config_t *config,
    gpu_trace_cuda_t **out_cuda);

gpu_trace_status_t gpu_trace_cuda_start(gpu_trace_cuda_t *cuda);
gpu_trace_status_t gpu_trace_cuda_flush(gpu_trace_cuda_t *cuda);
gpu_trace_status_t gpu_trace_cuda_stop(gpu_trace_cuda_t *cuda);
gpu_trace_status_t gpu_trace_cuda_destroy(gpu_trace_cuda_t *cuda);

gpu_trace_status_t gpu_trace_cuda_get_capabilities(
    const gpu_trace_cuda_t *cuda,
    gpu_trace_capabilities_t *out_capabilities);

uint64_t gpu_trace_cuda_get_cupti_dropped_count(
    const gpu_trace_cuda_t *cuda);

uint64_t gpu_trace_cuda_get_translation_error_count(
    const gpu_trace_cuda_t *cuda);

#ifdef __cplusplus
}
#endif

#endif
