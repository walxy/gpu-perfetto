#ifndef TEST_STUB_CUPTI_CALLBACKS_H
#define TEST_STUB_CUPTI_CALLBACKS_H
#include "cupti_activity.h"
#endif
