#ifndef TEST_STUB_CUPTI_H
#define TEST_STUB_CUPTI_H
#include <stddef.h>
#include <stdint.h>
#ifdef __cplusplus
extern "C" {
#endif
typedef void *CUcontext;
typedef enum {
    CUPTI_SUCCESS = 0,
    CUPTI_ERROR_MAX_LIMIT_REACHED = 1,
    CUPTI_ERROR_NOT_SUPPORTED = 2,
    CUPTI_ERROR_UNKNOWN = 3
} CUptiResult;
#ifdef __cplusplus
}
#endif
#endif
