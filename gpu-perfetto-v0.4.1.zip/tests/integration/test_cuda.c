#include "gpu_perfetto/gpu_perfetto.h"
#include "cupti_activity.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

extern void test_cupti_emit(uint8_t *buffer, size_t size);
extern CUpti_BuffersCallbackRequestFunc test_cupti_request(void);

typedef struct sink_state { uint32_t count; uint32_t execution; uint32_t named_api; uint32_t memory; uint32_t sync; uint32_t host; uint64_t correlation; uint64_t graph_node; uint32_t perfetto_domain_events; } sink_state_t;
static gpu_trace_status_t sink_emit(void *ud, const gpu_trace_event_desc_t *e) {
    sink_state_t *s = (sink_state_t *)ud;
    s->count++;
    if (e->type == GPU_TRACE_EVENT_EXECUTION) s->execution++;
    if (e->type == GPU_TRACE_EVENT_SCOPE && e->name != NULL && strcmp(e->name, "cudaStubApi") == 0) s->named_api++;
    if (e->type == GPU_TRACE_EVENT_MEMORY) s->memory++;
    if (e->type == GPU_TRACE_EVENT_SYNC) s->sync++;
    if (e->type == GPU_TRACE_EVENT_SCOPE && e->thread_id != 0U) s->host++;
    if (e->correlation_id != 0U) s->correlation = e->correlation_id;
    if (e->graph_node_id != 0U) s->graph_node = e->graph_node_id;
    if (e->begin.domain == GPU_TRACE_CLOCK_PERFETTO) s->perfetto_domain_events++;
    return GPU_TRACE_OK;
}
static uint64_t now_ns(void) {
    struct timespec ts; clock_gettime(CLOCK_MONOTONIC, &ts);
    return (uint64_t)ts.tv_sec * UINT64_C(1000000000) + (uint64_t)ts.tv_nsec;
}
static gpu_trace_status_t test_clock_now(void *user_data, uint64_t *timestamp,
                                         gpu_trace_clock_domain_t *domain) {
    (void)user_data;
    if (timestamp == NULL || domain == NULL) return GPU_TRACE_ERROR_INVALID_ARGUMENT;
    *timestamp = now_ns();
    *domain = GPU_TRACE_CLOCK_PERFETTO;
    return GPU_TRACE_OK;
}
#define CHECK(x) do { if (!(x)) { fprintf(stderr, "CHECK failed: %s\n", #x); return 1; } } while (0)

int main(void) {
    gpu_trace_config_t tc = {0}; gpu_trace_session_t *session = NULL;
    gpu_trace_sink_t sink = {0}; sink_state_t state = {0};
    gpu_trace_cuda_t *cuda = NULL; gpu_trace_cuda_config_t cc = {0};
    uint8_t *buffer; size_t offset = 0U;
    CUpti_ActivityAPI api = {0}; CUpti_ActivityKernel12 kernel = {0};
    CUpti_ActivityMemcpy6 copy = {0}; CUpti_ActivityMemcpy6 copy2 = {0}; CUpti_ActivitySynchronization2 sync = {0};
    uint64_t base;

    tc.size = (uint32_t)sizeof(tc); tc.version = 1U; tc.enabled = 1U; tc.capacity = 1024U;
    CHECK(gpu_trace_create(&tc, &session) == GPU_TRACE_OK);
    sink.size = (uint32_t)sizeof(sink); sink.version = 1U; sink.emit = sink_emit; sink.user_data = &state;
    CHECK(gpu_trace_set_sink(session, &sink) == GPU_TRACE_OK);
    CHECK(gpu_trace_start(session) == GPU_TRACE_OK);

    cc.size = (uint32_t)sizeof(cc); cc.version = 1U; cc.enable_runtime_api = 1U; cc.enable_driver_api = 1U; cc.enable_kernel = 1U; cc.enable_memcpy = 1U; cc.enable_memset = 1U; cc.enable_synchronization = 1U; cc.clock_now = test_clock_now;
    {
        gpu_trace_cuda_config_t invalid = cc;
        gpu_trace_cuda_t *invalid_cuda = (gpu_trace_cuda_t *)(uintptr_t)1U;
        invalid.enable_kernel = 2U;
        CHECK(gpu_trace_cuda_create(session, &invalid, &invalid_cuda) == GPU_TRACE_ERROR_INVALID_ARGUMENT);
        CHECK(invalid_cuda == NULL);
    }
    {
        gpu_trace_clock_mapping_t conflicting = {0};
        conflicting.size = (uint32_t)sizeof(conflicting); conflicting.version = 1U;
        conflicting.source_domain = GPU_TRACE_CLOCK_GPU; conflicting.destination_domain = GPU_TRACE_CLOCK_PERFETTO;
        conflicting.source_origin = 1U; conflicting.destination_origin = 1U; conflicting.numerator = 1U; conflicting.denominator = 1U;
        cc.clock_mapping = &conflicting;
        CHECK(gpu_trace_cuda_create(session, &cc, &cuda) == GPU_TRACE_ERROR_INVALID_ARGUMENT);
        cc.clock_mapping = NULL;
    }
    CHECK(gpu_trace_cuda_create(session, &cc, &cuda) == GPU_TRACE_OK);
    CHECK(gpu_trace_cuda_start(cuda) == GPU_TRACE_OK);
    CHECK(test_cupti_request() != NULL);
    base = now_ns();

    api.kind = CUPTI_ACTIVITY_KIND_RUNTIME; api.size = sizeof(api); api.start = base + 1000U; api.end = base + 2000U; api.threadId = 7U; api.correlationId = 42U;
    kernel.kind = CUPTI_ACTIVITY_KIND_CONCURRENT_KERNEL; kernel.size = sizeof(kernel); kernel.start = base + 3000U; kernel.end = base + 5000U; kernel.deviceId = 1U; kernel.contextId = 2U; kernel.streamId = 3U; kernel.gridId = 4; kernel.name = "kernel"; kernel.correlationId = 42U; kernel.graphId = 9U; kernel.graphNodeId = 10U;
    copy.kind = CUPTI_ACTIVITY_KIND_MEMCPY; copy.size = sizeof(copy); copy.copyKind = CUPTI_ACTIVITY_MEMCPY_KIND_HTOD; copy.bytes = 4096U; copy.start = base + 6000U; copy.end = base + 7000U; copy.deviceId = 1U; copy.contextId = 2U; copy.streamId = 3U; copy.correlationId = 43U;
    copy2 = copy; copy2.kind = CUPTI_ACTIVITY_KIND_MEMCPY2; copy2.correlationId = 45U; copy2.start = base + 7000U; copy2.end = base + 8000U;
    sync.kind = CUPTI_ACTIVITY_KIND_SYNCHRONIZATION; sync.size = sizeof(sync); sync.type = CUPTI_ACTIVITY_SYNCHRONIZATION_TYPE_STREAM_SYNCHRONIZE; sync.start = base + 9000U; sync.end = base + 10000U; sync.contextId = 2U; sync.streamId = 3U; sync.correlationId = 44U;

    buffer = (uint8_t *)malloc(sizeof(api) + sizeof(kernel) + sizeof(copy) + sizeof(copy2) + sizeof(sync));
    CHECK(buffer != NULL);
    memcpy(buffer + offset, &api, sizeof(api)); offset += sizeof(api);
    memcpy(buffer + offset, &kernel, sizeof(kernel)); offset += sizeof(kernel);
    memcpy(buffer + offset, &copy, sizeof(copy)); offset += sizeof(copy);
    memcpy(buffer + offset, &copy2, sizeof(copy2)); offset += sizeof(copy2);
    memcpy(buffer + offset, &sync, sizeof(sync)); offset += sizeof(sync);
    test_cupti_emit(buffer, offset);

    CHECK(gpu_trace_cuda_flush(cuda) == GPU_TRACE_OK);
    CHECK(gpu_trace_flush(session) == GPU_TRACE_OK);
    CHECK(state.host == 1U && state.named_api == 1U && state.execution == 1U && state.memory == 2U && state.sync == 1U);
    CHECK(gpu_trace_cuda_get_translation_error_count(cuda) == 0U);
    {
        uint8_t *malformed = (uint8_t *)malloc(sizeof(api));
        CHECK(malformed != NULL);
        memcpy(malformed, &api, sizeof(api));
        ((CUpti_ActivityAPI *)malformed)->size = (uint32_t)offsetof(CUpti_ActivityAPI, end);
        test_cupti_emit(malformed, sizeof(api));
        CHECK(gpu_trace_cuda_get_translation_error_count(cuda) == 1U);
    }
    CHECK(state.correlation == 44U && state.graph_node == 10U);
    CHECK(state.perfetto_domain_events == 5U);

    /* CUDA device/stream/context id 0 is valid; presence is carried by flags. */
    state = (sink_state_t){0};
    gpu_trace_event_desc_t zero_ids = {0};
    zero_ids.size = (uint32_t)sizeof(zero_ids);
    zero_ids.version = 1U;
    zero_ids.type = GPU_TRACE_EVENT_EXECUTION;
    zero_ids.name = "kernel0";
    zero_ids.event_id = 100U;
    zero_ids.correlation_id = 101U;
    zero_ids.flags = GPU_TRACE_FLAG_HAS_BEGIN | GPU_TRACE_FLAG_HAS_END |
                     GPU_TRACE_FLAG_HAS_DEVICE_ID |
                     GPU_TRACE_FLAG_HAS_QUEUE_ID |
                     GPU_TRACE_FLAG_HAS_CONTEXT_ID;
    zero_ids.begin.value = base + 10000U;
    zero_ids.begin.domain = GPU_TRACE_CLOCK_PERFETTO;
    zero_ids.end.value = base + 11000U;
    zero_ids.end.domain = GPU_TRACE_CLOCK_PERFETTO;
    zero_ids.device_id = 0U;
    zero_ids.queue_id = 0U;
    zero_ids.context_id = 0U;
    zero_ids.source = GPU_TRACE_SOURCE_CUPTI;
    zero_ids.correlation_domain = GPU_TRACE_CORRELATION_CUDA;
    CHECK(gpu_trace_record(session, &zero_ids) == GPU_TRACE_OK);
    CHECK(gpu_trace_flush(session) == GPU_TRACE_OK);
    CHECK(state.count == 1U);

    CHECK(gpu_trace_cuda_stop(cuda) == GPU_TRACE_OK);
    CHECK(gpu_trace_cuda_destroy(cuda) == GPU_TRACE_OK);
    CHECK(gpu_trace_stop(session) == GPU_TRACE_OK);
    CHECK(gpu_trace_destroy(session) == GPU_TRACE_OK);
    return 0;
}
