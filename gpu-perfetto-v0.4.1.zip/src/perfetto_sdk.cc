#include "gpu_perfetto/perfetto_sdk.h"

#include <atomic>
#include <cstdint>
#include <limits>
#include <mutex>

#include "perfetto.h"

PERFETTO_DEFINE_CATEGORIES(perfetto::Category("gpu-perfetto"));
PERFETTO_TRACK_EVENT_STATIC_STORAGE();

namespace {

constexpr uint32_t kVersion = 1U;
std::once_flag g_register_once;
std::atomic<bool> g_register_attempted{false};
std::atomic<bool> g_register_success{false};

int valid_sink(const gpu_trace_perfetto_sdk_sink_t *sink) {
    return sink != nullptr &&
           sink->size >= (uint32_t)sizeof(*sink) &&
           sink->version == kVersion &&
           sink->interface.emit != nullptr;
}

const char *counter_unit_name(gpu_trace_counter_unit_t unit) {
    switch (unit) {
        case GPU_TRACE_COUNTER_UNIT_COUNT: return "count";
        case GPU_TRACE_COUNTER_UNIT_BYTES: return "bytes";
        case GPU_TRACE_COUNTER_UNIT_NANOSECONDS: return "ns";
        case GPU_TRACE_COUNTER_UNIT_HERTZ: return "Hz";
        case GPU_TRACE_COUNTER_UNIT_PERCENT: return "percent";
        case GPU_TRACE_COUNTER_UNIT_UNKNOWN:
        default: return "";
    }
}

uint64_t mix64(uint64_t value) {
    value ^= value >> 30U;
    value *= UINT64_C(0xbf58476d1ce4e5b9);
    value ^= value >> 27U;
    value *= UINT64_C(0x94d049bb133111eb);
    value ^= value >> 31U;
    return value;
}

uint64_t stable_track_id(const gpu_trace_event_desc_t *event) {
    uint64_t value = event->device_id + UINT64_C(0x9e3779b97f4a7c15);
    value ^= mix64(event->queue_id + UINT64_C(0x517cc1b727220a95));
    value ^= mix64(event->context_id + UINT64_C(0x6eed0e9da4d94a4f));
    return mix64(value);
}

perfetto::Track event_track(const gpu_trace_event_desc_t *event) {
    if ((event->type == GPU_TRACE_EVENT_SCOPE ||
         event->type == GPU_TRACE_EVENT_INSTANT ||
         event->type == GPU_TRACE_EVENT_SYNC ||
         event->type == GPU_TRACE_EVENT_METADATA) &&
        (event->thread_id != 0U || (event->flags & GPU_TRACE_FLAG_HAS_THREAD_ID) != 0U)) {
        return perfetto::ThreadTrack::ForThread(
            static_cast<perfetto::base::PlatformThreadId>(event->thread_id));
    }

    if (event->queue_id != 0U || (event->flags & GPU_TRACE_FLAG_HAS_QUEUE_ID) != 0U) {
        return perfetto::NamedTrack(
            "gpu.queue", stable_track_id(event), perfetto::ProcessTrack::Current());
    }

    if (event->device_id != 0U || (event->flags & GPU_TRACE_FLAG_HAS_DEVICE_ID) != 0U) {
        return perfetto::NamedTrack(
            "gpu.device", mix64(event->device_id), perfetto::ProcessTrack::Current());
    }

    return perfetto::ProcessTrack::Current();
}

template <typename EventContext>
void write_common_annotations(EventContext &ctx,
                              const gpu_trace_event_desc_t *event) {
    auto *annotations = ctx.event()->add_debug_annotations();
    annotations->set_name("gpu.event_id");
    annotations->set_uint_value(event->event_id);

    if (event->correlation_id != 0U) {
        auto *annotation = ctx.event()->add_debug_annotations();
        annotation->set_name("gpu.correlation_id");
        annotation->set_uint_value(event->correlation_id);
    }

    if (event->device_id != 0U || (event->flags & GPU_TRACE_FLAG_HAS_DEVICE_ID) != 0U) {
        auto *annotation = ctx.event()->add_debug_annotations();
        annotation->set_name("gpu.device_id");
        annotation->set_uint_value(event->device_id);
    }

    if (event->queue_id != 0U || (event->flags & GPU_TRACE_FLAG_HAS_QUEUE_ID) != 0U) {
        auto *annotation = ctx.event()->add_debug_annotations();
        annotation->set_name("gpu.queue_id");
        annotation->set_uint_value(event->queue_id);
    }

    if (event->context_id != 0U || (event->flags & GPU_TRACE_FLAG_HAS_CONTEXT_ID) != 0U) {
        auto *annotation = ctx.event()->add_debug_annotations();
        annotation->set_name("gpu.context_id");
        annotation->set_uint_value(event->context_id);
    }

    if (event->graph_id != 0U || (event->flags & GPU_TRACE_FLAG_HAS_GRAPH_ID) != 0U) {
        auto *annotation = ctx.event()->add_debug_annotations();
        annotation->set_name("gpu.graph_id");
        annotation->set_uint_value(event->graph_id);
    }

    if (event->graph_node_id != 0U || (event->flags & GPU_TRACE_FLAG_HAS_GRAPH_NODE_ID) != 0U) {
        auto *annotation = ctx.event()->add_debug_annotations();
        annotation->set_name("gpu.graph_node_id");
        annotation->set_uint_value(event->graph_node_id);
    }

    if (event->thread_id != 0U || (event->flags & GPU_TRACE_FLAG_HAS_THREAD_ID) != 0U) {
        auto *annotation = ctx.event()->add_debug_annotations();
        annotation->set_name("gpu.thread_id");
        annotation->set_uint_value(event->thread_id);
    }

    auto *source = ctx.event()->add_debug_annotations();
    source->set_name("gpu.source");
    source->set_uint_value(static_cast<uint32_t>(event->source));

    auto *domain = ctx.event()->add_debug_annotations();
    domain->set_name("gpu.correlation_domain");
    domain->set_uint_value(static_cast<uint32_t>(event->correlation_domain));

    auto *flags = ctx.event()->add_debug_annotations();
    flags->set_name("gpu.flags");
    flags->set_uint_value(event->flags);
}

template <typename EventContext>
void write_correlation(EventContext &ctx,
                       const gpu_trace_event_desc_t *event) {
    if (event->correlation_id != 0U) {
        ctx.event()->set_correlation_id(event->correlation_id);
    }
    write_common_annotations(ctx, event);
}

void emit_complete(const gpu_trace_event_desc_t *event,
                   perfetto::Track track) {
    TRACE_EVENT_BEGIN(
        "gpu-perfetto",
        perfetto::DynamicString{event->name != nullptr ? event->name : ""},
        track,
        event->begin.value,
        [event](perfetto::EventContext ctx) { write_correlation(ctx, event); });

    TRACE_EVENT_END(
        "gpu-perfetto",
        track,
        event->end.value,
        [event](perfetto::EventContext ctx) {
            if (event->correlation_id != 0U) {
                ctx.event()->set_correlation_id(event->correlation_id);
            }
        });
}

void emit_instant(const gpu_trace_event_desc_t *event,
                  perfetto::Track track) {
    TRACE_EVENT_INSTANT(
        "gpu-perfetto",
        perfetto::DynamicString{event->name != nullptr ? event->name : ""},
        track,
        event->begin.value,
        [event](perfetto::EventContext ctx) { write_correlation(ctx, event); });
}

void emit_counter(const gpu_trace_event_desc_t *event) {
    const char *unit = counter_unit_name(event->counter_unit);
    perfetto::CounterTrack track(
        perfetto::DynamicString{event->name != nullptr ? event->name : "counter"},
        unit,
        perfetto::ProcessTrack::Current());

    if (event->value > static_cast<uint64_t>(std::numeric_limits<int64_t>::max())) {
        return;
    }

    TRACE_COUNTER(
        "gpu-perfetto",
        track,
        event->begin.value,
        static_cast<int64_t>(event->value),
        [event](perfetto::EventContext ctx) { write_correlation(ctx, event); });
}

gpu_trace_status_t sink_emit(void *user_data,
                             const gpu_trace_event_desc_t *event) {
    gpu_trace_perfetto_sdk_sink_t *sink =
        static_cast<gpu_trace_perfetto_sdk_sink_t *>(user_data);

    if (!valid_sink(sink) || event == nullptr) {
        return GPU_TRACE_ERROR_INVALID_ARGUMENT;
    }
    if (!g_register_success.load(std::memory_order_acquire)) {
        return GPU_TRACE_ERROR_NOT_INITIALIZED;
    }

    /* The native TrackEvent timestamp is in Perfetto's trace clock. The core's
     * CALIBRATED domain therefore means calibrated into that same target clock
     * for this sink. Raw GPU clocks and uncalibrated monotonic clocks are
     * intentionally rejected rather than producing a plausible but incorrect
     * timeline. */
    if (event->begin.domain != GPU_TRACE_CLOCK_PERFETTO) {
        return GPU_TRACE_ERROR_UNSUPPORTED;
    }

    switch (event->type) {
        case GPU_TRACE_EVENT_SCOPE:
        case GPU_TRACE_EVENT_SUBMISSION:
        case GPU_TRACE_EVENT_EXECUTION:
        case GPU_TRACE_EVENT_MEMORY:
            if (event->end.domain != GPU_TRACE_CLOCK_PERFETTO ||
                event->end.value < event->begin.value) {
                return GPU_TRACE_ERROR_UNSUPPORTED;
            }
            emit_complete(event, event_track(event));
            return GPU_TRACE_OK;

        case GPU_TRACE_EVENT_INSTANT:
        case GPU_TRACE_EVENT_SYNC:
        case GPU_TRACE_EVENT_METADATA:
            emit_instant(event, event_track(event));
            return GPU_TRACE_OK;

        case GPU_TRACE_EVENT_COUNTER:
            if (event->begin.domain != GPU_TRACE_CLOCK_PERFETTO) {
                return GPU_TRACE_ERROR_UNSUPPORTED;
            }
            if (event->value > static_cast<uint64_t>(std::numeric_limits<int64_t>::max())) {
                return GPU_TRACE_ERROR_UNSUPPORTED;
            }
            emit_counter(event);
            return GPU_TRACE_OK;

        default:
            return GPU_TRACE_ERROR_INVALID_ARGUMENT;
    }
}

}  // namespace

extern "C" gpu_trace_status_t gpu_trace_perfetto_sdk_register(void) {
    std::call_once(g_register_once, []() {
        g_register_attempted.store(true, std::memory_order_release);
        /* Perfetto requires the application to initialize Tracing first. This
         * function deliberately does not choose in-process vs system mode. */
        perfetto::TrackEvent::Register();
        g_register_success.store(true, std::memory_order_release);
    });

    if (!g_register_attempted.load(std::memory_order_acquire) ||
        !g_register_success.load(std::memory_order_acquire)) {
        return GPU_TRACE_ERROR_INTERNAL;
    }
    return GPU_TRACE_OK;
}

extern "C" gpu_trace_status_t gpu_trace_perfetto_sdk_clock_now(
    void *user_data,
    uint64_t *timestamp,
    gpu_trace_clock_domain_t *domain) {
    (void)user_data;
    if (timestamp == nullptr || domain == nullptr) {
        return GPU_TRACE_ERROR_INVALID_ARGUMENT;
    }
    if (!g_register_success.load(std::memory_order_acquire)) {
        return GPU_TRACE_ERROR_NOT_INITIALIZED;
    }
    *timestamp = perfetto::TrackEvent::GetTraceTimeNs();
    *domain = GPU_TRACE_CLOCK_PERFETTO;
    return GPU_TRACE_OK;
}

extern "C" gpu_trace_status_t gpu_trace_perfetto_sdk_sink_init(
    gpu_trace_perfetto_sdk_sink_t *sink) {
    if (sink == nullptr) {
        return GPU_TRACE_ERROR_INVALID_ARGUMENT;
    }

    *sink = {};
    sink->size = static_cast<uint32_t>(sizeof(*sink));
    sink->version = kVersion;
    sink->initialized = 1U;
    sink->interface.size = static_cast<uint32_t>(sizeof(sink->interface));
    sink->interface.version = 1U;
    sink->interface.emit = sink_emit;
    sink->interface.user_data = sink;
    return GPU_TRACE_OK;
}

extern "C" const gpu_trace_sink_t *gpu_trace_perfetto_sdk_sink_get_sink(
    const gpu_trace_perfetto_sdk_sink_t *sink) {
    if (!valid_sink(sink) || sink->initialized == 0U ||
        !g_register_success.load(std::memory_order_acquire)) {
        return nullptr;
    }
    return &sink->interface;
}

extern "C" gpu_trace_status_t gpu_trace_perfetto_sdk_flush(void) {
    perfetto::TrackEvent::Flush();
    return GPU_TRACE_OK;
}
