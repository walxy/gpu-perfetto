# Compatibility

This document distinguishes **build support** from **runtime validation**.

| Component | Status |
|---|---|
| ISO C11 core | Development target |
| C++ wrapper | Planned |
| Perfetto backend | Optional / not yet implemented in baseline |
| CUDA/CUPTI | Adapter planned |
| HIP/ROCm | Adapter planned |
| Level Zero | Adapter planned |
| SYCL | Adapter planned |
| Vulkan | Adapter planned |
| WebGPU | Adapter planned |
| Linux | CI target |
| Windows | CI target |
| macOS | CI target |

No entry marked "planned" should be interpreted as runtime support.
