#include "gpu_perfetto/gpu_perfetto.h"

#include <assert.h>
#include <stdint.h>
#include <string.h>

struct sink_state {
    uint64_t count;
    uint64_t last_event_id;
    uint32_t last_flags;
    char last_name[64];
    uint32_t fail_once;
};

static gpu_trace_status_t sink_emit(void *user_data,
                                    const gpu_trace_event_desc_t *event) {
    struct sink_state *state = (struct sink_state *)user_data;
    if (state->fail_once != 0U) {
        state->fail_once = 0U;
        return GPU_TRACE_ERROR_INTERNAL;
    }
    state->count += 1U;
    state->last_event_id = event->event_id;
    state->last_flags = event->flags;
    (void)strncpy(state->last_name, event->name != NULL ? event->name : "",
                  sizeof(state->last_name) - 1U);
    state->last_name[sizeof(state->last_name) - 1U] = '\0';
    return GPU_TRACE_OK;
}

static gpu_trace_event_desc_t make_event(uint64_t id, const char *name) {
    gpu_trace_event_desc_t event;
    memset(&event, 0, sizeof(event));
    event.size = (uint32_t)sizeof(event);
    event.version = 1U;
    event.type = GPU_TRACE_EVENT_SUBMISSION;
    event.name = name;
    event.event_id = id;
    event.correlation_id = 10U + id;
    event.device_id = 20U;
    event.queue_id = 30U;
    return event;
}

int main(void) {
    gpu_trace_config_t config;
    gpu_trace_session_t *session = NULL;
    gpu_trace_event_desc_t event;
    struct sink_state sink_state = {0U, 0U, 0U, {0}, 0U};
    gpu_trace_sink_t sink;
    char long_name[96];

    memset(&config, 0, sizeof(config));
    config.size = (uint32_t)sizeof(config);
    config.version = 1U;
    config.enabled = 1U;
    config.capacity = 4U;

    assert(gpu_trace_create(&config, &session) == GPU_TRACE_OK);
    assert(session != NULL);
    assert(gpu_trace_get_capacity(session) == 4U);
    assert(gpu_trace_start(session) == GPU_TRACE_OK);
    assert(gpu_trace_start(session) == GPU_TRACE_ERROR_ALREADY_STARTED);

    event = make_event(1U, "matmul");
    assert(gpu_trace_record(NULL, &event) == GPU_TRACE_ERROR_INVALID_ARGUMENT);

    assert(gpu_trace_stop(session) == GPU_TRACE_OK);
    assert(gpu_trace_record(session, &event) == GPU_TRACE_ERROR_NOT_INITIALIZED);
    assert(gpu_trace_start(session) == GPU_TRACE_ERROR_ALREADY_STARTED);
    assert(gpu_trace_destroy(session) == GPU_TRACE_OK);

    memset(&session, 0, sizeof(session));
    assert(gpu_trace_create(&config, &session) == GPU_TRACE_OK);
    assert(gpu_trace_start(session) == GPU_TRACE_OK);

    sink.size = (uint32_t)sizeof(sink);
    sink.version = 1U;
    sink.emit = sink_emit;
    sink.user_data = &sink_state;
    assert(gpu_trace_set_sink(session, &sink) == GPU_TRACE_ERROR_ALREADY_STARTED);
    assert(gpu_trace_stop(session) == GPU_TRACE_OK);
    assert(gpu_trace_destroy(session) == GPU_TRACE_OK);

    memset(&session, 0, sizeof(session));
    assert(gpu_trace_create(&config, &session) == GPU_TRACE_OK);
    assert(gpu_trace_set_sink(session, &sink) == GPU_TRACE_OK);
    assert(gpu_trace_start(session) == GPU_TRACE_OK);

    event = make_event(7U, "matmul");
    assert(gpu_trace_record(session, &event) == GPU_TRACE_OK);
    assert(gpu_trace_get_recorded_count(session) == 1U);
    assert(gpu_trace_get_pending_count(session) == 1U);
    assert(gpu_trace_get_dropped_count(session) == 0U);

    event.type = (gpu_trace_event_type_t)99;
    assert(gpu_trace_record(session, &event) == GPU_TRACE_ERROR_INVALID_ARGUMENT);
    event = make_event(8U, "other");
    assert(gpu_trace_record(session, &event) == GPU_TRACE_OK);
    event = make_event(9U, "third");
    assert(gpu_trace_record(session, &event) == GPU_TRACE_OK);
    event = make_event(10U, "fourth");
    assert(gpu_trace_record(session, &event) == GPU_TRACE_OK);
    event = make_event(11U, "overflow");
    assert(gpu_trace_record(session, &event) == GPU_TRACE_ERROR_BUFFER_FULL);
    assert(gpu_trace_get_dropped_count(session) == 1U);
    assert(gpu_trace_stop(session) == GPU_TRACE_OK);
    assert(gpu_trace_destroy(session) == GPU_TRACE_ERROR_PENDING_EVENTS);

    sink_state.fail_once = 1U;
    assert(gpu_trace_flush(session) == GPU_TRACE_ERROR_INTERNAL);
    assert(gpu_trace_get_flushed_count(session) == 0U);
    assert(gpu_trace_flush(session) == GPU_TRACE_OK);
    assert(gpu_trace_get_flushed_count(session) == 4U);

    assert(sink_state.count == 4U);
    assert(sink_state.last_event_id == 10U);
    assert(gpu_trace_destroy(session) == GPU_TRACE_OK);

    /* Truncation is validated in a fresh session because stopped sessions are one-shot. */
    memset(long_name, 'x', sizeof(long_name) - 1U);
    long_name[sizeof(long_name) - 1U] = '\0';
    memset(&session, 0, sizeof(session));
    sink_state.count = 0U;
    sink_state.last_event_id = 0U;
    sink_state.last_flags = 0U;
    assert(gpu_trace_create(&config, &session) == GPU_TRACE_OK);
    assert(gpu_trace_set_sink(session, &sink) == GPU_TRACE_OK);
    assert(gpu_trace_start(session) == GPU_TRACE_OK);
    event = make_event(12U, long_name);
    assert(gpu_trace_record(session, &event) == GPU_TRACE_OK);
    assert(gpu_trace_flush(session) == GPU_TRACE_OK);
    assert(sink_state.count == 1U);
    assert(sink_state.last_event_id == 12U);
    assert((sink_state.last_flags & GPU_TRACE_FLAG_TRUNCATED_NAME) != 0U);
    assert(strlen(sink_state.last_name) == 63U);
    assert(gpu_trace_stop(session) == GPU_TRACE_OK);
    assert(gpu_trace_destroy(session) == GPU_TRACE_OK);


    {
        struct legacy_config {
            uint32_t size;
            uint32_t version;
            uint32_t enabled;
            uint32_t reserved0;
        } legacy;
        legacy.size = (uint32_t)sizeof(legacy);
        legacy.version = 1U;
        legacy.enabled = 1U;
        legacy.reserved0 = 0U;
        memset(&session, 0, sizeof(session));
        assert(gpu_trace_create((const gpu_trace_config_t *)&legacy, &session) == GPU_TRACE_OK);
        assert(gpu_trace_get_capacity(session) == 1024U);
        assert(gpu_trace_start(session) == GPU_TRACE_OK);
        assert(gpu_trace_stop(session) == GPU_TRACE_OK);
        assert(gpu_trace_destroy(session) == GPU_TRACE_OK);
    }

    memset(&session, 0, sizeof(session));
    config.enabled = 0U;
    assert(gpu_trace_create(&config, &session) == GPU_TRACE_OK);
    assert(gpu_trace_start(session) == GPU_TRACE_OK);
    event = make_event(99U, "disabled");
    assert(gpu_trace_record(session, &event) == GPU_TRACE_OK);
    assert(gpu_trace_get_recorded_count(session) == 0U);
    assert(gpu_trace_get_dropped_count(session) == 0U);
    assert(gpu_trace_stop(session) == GPU_TRACE_OK);
    assert(gpu_trace_destroy(session) == GPU_TRACE_OK);

    assert(strcmp(gpu_trace_status_string(GPU_TRACE_OK), "ok") == 0);
    return 0;
}
