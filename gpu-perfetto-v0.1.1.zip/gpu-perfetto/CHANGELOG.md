# Changelog

## [0.1.1] - Development

### Added
- Bounded fixed-capacity multi-producer event transport.
- Thread-safe session state and event counters.
- Generic sink API with explicit flush semantics.
- Deterministic buffer-full reporting and dropped-event accounting.
- Safe deferred event-name ownership with truncation reporting.
- Recorded/flushed/dropped count introspection.
- Concurrency and performance test targets.

### Changed
- Core event recording now persists semantic events instead of only validating them.
- Configuration supports an optional power-of-two transport capacity.
- The event descriptor carries explicit flags for transport/timestamp semantics.

### Fixed
- Session lifecycle state is now atomic for concurrent recorders.
