# Core event transport

The v0.1.1 core separates event production from event consumption.

`gpu_trace_record()` validates and copies an event into a bounded, fixed-capacity
multi-producer queue. Normal recording performs no heap allocation. If the
queue is full, the event is dropped deterministically and
`GPU_TRACE_ERROR_BUFFER_FULL` is returned; the drop count is available through
`gpu_trace_get_dropped_count()`.

Event names are copied into the queue and capped at 63 bytes. Truncation is
reported with `GPU_TRACE_FLAG_TRUNCATED_NAME` so deferred consumers never
observe a dangling caller-owned string.

`gpu_trace_flush()` is the consumer side. It invokes the configured sink in FIFO
transport order. The sink must be configured before `gpu_trace_start()`.

This transport order is not a statement about GPU execution order. Backend
adapters must preserve native timestamp and correlation semantics rather than
turning host submission order into synthetic GPU timing.


## Lifecycle and data preservation

`gpu_trace_destroy()` does not silently discard buffered events. After stopping a
session, queued records must be flushed successfully before destruction; otherwise
`GPU_TRACE_ERROR_PENDING_EVENTS` is returned.

The core supports multiple producer threads and a single flush consumer. Callers
must externally serialize `start()`, `stop()`, and `destroy()`, and must not destroy
or concurrently reconfigure a session while another thread is using it. The sink is
configured before `start()` and remains immutable while the session is active.
