# Event model

The core distinguishes application annotations, GPU submissions, and actual GPU execution.

| Event | Meaning |
|---|---|
| Scope | Host-side semantic interval |
| Instant | Host-side point event |
| Submission | A GPU operation was submitted/enqueued |
| Execution | Backend-observed GPU execution interval |
| Memory | Copy/memory operation |
| Sync | Synchronization/wait |
| Counter | Numeric measurement |
| Metadata | Descriptive information |

Do not infer GPU execution duration from a host launch API call unless the backend explicitly provides that semantic guarantee.

## Thread safety

The v0.1 baseline does not claim concurrent mutation of a single session is thread-safe. A production implementation must define the session/buffer ownership model before enabling multi-threaded recording.
