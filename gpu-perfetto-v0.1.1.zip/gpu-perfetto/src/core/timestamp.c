#include "gpu_perfetto/timestamp.h"

/* Timestamp utilities intentionally remain minimal until backend-specific
 * clock calibration is introduced. */
