#include "gpu_perfetto/status.h"

const char *gpu_trace_status_string(gpu_trace_status_t status) {
    switch (status) {
        case GPU_TRACE_OK: return "ok";
        case GPU_TRACE_ERROR_INVALID_ARGUMENT: return "invalid argument";
        case GPU_TRACE_ERROR_NOT_INITIALIZED: return "not initialized";
        case GPU_TRACE_ERROR_ALREADY_STARTED: return "already started";
        case GPU_TRACE_ERROR_UNSUPPORTED: return "unsupported";
        case GPU_TRACE_ERROR_BACKEND_UNAVAILABLE: return "backend unavailable";
        case GPU_TRACE_ERROR_NO_MEMORY: return "out of memory";
        case GPU_TRACE_ERROR_BUFFER_FULL: return "buffer full";
        case GPU_TRACE_ERROR_INTERNAL: return "internal error";
        default: return "unknown status";
    }
}
