#ifndef GPU_PERFETTO_H
#define GPU_PERFETTO_H

#include "gpu_perfetto/status.h"
#include "gpu_perfetto/timestamp.h"
#include "gpu_perfetto/trace.h"

#define GPU_PERFETTO_VERSION_MAJOR 0
#define GPU_PERFETTO_VERSION_MINOR 1
#define GPU_PERFETTO_VERSION_PATCH 1

#endif
