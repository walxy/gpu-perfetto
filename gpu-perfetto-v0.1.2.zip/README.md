# gpu-perfetto

Tiny vendor-neutral GPU tracing interoperability layer for Perfetto.

## Status

**v0.1.2 development timestamp/correlation milestone.** The current tree implements the core semantic transport, bounded event buffering, sink interface, explicit event-source/correlation metadata, affine clock conversion primitives, and concurrency/sanitizer test foundation. Vendor adapters and the Perfetto sink are intentionally separate milestones and are not claimed to be runtime-validated yet.

## Design goals

- stable, small C API
- zero third-party runtime dependencies in the core
- explicit timestamp/clock semantics
- host/submission/execution distinction
- device/queue/correlation identity
- graceful capability-based degradation
- Perfetto-native output rather than a competing trace ecosystem

## Non-goals

Not a profiler, debugger, GPU scheduler, tracing daemon, profiler UI, or replacement for CUPTI, ROCprofiler, Intel PTI/unitrace, Kineto, Tracy, Nsight, or Perfetto itself.

## Timestamp and correlation foundation

The v0.1.2 development milestone adds explicit event-source and correlation-domain provenance plus an affine clock-mapping utility. The mapping utility is intentionally a conversion primitive rather than an automatic calibration system: backends must collect valid calibration samples and supply an uncertainty bound.

The public `device_id` and `queue_id` fields are opaque numeric identifiers whose interpretation is supplied by the event source. They are not assumed to be globally unique across processes, machines, or backend domains. Future adapters should attach stable native/UUID identity metadata without rewriting native identifiers.

## Current limitations

The v0.1.2 core persists semantic events in a bounded in-memory transport and can flush them to a generic sink. It does not yet emit Perfetto packets, perform backend-specific GPU clock calibration/clock synchronization, or implement vendor adapters; those remain separate milestones.

## Build

```bash
cmake -S . -B build
cmake --build build
ctest --test-dir build --output-on-failure
```

## Architecture

```text
application / framework
        |
        v
 gpu-perfetto core
        |
        +---- semantic events
        +---- timestamps/clocks
        +---- correlation/IDs
        +---- capabilities
        |
        +---- optional native adapters
        |      CUDA/CUPTI
        |      HIP/ROCm
        |      Level Zero/SYCL
        |      Vulkan
        |      WebGPU
        |
        +---- optional Perfetto backend
```

## Important semantic rule

An annotation around a host API call is not automatically the duration of GPU execution. Actual GPU execution timing must come from backend-observed GPU activity or explicit device timestamps. The implementation must not insert device synchronization merely to make a trace appear complete.

## License

Apache-2.0.
