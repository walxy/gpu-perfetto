#include "gpu_perfetto/gpu_perfetto.h"

#include <stdio.h>
#include <stdint.h>
#include <string.h>

#define CHECK(expr)                                                               \
    do {                                                                          \
        if (!(expr)) {                                                            \
            fprintf(stderr, "CHECK failed: %s (%s:%d)\n", #expr, __FILE__,    \
                    __LINE__);                                                   \
            return 1;                                                             \
        }                                                                         \
    } while (0)

struct sink_state {
    uint64_t count;
    uint64_t last_event_id;
    uint32_t last_flags;
    char last_name[64];
    uint32_t fail_once;
};

static gpu_trace_status_t sink_emit(void *user_data,
                                    const gpu_trace_event_desc_t *event) {
    struct sink_state *state = (struct sink_state *)user_data;
    if (state->fail_once != 0U) {
        state->fail_once = 0U;
        return GPU_TRACE_ERROR_INTERNAL;
    }
    state->count += 1U;
    state->last_event_id = event->event_id;
    state->last_flags = event->flags;
    (void)strncpy(state->last_name, event->name != NULL ? event->name : "",
                  sizeof(state->last_name) - 1U);
    state->last_name[sizeof(state->last_name) - 1U] = '\0';
    return GPU_TRACE_OK;
}

static gpu_trace_event_desc_t make_event(uint64_t id, const char *name) {
    gpu_trace_event_desc_t event;
    memset(&event, 0, sizeof(event));
    event.size = (uint32_t)sizeof(event);
    event.version = 1U;
    event.type = GPU_TRACE_EVENT_SUBMISSION;
    event.name = name;
    event.event_id = id;
    event.correlation_id = 10U + id;
    event.device_id = 20U;
    event.queue_id = 30U;
    return event;
}

int main(void) {
    gpu_trace_config_t config;
    gpu_trace_session_t *session = NULL;
    gpu_trace_event_desc_t event;
    struct sink_state sink_state = {0U, 0U, 0U, {0}, 0U};
    gpu_trace_sink_t sink;
    char long_name[96];

    memset(&config, 0, sizeof(config));
    config.size = (uint32_t)sizeof(config);
    config.version = 1U;
    config.enabled = 1U;
    config.capacity = 4U;

    CHECK(gpu_trace_create(&config, &session) == GPU_TRACE_OK);
    CHECK(session != NULL);
    CHECK(gpu_trace_get_capacity(session) == 4U);
    CHECK(gpu_trace_start(session) == GPU_TRACE_OK);
    CHECK(gpu_trace_start(session) == GPU_TRACE_ERROR_ALREADY_STARTED);

    event = make_event(1U, "matmul");
    CHECK(gpu_trace_record(NULL, &event) == GPU_TRACE_ERROR_INVALID_ARGUMENT);

    CHECK(gpu_trace_stop(session) == GPU_TRACE_OK);
    CHECK(gpu_trace_record(session, &event) == GPU_TRACE_ERROR_NOT_INITIALIZED);
    CHECK(gpu_trace_start(session) == GPU_TRACE_ERROR_ALREADY_STARTED);
    CHECK(gpu_trace_destroy(session) == GPU_TRACE_OK);

    memset(&session, 0, sizeof(session));
    CHECK(gpu_trace_create(&config, &session) == GPU_TRACE_OK);
    CHECK(gpu_trace_start(session) == GPU_TRACE_OK);

    sink.size = (uint32_t)sizeof(sink);
    sink.version = 1U;
    sink.emit = sink_emit;
    sink.user_data = &sink_state;
    CHECK(gpu_trace_set_sink(session, &sink) == GPU_TRACE_ERROR_ALREADY_STARTED);
    CHECK(gpu_trace_stop(session) == GPU_TRACE_OK);
    CHECK(gpu_trace_destroy(session) == GPU_TRACE_OK);

    memset(&session, 0, sizeof(session));
    CHECK(gpu_trace_create(&config, &session) == GPU_TRACE_OK);
    CHECK(gpu_trace_set_sink(session, &sink) == GPU_TRACE_OK);
    CHECK(gpu_trace_start(session) == GPU_TRACE_OK);

    event = make_event(7U, "matmul");
    event.source = GPU_TRACE_SOURCE_USER;
    event.correlation_domain = GPU_TRACE_CORRELATION_LOCAL;
    CHECK(gpu_trace_record(session, &event) == GPU_TRACE_OK);
    CHECK(gpu_trace_get_recorded_count(session) == 1U);
    CHECK(gpu_trace_get_pending_count(session) == 1U);
    CHECK(gpu_trace_get_dropped_count(session) == 0U);

    event.type = (gpu_trace_event_type_t)99;
    CHECK(gpu_trace_record(session, &event) == GPU_TRACE_ERROR_INVALID_ARGUMENT);
    event = make_event(8U, "other");
    CHECK(gpu_trace_record(session, &event) == GPU_TRACE_OK);
    event = make_event(9U, "third");
    CHECK(gpu_trace_record(session, &event) == GPU_TRACE_OK);
    event = make_event(10U, "fourth");
    CHECK(gpu_trace_record(session, &event) == GPU_TRACE_OK);
    event = make_event(11U, "overflow");
    CHECK(gpu_trace_record(session, &event) == GPU_TRACE_ERROR_BUFFER_FULL);
    CHECK(gpu_trace_get_dropped_count(session) == 1U);
    CHECK(gpu_trace_stop(session) == GPU_TRACE_OK);
    CHECK(gpu_trace_destroy(session) == GPU_TRACE_ERROR_PENDING_EVENTS);

    sink_state.fail_once = 1U;
    CHECK(gpu_trace_flush(session) == GPU_TRACE_ERROR_INTERNAL);
    CHECK(gpu_trace_get_flushed_count(session) == 0U);
    CHECK(gpu_trace_flush(session) == GPU_TRACE_OK);
    CHECK(gpu_trace_get_flushed_count(session) == 4U);

    CHECK(sink_state.count == 4U);
    CHECK(sink_state.last_event_id == 10U);
    CHECK(sink_state.last_flags == 0U);
    CHECK(gpu_trace_destroy(session) == GPU_TRACE_OK);

    /* Provenance fields are part of the optional trailing descriptor extension. */
    memset(&session, 0, sizeof(session));
    sink_state.count = 0U;
    CHECK(gpu_trace_create(&config, &session) == GPU_TRACE_OK);
    CHECK(gpu_trace_set_sink(session, &sink) == GPU_TRACE_OK);
    CHECK(gpu_trace_start(session) == GPU_TRACE_OK);
    event = make_event(13U, "provenance");
    event.source = GPU_TRACE_SOURCE_CUPTI;
    event.correlation_domain = GPU_TRACE_CORRELATION_CUDA;
    CHECK(gpu_trace_record(session, &event) == GPU_TRACE_OK);
    CHECK(gpu_trace_flush(session) == GPU_TRACE_OK);
    CHECK(sink_state.count == 1U);
    CHECK(gpu_trace_stop(session) == GPU_TRACE_OK);
    CHECK(gpu_trace_destroy(session) == GPU_TRACE_OK);

    /* Invalid provenance is rejected when the extension fields are present. */
    memset(&session, 0, sizeof(session));
    CHECK(gpu_trace_create(&config, &session) == GPU_TRACE_OK);
    CHECK(gpu_trace_start(session) == GPU_TRACE_OK);
    event = make_event(14U, "bad-source");
    event.source = (gpu_trace_event_source_t)99;
    CHECK(gpu_trace_record(session, &event) == GPU_TRACE_ERROR_INVALID_ARGUMENT);
    event.source = GPU_TRACE_SOURCE_USER;
    event.correlation_domain = (gpu_trace_correlation_domain_t)99;
    CHECK(gpu_trace_record(session, &event) == GPU_TRACE_ERROR_INVALID_ARGUMENT);
    CHECK(gpu_trace_stop(session) == GPU_TRACE_OK);
    CHECK(gpu_trace_destroy(session) == GPU_TRACE_OK);

    /* Truncation is validated in a fresh session because stopped sessions are one-shot. */
    memset(long_name, 'x', sizeof(long_name) - 1U);
    long_name[sizeof(long_name) - 1U] = '\0';
    memset(&session, 0, sizeof(session));
    sink_state.count = 0U;
    sink_state.last_event_id = 0U;
    sink_state.last_flags = 0U;
    CHECK(gpu_trace_create(&config, &session) == GPU_TRACE_OK);
    CHECK(gpu_trace_set_sink(session, &sink) == GPU_TRACE_OK);
    CHECK(gpu_trace_start(session) == GPU_TRACE_OK);
    event = make_event(12U, long_name);
    CHECK(gpu_trace_record(session, &event) == GPU_TRACE_OK);
    CHECK(gpu_trace_flush(session) == GPU_TRACE_OK);
    CHECK(sink_state.count == 1U);
    CHECK(sink_state.last_event_id == 12U);
    CHECK((sink_state.last_flags & GPU_TRACE_FLAG_TRUNCATED_NAME) != 0U);
    CHECK(strlen(sink_state.last_name) == 63U);
    CHECK(gpu_trace_stop(session) == GPU_TRACE_OK);
    CHECK(gpu_trace_destroy(session) == GPU_TRACE_OK);


    {
        struct legacy_config {
            uint32_t size;
            uint32_t version;
            uint32_t enabled;
            uint32_t reserved0;
        } legacy;
        legacy.size = (uint32_t)sizeof(legacy);
        legacy.version = 1U;
        legacy.enabled = 1U;
        legacy.reserved0 = 0U;
        memset(&session, 0, sizeof(session));
        CHECK(gpu_trace_create((const gpu_trace_config_t *)&legacy, &session) == GPU_TRACE_OK);
        CHECK(gpu_trace_get_capacity(session) == 1024U);
        CHECK(gpu_trace_start(session) == GPU_TRACE_OK);
        CHECK(gpu_trace_stop(session) == GPU_TRACE_OK);
        CHECK(gpu_trace_destroy(session) == GPU_TRACE_OK);
    }

    memset(&session, 0, sizeof(session));
    config.enabled = 0U;
    CHECK(gpu_trace_create(&config, &session) == GPU_TRACE_OK);
    CHECK(gpu_trace_start(session) == GPU_TRACE_OK);
    event = make_event(99U, "disabled");
    CHECK(gpu_trace_record(session, &event) == GPU_TRACE_OK);
    CHECK(gpu_trace_get_recorded_count(session) == 0U);
    CHECK(gpu_trace_get_dropped_count(session) == 0U);
    CHECK(gpu_trace_stop(session) == GPU_TRACE_OK);
    CHECK(gpu_trace_destroy(session) == GPU_TRACE_OK);

    CHECK(strcmp(gpu_trace_status_string(GPU_TRACE_OK), "ok") == 0);
    CHECK(strcmp(gpu_trace_status_string(GPU_TRACE_ERROR_PENDING_EVENTS),
                "pending events") == 0);

    /* The pre-v0.1.2 event prefix remains accepted. */
    {
        gpu_trace_event_desc_t legacy_event = make_event(100U, "legacy");
        legacy_event.size = (uint32_t)offsetof(gpu_trace_event_desc_t, source);
        legacy_event.source = (gpu_trace_event_source_t)99;
        legacy_event.correlation_domain = (gpu_trace_correlation_domain_t)99;
        memset(&session, 0, sizeof(session));
        config.enabled = 1U;
        CHECK(gpu_trace_create(&config, &session) == GPU_TRACE_OK);
        CHECK(gpu_trace_set_sink(session, &sink) == GPU_TRACE_OK);
        CHECK(gpu_trace_start(session) == GPU_TRACE_OK);
        CHECK(gpu_trace_record(session, &legacy_event) == GPU_TRACE_OK);
        CHECK(gpu_trace_flush(session) == GPU_TRACE_OK);
        CHECK(gpu_trace_stop(session) == GPU_TRACE_OK);
        CHECK(gpu_trace_destroy(session) == GPU_TRACE_OK);
    }
    return 0;
}
