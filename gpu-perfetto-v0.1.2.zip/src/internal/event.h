#ifndef GPU_PERFETTO_INTERNAL_EVENT_H
#define GPU_PERFETTO_INTERNAL_EVENT_H

#include <stdint.h>
#include "gpu_perfetto/trace.h"

#define GPU_TRACE_DEFAULT_CAPACITY 1024U
#define GPU_TRACE_MIN_CAPACITY 2U
#define GPU_TRACE_MAX_NAME_LENGTH 63U

typedef struct gpu_trace_internal_event {
    uint64_t sequence;
    uint64_t event_id;
    uint64_t correlation_id;
    uint64_t device_id;
    uint64_t queue_id;
    uint64_t begin;
    uint64_t end;
    uint64_t value;
    uint32_t name_length;
    uint32_t flags;
    uint8_t source;
    uint8_t correlation_domain;
    uint8_t reserved_event0;
    uint8_t reserved_event1;
    uint8_t type;
    uint8_t begin_domain;
    uint8_t end_domain;
    uint8_t reserved0;
    uint32_t begin_resolution_ns;
    uint32_t end_resolution_ns;
    uint32_t begin_uncertainty_ns;
    uint32_t end_uncertainty_ns;
    char name[GPU_TRACE_MAX_NAME_LENGTH + 1U];
} gpu_trace_internal_event_t;

#endif
