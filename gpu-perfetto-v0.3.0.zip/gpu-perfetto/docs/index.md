# gpu-perfetto

A tiny vendor-neutral GPU tracing interoperability layer for Perfetto.

## Core principle

Instrument once, preserve native semantics, and export into the Perfetto ecosystem without creating a second tracing ecosystem.
