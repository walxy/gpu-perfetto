# Event model

The core distinguishes application annotations, GPU submissions, and actual GPU execution.

| Event | Meaning |
|---|---|
| Scope | Host-side semantic interval |
| Instant | Host-side point event |
| Submission | A GPU operation was submitted/enqueued |
| Execution | Backend-observed GPU execution interval |
| Memory | Copy/memory operation |
| Sync | Synchronization/wait |
| Counter | Numeric measurement |
| Metadata | Descriptive information |

Do not infer GPU execution duration from a host launch API call unless the backend explicitly provides that semantic guarantee.

## Thread safety

The v0.1.2 core supports multiple producer threads recording to one session and a single flush consumer. `start()`, `stop()`, and `destroy()` must still be externally serialized, and a session must not be destroyed while another thread is using it.

## Source and correlation provenance

Events may identify their source (`user`, CUDA/CUPTI, HIP/ROCm, Level Zero/SYCL, Vulkan, WebGPU, or synthetic) and the domain of the correlation ID. A correlation ID is not globally meaningful unless its domain is known. Backend adapters should preserve native IDs instead of renumbering them unnecessarily.

## Timestamp semantics

A timestamp records its clock domain, nominal resolution, and uncertainty. A host monotonic timestamp must not be treated as a GPU timestamp, and a GPU timestamp must not be converted into host time without an explicit mapping/calibration step. The core provides an affine conversion primitive; backend adapters are responsible for obtaining valid calibration samples and determining uncertainty.

GPU execution duration must come from backend-observed execution timestamps or explicit device timestamps. Host launch/submission timing is a distinct semantic event.

## Semantic invariants

The core treats these as distinct concepts:

1. A host annotation is not GPU execution.
2. Transport sequence is not execution order or causality.
3. A correlation ID is meaningful only within its declared correlation domain.
4. A device or queue ID is opaque unless its identity metadata defines how it is resolved.
5. Timestamp clock-domain values must be known enum values; timestamps may be compared across clock domains only after an explicit valid mapping exists.
6. Counter values require a declared unit when the producer has one; `unknown` is allowed when no stronger unit is available.
7. Backend capability claims must be conservative: `guaranteed` is a subset of `supported`, and `unavailable` must not overlap `supported`.

## Capability model

The capability API describes what a producer/backend can supply without implying that all capabilities are available on all machines. Capabilities include GPU execution observation, GPU timestamps, clock calibration, host/GPU correlation, device and queue identity, counters, memory operations, synchronization, multi-GPU, graph capture, and asynchronous recording.
