# Core event transport

The v0.1.2 core separates event production from event consumption and carries explicit timestamp/correlation provenance into the transport.

`gpu_trace_record()` validates and copies an event into a bounded, fixed-capacity
multi-producer queue. Normal recording performs no heap allocation. If the
queue is full, the event is dropped deterministically and
`GPU_TRACE_ERROR_BUFFER_FULL` is returned; the drop count is available through
`gpu_trace_get_dropped_count()`.

Event names are copied into the queue and capped at 63 bytes. Truncation is
reported with `GPU_TRACE_FLAG_TRUNCATED_NAME` so deferred consumers never
observe a dangling caller-owned string.

`gpu_trace_flush()` is the consumer side. It invokes the configured sink in FIFO
transport order. The sink must be configured before `gpu_trace_start()`.

This transport order is not a statement about GPU execution order. Backend
adapters must preserve native timestamp and correlation semantics rather than
turning host submission order into synthetic GPU timing.


## Lifecycle and data preservation

`gpu_trace_destroy()` does not silently discard buffered events. After stopping a
session, queued records must be flushed successfully before destruction; otherwise
`GPU_TRACE_ERROR_PENDING_EVENTS` is returned.

The core supports multiple producer threads and a single flush consumer. Callers
must externally serialize `start()`, `stop()`, and `destroy()`, and must not destroy
or concurrently reconfigure a session while another thread is using it. The sink is
configured before `start()` and remains immutable while the session is active.

## Timestamp and correlation preservation

The transport copies both timestamp metadata and event provenance. Event source and correlation-domain fields are trailing descriptor extensions, so older v0.1-sized descriptors remain valid. Native backend correlation IDs should be preserved with their domain rather than treated as globally unique integers.

The clock mapping API is deliberately outside the hot path. It represents a calibrated affine relationship between two clock domains and conservatively adds source and mapping uncertainty with saturation. The backend remains responsible for collecting calibration samples and deciding whether a mapping is valid.

## Perfetto-compatible JSON sink

The optional `gpu-perfetto-perfetto-json` sink emits Chrome Trace JSON that can be opened directly by the Perfetto UI. Perfetto documents Chrome JSON as a supported external format; timestamps are expressed in microseconds, so this sink preserves nanosecond input to three decimal places in that representation. The sink accepts only host-monotonic or explicitly calibrated timestamps because Chrome JSON does not carry a general GPU clock-domain definition. citeturn131444search0turn131444search2

The sink is intentionally not the native Perfetto protobuf SDK backend. The current Perfetto documentation recommends the C++17 SDK and its two-file amalgamation (`perfetto.h`/`perfetto.cc`) for native in-process TrackEvent instrumentation. That backend remains a separate integration target so the core package does not vendor the SDK. citeturn269560view1

For host events, set `thread_id` explicitly when the producer can provide a stable thread identifier. For GPU queue/dispatch events where `thread_id` is zero, the JSON sink uses `queue_id` as the trace lane identifier rather than pretending it is an OS thread ID.
