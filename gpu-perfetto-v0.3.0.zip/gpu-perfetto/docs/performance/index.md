# Performance

Performance claims must be measurement-backed.

The project should report at least:

- disabled-path nanoseconds/event;
- enabled-path nanoseconds/event;
- CPU cycles/event;
- allocations/event;
- bytes/event;
- memory overhead;
- trace bytes/event;
- multi-thread contention.

Do not publish fixed overhead numbers until they have been reproduced across representative compilers, optimization levels and CPUs.
