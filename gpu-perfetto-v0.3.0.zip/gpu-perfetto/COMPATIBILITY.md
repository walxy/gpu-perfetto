# Compatibility

This document distinguishes **build support** from **runtime validation**.

| Component | Status |
|---|---|
| ISO C11 core | Development target |
| C++ wrapper | Planned |
| Perfetto-compatible JSON sink | Implemented / host-clock only |
| Native Perfetto C++ SDK backend | Planned |
| CUDA/CUPTI | Adapter planned |
| HIP/ROCm | Adapter planned |
| Level Zero | Adapter planned |
| SYCL | Adapter planned |
| Vulkan | Adapter planned |
| WebGPU | Adapter planned |
| Linux | CI target |
| Windows | CI target |
| macOS | CI target |

No entry marked "planned" should be interpreted as runtime support.


## v0.2.0 development foundation

- C11 core API.
- C++17 public-header inclusion smoke-tested.
- Public structures use `size`/`version` extension semantics where explicitly documented.
- Event-source and correlation-domain fields are optional trailing extensions; callers using the v0.1.1 descriptor prefix remain valid.
- Clock mapping is a host-side utility and has no backend-specific timing guarantees.
- Real GPU/backend validation is not claimed until the corresponding adapters are implemented and tested on hardware.

## v0.3.0 Perfetto output

The v0.3 development tree provides a dependency-free Chrome Trace JSON sink. It is intended for direct opening in the Perfetto UI and Trace Processor. This is a compatibility/output path, not the native Perfetto protobuf SDK integration. The native SDK remains optional future work.

The JSON sink accepts `HOST_MONOTONIC` and `CALIBRATED` timestamps only. GPU-domain timestamps must be converted by a backend before being passed to this sink.
