#ifndef GPU_PERFETTO_CLOCK_H
#define GPU_PERFETTO_CLOCK_H

#include <stdint.h>
#include "gpu_perfetto/status.h"
#include "gpu_perfetto/timestamp.h"

#ifdef __cplusplus
extern "C" {
#endif

/*
 * Describes an affine mapping from a source clock domain into a destination
 * clock domain:
 *
 *   destination = destination_origin +
 *                 (source - source_origin) * numerator / denominator
 *
 * The mapping is intended for calibration/conversion outside the event hot
 * path. numerator and denominator must be non-zero.
 */
typedef struct gpu_trace_clock_mapping {
    uint32_t size;
    uint32_t version;
    gpu_trace_clock_domain_t source_domain;
    gpu_trace_clock_domain_t destination_domain;
    uint64_t source_origin;
    uint64_t destination_origin;
    uint64_t numerator;
    uint64_t denominator;
    uint32_t uncertainty_ns;
    uint32_t reserved0;
} gpu_trace_clock_mapping_t;

/* Validate mapping metadata without modifying it. */
gpu_trace_status_t gpu_trace_clock_mapping_validate(
    const gpu_trace_clock_mapping_t *mapping);

/* Convert a timestamp using an affine clock mapping. */
gpu_trace_status_t gpu_trace_clock_convert(
    const gpu_trace_clock_mapping_t *mapping,
    const gpu_trace_timestamp_t *source,
    gpu_trace_timestamp_t *destination);

#ifdef __cplusplus
}
#endif

#endif
