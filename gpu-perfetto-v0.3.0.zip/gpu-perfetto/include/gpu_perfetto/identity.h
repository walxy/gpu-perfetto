#ifndef GPU_PERFETTO_IDENTITY_H
#define GPU_PERFETTO_IDENTITY_H

#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

typedef enum gpu_trace_event_source {
    GPU_TRACE_SOURCE_USER = 0,
    GPU_TRACE_SOURCE_CUDA = 1,
    GPU_TRACE_SOURCE_CUPTI = 2,
    GPU_TRACE_SOURCE_HIP = 3,
    GPU_TRACE_SOURCE_ROCPROFILER = 4,
    GPU_TRACE_SOURCE_LEVEL_ZERO = 5,
    GPU_TRACE_SOURCE_SYCL = 6,
    GPU_TRACE_SOURCE_VULKAN = 7,
    GPU_TRACE_SOURCE_WEBGPU = 8,
    GPU_TRACE_SOURCE_SYNTHETIC = 9
} gpu_trace_event_source_t;

typedef enum gpu_trace_correlation_domain {
    GPU_TRACE_CORRELATION_NONE = 0,
    GPU_TRACE_CORRELATION_LOCAL = 1,
    GPU_TRACE_CORRELATION_CUDA = 2,
    GPU_TRACE_CORRELATION_ROCM = 3,
    GPU_TRACE_CORRELATION_LEVEL_ZERO = 4,
    GPU_TRACE_CORRELATION_VULKAN = 5,
    GPU_TRACE_CORRELATION_WEBGPU = 6,
    GPU_TRACE_CORRELATION_USER = 7
} gpu_trace_correlation_domain_t;

/* Stable identity kinds for future device/queue metadata. */
typedef enum gpu_trace_identity_kind {
    GPU_TRACE_IDENTITY_UNKNOWN = 0,
    GPU_TRACE_IDENTITY_ORDINAL = 1,
    GPU_TRACE_IDENTITY_UUID = 2,
    GPU_TRACE_IDENTITY_NATIVE = 3
} gpu_trace_identity_kind_t;

#ifdef __cplusplus
}
#endif

#endif
