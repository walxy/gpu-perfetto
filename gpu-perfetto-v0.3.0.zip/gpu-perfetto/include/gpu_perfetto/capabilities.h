#ifndef GPU_PERFETTO_CAPABILITIES_H
#define GPU_PERFETTO_CAPABILITIES_H

#include <stdint.h>
#include "gpu_perfetto/status.h"

#ifdef __cplusplus
extern "C" {
#endif

typedef enum gpu_trace_capability {
    GPU_TRACE_CAP_HOST_EVENTS = 0,
    GPU_TRACE_CAP_GPU_EXECUTION = 1,
    GPU_TRACE_CAP_GPU_TIMESTAMPS = 2,
    GPU_TRACE_CAP_CLOCK_CALIBRATION = 3,
    GPU_TRACE_CAP_HOST_GPU_CORRELATION = 4,
    GPU_TRACE_CAP_DEVICE_IDENTITY = 5,
    GPU_TRACE_CAP_QUEUE_IDENTITY = 6,
    GPU_TRACE_CAP_COUNTERS = 7,
    GPU_TRACE_CAP_MEMORY = 8,
    GPU_TRACE_CAP_SYNCHRONIZATION = 9,
    GPU_TRACE_CAP_MULTI_GPU = 10,
    GPU_TRACE_CAP_GRAPH_CAPTURE = 11,
    GPU_TRACE_CAP_ASYNC_RECORDING = 12
} gpu_trace_capability_t;

typedef uint64_t gpu_trace_capability_mask_t;

#define GPU_TRACE_CAPABILITY_BIT(capability) \
    (UINT64_C(1) << (uint32_t)(capability))

typedef struct gpu_trace_capabilities {
    uint32_t size;
    uint32_t version;
    gpu_trace_capability_mask_t supported;
    gpu_trace_capability_mask_t guaranteed;
    gpu_trace_capability_mask_t unavailable;
    uint32_t reserved0;
    uint32_t reserved1;
} gpu_trace_capabilities_t;

/* Validate capability metadata and ensure masks are mutually consistent. */
gpu_trace_status_t gpu_trace_capabilities_validate(
    const gpu_trace_capabilities_t *capabilities);

/* Return a conservative mask containing every capability enumerated by this API. */
gpu_trace_capability_mask_t gpu_trace_capability_all(void);

#ifdef __cplusplus
}
#endif

#endif
