#ifndef GPU_PERFETTO_STATUS_H
#define GPU_PERFETTO_STATUS_H

#ifdef __cplusplus
extern "C" {
#endif

typedef enum gpu_trace_status {
    GPU_TRACE_OK = 0,
    GPU_TRACE_ERROR_INVALID_ARGUMENT = 1,
    GPU_TRACE_ERROR_NOT_INITIALIZED = 2,
    GPU_TRACE_ERROR_ALREADY_STARTED = 3,
    GPU_TRACE_ERROR_UNSUPPORTED = 4,
    GPU_TRACE_ERROR_BACKEND_UNAVAILABLE = 5,
    GPU_TRACE_ERROR_NO_MEMORY = 6,
    GPU_TRACE_ERROR_BUFFER_FULL = 7,
    GPU_TRACE_ERROR_INTERNAL = 8,
    GPU_TRACE_ERROR_PENDING_EVENTS = 9
} gpu_trace_status_t;

const char *gpu_trace_status_string(gpu_trace_status_t status);

#ifdef __cplusplus
}
#endif

#endif
