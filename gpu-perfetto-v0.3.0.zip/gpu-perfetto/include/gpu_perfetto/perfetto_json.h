#ifndef GPU_PERFETTO_PERFETTO_JSON_H
#define GPU_PERFETTO_PERFETTO_JSON_H

#include <stdio.h>
#include <stdint.h>

#include "gpu_perfetto/status.h"
#include "gpu_perfetto/trace.h"

#ifdef __cplusplus
extern "C" {
#endif

typedef struct gpu_trace_perfetto_json_sink {
    uint32_t size;
    uint32_t version;
    FILE *file;
    uint32_t owns_file;
    uint32_t started;
    uint32_t finished;
    uint32_t first_event;
    uint32_t io_error;
    uint64_t process_id;
    gpu_trace_sink_t interface;
} gpu_trace_perfetto_json_sink_t;

/* Initialize a sink around an already-open binary/text stream. */
gpu_trace_status_t gpu_trace_perfetto_json_sink_init(
    gpu_trace_perfetto_json_sink_t *sink,
    FILE *file);

/* Set the process identifier written to Chrome JSON pid fields. */
gpu_trace_status_t gpu_trace_perfetto_json_sink_set_process_id(
    gpu_trace_perfetto_json_sink_t *sink,
    uint64_t process_id);

/* Return the generic sink interface used with gpu_trace_set_sink(). */
const gpu_trace_sink_t *gpu_trace_perfetto_json_sink_get_sink(
    const gpu_trace_perfetto_json_sink_t *sink);

/* Finalize the JSON document. Must be called after the trace has been flushed. */
gpu_trace_status_t gpu_trace_perfetto_json_sink_finalize(
    gpu_trace_perfetto_json_sink_t *sink);

#ifdef __cplusplus
}
#endif

#endif
