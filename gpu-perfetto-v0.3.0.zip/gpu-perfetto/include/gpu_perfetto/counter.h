#ifndef GPU_PERFETTO_COUNTER_H
#define GPU_PERFETTO_COUNTER_H

#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

typedef enum gpu_trace_counter_unit {
    GPU_TRACE_COUNTER_UNIT_UNKNOWN = 0,
    GPU_TRACE_COUNTER_UNIT_COUNT = 1,
    GPU_TRACE_COUNTER_UNIT_BYTES = 2,
    GPU_TRACE_COUNTER_UNIT_NANOSECONDS = 3,
    GPU_TRACE_COUNTER_UNIT_HERTZ = 4,
    GPU_TRACE_COUNTER_UNIT_PERCENT = 5
} gpu_trace_counter_unit_t;

#ifdef __cplusplus
}
#endif

#endif
