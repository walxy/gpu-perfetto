from pathlib import Path

required = [
    "LICENSE",
    "NOTICE",
    "README.md",
    "CHANGELOG.md",
    "COMPATIBILITY.md",
    "LICENSES.md",
]
missing = [p for p in required if not Path(p).is_file()]
if missing:
    raise SystemExit(f"Missing release files: {', '.join(missing)}")
print("Release metadata check passed.")
