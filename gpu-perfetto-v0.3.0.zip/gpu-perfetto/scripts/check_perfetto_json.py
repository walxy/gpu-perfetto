#!/usr/bin/env python3
import json
import sys
from pathlib import Path

if len(sys.argv) != 2:
    raise SystemExit("usage: check_perfetto_json.py TRACE.json")

path = Path(sys.argv[1])
data = json.loads(path.read_text(encoding="utf-8"))
if data.get("displayTimeUnit") != "us":
    raise SystemExit("displayTimeUnit must be us")
events = data.get("traceEvents")
if not isinstance(events, list) or len(events) != 3:
    raise SystemExit("expected exactly 3 trace events")
expected_phases = ["X", "i", "C"]
actual_phases = [event.get("ph") for event in events]
if actual_phases != expected_phases:
    raise SystemExit(f"unexpected phases: {actual_phases!r}")
if events[0].get("name") != 'matmul"quoted':
    raise SystemExit("JSON string escaping/name mismatch")
if events[0].get("tid") != 11:
    raise SystemExit("thread id mismatch")
if events[0].get("args", {}).get("event_type") != "scope":
    raise SystemExit("scope metadata missing")
print(f"validated {path} ({len(events)} events)")
