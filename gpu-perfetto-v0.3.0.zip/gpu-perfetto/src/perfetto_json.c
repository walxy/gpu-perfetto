#include "gpu_perfetto/perfetto_json.h"

#include <string.h>

static int valid_sink(const gpu_trace_perfetto_json_sink_t *sink) {
    return sink != NULL && sink->size >= (uint32_t)sizeof(*sink) &&
           sink->version == 1U && sink->file != NULL;
}

static int write_all(FILE *file, const char *text) {
    const size_t length = strlen(text);
    return fwrite(text, 1U, length, file) == length;
}

static int write_json_string(FILE *file, const char *text) {
    const unsigned char *p = (const unsigned char *)(text != NULL ? text : "");
    if (fputc('"', file) == EOF) {
        return 0;
    }
    while (*p != '\0') {
        switch (*p) {
            case '"':
                if (!write_all(file, "\\\"")) return 0;
                break;
            case '\\':
                if (!write_all(file, "\\\\")) return 0;
                break;
            case '\b':
                if (!write_all(file, "\\b")) return 0;
                break;
            case '\f':
                if (!write_all(file, "\\f")) return 0;
                break;
            case '\n':
                if (!write_all(file, "\\n")) return 0;
                break;
            case '\r':
                if (!write_all(file, "\\r")) return 0;
                break;
            case '\t':
                if (!write_all(file, "\\t")) return 0;
                break;
            default:
                if (*p < 0x20U) {
                    if (fprintf(file, "\\u%04x", (unsigned int)*p) < 0) {
                        return 0;
                    }
                } else if (fputc((int)*p, file) == EOF) {
                    return 0;
                }
                break;
        }
        ++p;
    }
    return fputc('"', file) != EOF;
}

static int timestamp_valid(const gpu_trace_timestamp_t *ts) {
    return ts != NULL &&
           (ts->domain == GPU_TRACE_CLOCK_HOST_MONOTONIC ||
            ts->domain == GPU_TRACE_CLOCK_CALIBRATED);
}

static int write_timestamp_us(FILE *file, uint64_t value_ns) {
    const uint64_t whole_us = value_ns / UINT64_C(1000);
    const uint64_t remainder_ns = value_ns % UINT64_C(1000);
    return fprintf(file, "%llu.%03llu",
                   (unsigned long long)whole_us,
                   (unsigned long long)remainder_ns) >= 0;
}

static const char *event_type_name(gpu_trace_event_type_t type) {
    switch (type) {
        case GPU_TRACE_EVENT_SCOPE: return "scope";
        case GPU_TRACE_EVENT_INSTANT: return "instant";
        case GPU_TRACE_EVENT_COUNTER: return "counter";
        case GPU_TRACE_EVENT_SUBMISSION: return "submission";
        case GPU_TRACE_EVENT_EXECUTION: return "execution";
        case GPU_TRACE_EVENT_MEMORY: return "memory";
        case GPU_TRACE_EVENT_SYNC: return "sync";
        case GPU_TRACE_EVENT_METADATA: return "metadata";
        default: return "unknown";
    }
}

static int write_args(FILE *file, const gpu_trace_event_desc_t *event) {
    if (fprintf(file,
                "\"event_id\":%llu,\"correlation_id\":%llu,"
                "\"device_id\":%llu,\"queue_id\":%llu,"
                "\"thread_id\":%llu,\"value\":%llu,\"flags\":%u,"
                "\"source\":%u,\"correlation_domain\":%u,"
                "\"counter_unit\":%u,\"event_type\":",
                (unsigned long long)event->event_id,
                (unsigned long long)event->correlation_id,
                (unsigned long long)event->device_id,
                (unsigned long long)event->queue_id,
                (unsigned long long)event->thread_id,
                (unsigned long long)event->value,
                (unsigned int)event->flags,
                (unsigned int)event->source,
                (unsigned int)event->correlation_domain,
                (unsigned int)event->counter_unit) < 0) {
        return 0;
    }
    return write_json_string(file, event_type_name(event->type));
}

static gpu_trace_status_t sink_emit(void *user_data,
                                    const gpu_trace_event_desc_t *event) {
    gpu_trace_perfetto_json_sink_t *sink =
        (gpu_trace_perfetto_json_sink_t *)user_data;
    uint64_t tid;
    const char *phase;

    if (!valid_sink(sink) || event == NULL || sink->finished != 0U ||
        sink->io_error != 0U) {
        return sink->io_error != 0U ? GPU_TRACE_ERROR_INTERNAL
                                    : GPU_TRACE_ERROR_INVALID_ARGUMENT;
    }
    if (!timestamp_valid(&event->begin) ||
        ((event->type == GPU_TRACE_EVENT_SCOPE ||
          event->type == GPU_TRACE_EVENT_SUBMISSION ||
          event->type == GPU_TRACE_EVENT_EXECUTION ||
          event->type == GPU_TRACE_EVENT_MEMORY) &&
         !timestamp_valid(&event->end))) {
        return GPU_TRACE_ERROR_UNSUPPORTED;
    }
    if (sink->started == 0U) {
        if (!write_all(sink->file,
                       "{\"displayTimeUnit\":\"us\",\"traceEvents\":[")) {
            sink->io_error = 1U;
            return GPU_TRACE_ERROR_INTERNAL;
        }
        sink->started = 1U;
    }

    tid = event->thread_id != 0U ? event->thread_id : event->queue_id;
    switch (event->type) {
        case GPU_TRACE_EVENT_SCOPE:
        case GPU_TRACE_EVENT_SUBMISSION:
        case GPU_TRACE_EVENT_EXECUTION:
        case GPU_TRACE_EVENT_MEMORY:
            phase = "X";
            break;
        case GPU_TRACE_EVENT_COUNTER:
            phase = "C";
            break;
        case GPU_TRACE_EVENT_INSTANT:
        case GPU_TRACE_EVENT_SYNC:
        case GPU_TRACE_EVENT_METADATA:
        default:
            phase = "i";
            break;
    }

    if (sink->first_event == 0U) {
        sink->first_event = 1U;
    } else if (fputc(',', sink->file) == EOF) {
        sink->io_error = 1U;
        return GPU_TRACE_ERROR_INTERNAL;
    }

    if (fprintf(sink->file, "{\"name\":") < 0 ||
        !write_json_string(sink->file, event->name != NULL ? event->name : "") ||
        fprintf(sink->file, ",\"cat\":\"gpu-perfetto\",\"ph\":\"%s\","
                         "\"pid\":%llu,\"tid\":%llu",
                phase,
                (unsigned long long)sink->process_id,
                (unsigned long long)tid) < 0) {
        sink->io_error = 1U;
        return GPU_TRACE_ERROR_INTERNAL;
    }

    if (event->type == GPU_TRACE_EVENT_COUNTER) {
        if (write_all(sink->file, ",\"ts\":") == 0 ||
            !write_timestamp_us(sink->file, event->begin.value) ||
            write_all(sink->file, ",\"args\":{" ) == 0 ||
            !write_json_string(sink->file,
                               event->name != NULL ? event->name : "value") ||
            fprintf(sink->file, ":%llu}", (unsigned long long)event->value) < 0) {
            sink->io_error = 1U;
            return GPU_TRACE_ERROR_INTERNAL;
        }
    } else {
        if (write_all(sink->file, ",\"ts\":") == 0 ||
            !write_timestamp_us(sink->file, event->begin.value)) {
            sink->io_error = 1U;
            return GPU_TRACE_ERROR_INTERNAL;
        }
        if (phase[0] == 'X') {
            const uint64_t duration = event->end.value >= event->begin.value
                                          ? event->end.value - event->begin.value
                                          : 0U;
            if (write_all(sink->file, ",\"dur\":") == 0 ||
                !write_timestamp_us(sink->file, duration)) {
                sink->io_error = 1U;
                return GPU_TRACE_ERROR_INTERNAL;
            }
        } else if (phase[0] == 'i') {
            if (!write_all(sink->file, ",\"s\":\"t\"")) {
                sink->io_error = 1U;
                return GPU_TRACE_ERROR_INTERNAL;
            }
        }
        if (write_all(sink->file, ",\"args\":{" ) == 0 ||
            !write_args(sink->file, event) ||
            fputc('}', sink->file) == EOF) {
            sink->io_error = 1U;
            return GPU_TRACE_ERROR_INTERNAL;
        }
    }

    if (fputc('}', sink->file) == EOF) {
        sink->io_error = 1U;
        return GPU_TRACE_ERROR_INTERNAL;
    }
    return GPU_TRACE_OK;
}

gpu_trace_status_t gpu_trace_perfetto_json_sink_init(
    gpu_trace_perfetto_json_sink_t *sink,
    FILE *file) {
    if (sink == NULL || file == NULL) {
        return GPU_TRACE_ERROR_INVALID_ARGUMENT;
    }
    memset(sink, 0, sizeof(*sink));
    sink->size = (uint32_t)sizeof(*sink);
    sink->version = 1U;
    sink->file = file;
    sink->process_id = 1U;
    sink->interface.size = (uint32_t)sizeof(sink->interface);
    sink->interface.version = 1U;
    sink->interface.emit = sink_emit;
    sink->interface.user_data = sink;
    return GPU_TRACE_OK;
}

gpu_trace_status_t gpu_trace_perfetto_json_sink_set_process_id(
    gpu_trace_perfetto_json_sink_t *sink,
    uint64_t process_id) {
    if (!valid_sink(sink) || process_id == 0U) {
        return GPU_TRACE_ERROR_INVALID_ARGUMENT;
    }
    if (sink->started != 0U || sink->finished != 0U) {
        return GPU_TRACE_ERROR_ALREADY_STARTED;
    }
    sink->process_id = process_id;
    return GPU_TRACE_OK;
}

const gpu_trace_sink_t *gpu_trace_perfetto_json_sink_get_sink(
    const gpu_trace_perfetto_json_sink_t *sink) {
    if (!valid_sink(sink)) {
        return NULL;
    }
    return &sink->interface;
}

gpu_trace_status_t gpu_trace_perfetto_json_sink_finalize(
    gpu_trace_perfetto_json_sink_t *sink) {
    if (!valid_sink(sink)) {
        return GPU_TRACE_ERROR_INVALID_ARGUMENT;
    }
    if (sink->finished != 0U) {
        return GPU_TRACE_OK;
    }
    if (sink->io_error != 0U) {
        return GPU_TRACE_ERROR_INTERNAL;
    }
    if (sink->started == 0U) {
        if (!write_all(sink->file, "{\"displayTimeUnit\":\"us\",\"traceEvents\":[]}")) {
            return GPU_TRACE_ERROR_INTERNAL;
        }
    } else {
        if (!write_all(sink->file, "]}")) {
            return GPU_TRACE_ERROR_INTERNAL;
        }
    }
    if (fflush(sink->file) != 0) {
        return GPU_TRACE_ERROR_INTERNAL;
    }
    sink->finished = 1U;
    return GPU_TRACE_OK;
}
