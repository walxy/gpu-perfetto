#ifndef GPU_PERFETTO_INTERNAL_RING_H
#define GPU_PERFETTO_INTERNAL_RING_H

#include <stdatomic.h>
#include <stddef.h>
#include <stdint.h>
#include "src/internal/event.h"

typedef struct gpu_trace_ring_slot {
    _Atomic uint64_t sequence;
    gpu_trace_internal_event_t event;
} gpu_trace_ring_slot_t;

typedef struct gpu_trace_ring {
    gpu_trace_ring_slot_t *slots;
    uint32_t capacity;
    uint32_t mask;
    _Atomic uint64_t enqueue_pos;
    _Atomic uint64_t dequeue_pos;
} gpu_trace_ring_t;

int gpu_trace_ring_init(gpu_trace_ring_t *ring, uint32_t capacity);
void gpu_trace_ring_destroy(gpu_trace_ring_t *ring);
int gpu_trace_ring_try_push(gpu_trace_ring_t *ring,
                            const gpu_trace_internal_event_t *event);
int gpu_trace_ring_try_peek(const gpu_trace_ring_t *ring,
                            gpu_trace_internal_event_t *event);
void gpu_trace_ring_consume(gpu_trace_ring_t *ring);
uint32_t gpu_trace_ring_capacity(const gpu_trace_ring_t *ring);

#endif
