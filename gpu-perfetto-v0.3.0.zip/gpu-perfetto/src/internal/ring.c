#include "src/internal/ring.h"

#include <stdlib.h>

static int power_of_two(uint32_t value) {
    return value >= 2U && (value & (value - 1U)) == 0U;
}

int gpu_trace_ring_init(gpu_trace_ring_t *ring, uint32_t capacity) {
    uint32_t i;
    if (ring == NULL || !power_of_two(capacity)) {
        return 0;
    }

    ring->slots = (gpu_trace_ring_slot_t *)calloc((size_t)capacity,
                                                   sizeof(*ring->slots));
    if (ring->slots == NULL) {
        return 0;
    }

    ring->capacity = capacity;
    ring->mask = capacity - 1U;
    atomic_init(&ring->enqueue_pos, 0U);
    atomic_init(&ring->dequeue_pos, 0U);

    for (i = 0U; i < capacity; ++i) {
        atomic_init(&ring->slots[i].sequence, (uint64_t)i);
    }
    return 1;
}

void gpu_trace_ring_destroy(gpu_trace_ring_t *ring) {
    if (ring == NULL) {
        return;
    }
    free(ring->slots);
    ring->slots = NULL;
    ring->capacity = 0U;
    ring->mask = 0U;
}

int gpu_trace_ring_try_push(gpu_trace_ring_t *ring,
                            const gpu_trace_internal_event_t *event) {
    uint64_t pos;
    gpu_trace_ring_slot_t *slot;

    if (ring == NULL || event == NULL) {
        return 0;
    }

    pos = atomic_load_explicit(&ring->enqueue_pos, memory_order_relaxed);
    for (;;) {
        uint64_t sequence;
        int64_t difference;

        slot = &ring->slots[(uint32_t)(pos & (uint64_t)ring->mask)];
        sequence = atomic_load_explicit(&slot->sequence, memory_order_acquire);
        difference = (int64_t)(sequence - pos);

        if (difference == 0) {
            if (atomic_compare_exchange_weak_explicit(
                    &ring->enqueue_pos, &pos, pos + 1U,
                    memory_order_relaxed, memory_order_relaxed)) {
                break;
            }
        } else if (difference < 0) {
            return 0;
        } else {
            pos = atomic_load_explicit(&ring->enqueue_pos, memory_order_relaxed);
        }
    }

    slot->event = *event;
    slot->event.sequence = pos;
    atomic_store_explicit(&slot->sequence, pos + 1U, memory_order_release);
    return 1;
}

int gpu_trace_ring_try_peek(const gpu_trace_ring_t *ring,
                            gpu_trace_internal_event_t *event) {
    uint64_t pos;
    const gpu_trace_ring_slot_t *slot;

    if (ring == NULL || event == NULL) {
        return 0;
    }

    pos = atomic_load_explicit(&ring->dequeue_pos, memory_order_relaxed);
    slot = &ring->slots[(uint32_t)(pos & (uint64_t)ring->mask)];

    if (atomic_load_explicit(&slot->sequence, memory_order_acquire) != pos + 1U) {
        return 0;
    }

    *event = slot->event;
    return 1;
}

void gpu_trace_ring_consume(gpu_trace_ring_t *ring) {
    uint64_t pos;
    gpu_trace_ring_slot_t *slot;

    if (ring == NULL) {
        return;
    }

    pos = atomic_load_explicit(&ring->dequeue_pos, memory_order_relaxed);
    slot = &ring->slots[(uint32_t)(pos & (uint64_t)ring->mask)];

    if (atomic_load_explicit(&slot->sequence, memory_order_acquire) != pos + 1U) {
        return;
    }

    atomic_store_explicit(&slot->sequence,
                          pos + (uint64_t)ring->capacity,
                          memory_order_release);
    atomic_store_explicit(&ring->dequeue_pos, pos + 1U, memory_order_relaxed);
}

uint32_t gpu_trace_ring_capacity(const gpu_trace_ring_t *ring) {
    return ring != NULL ? ring->capacity : 0U;
}
