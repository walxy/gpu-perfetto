#ifndef GPU_PERFETTO_INTERNAL_SESSION_H
#define GPU_PERFETTO_INTERNAL_SESSION_H

#include <stdatomic.h>
#include <stdint.h>
#include "src/internal/ring.h"
#include "gpu_perfetto/trace.h"

typedef enum gpu_trace_session_state {
    GPU_TRACE_STATE_CREATED = 0,
    GPU_TRACE_STATE_RUNNING = 1,
    GPU_TRACE_STATE_STOPPED = 2
} gpu_trace_session_state_t;

struct gpu_trace_session {
    gpu_trace_config_t config;
    _Atomic uint32_t state;
    _Atomic uint64_t recorded_count;
    _Atomic uint64_t flushed_count;
    _Atomic uint64_t dropped_count;
    gpu_trace_ring_t ring;
    gpu_trace_sink_t sink;
    uint32_t has_sink;
};

#endif
