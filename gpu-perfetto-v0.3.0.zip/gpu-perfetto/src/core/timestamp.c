#include "gpu_perfetto/clock.h"

#include <stddef.h>
#include <stdint.h>

static int clock_domain_valid(gpu_trace_clock_domain_t domain) {
    switch (domain) {
        case GPU_TRACE_CLOCK_HOST_MONOTONIC:
        case GPU_TRACE_CLOCK_GPU:
        case GPU_TRACE_CLOCK_CALIBRATED:
        case GPU_TRACE_CLOCK_UNKNOWN:
            return 1;
        default:
            return 0;
    }
}

/*
 * Compute floor(a * b / divisor) without floating point or compiler-specific
 * integer extensions. The 128-bit product is represented as four 32-bit limbs;
 * binary long division then produces a 64-bit quotient and detects overflow.
 * This function is intentionally for calibration/conversion paths, not the
 * event-recording hot path.
 */
static int mul_div_u64(uint64_t a, uint64_t b, uint64_t divisor,
                       uint64_t *out) {
    uint64_t p0;
    uint64_t p1;
    uint64_t p2;
    uint64_t p3;
    uint32_t limbs[4];
    uint64_t remainder = 0U;
    uint64_t quotient = 0U;
    uint64_t half;
    uint32_t bit_index;

    if (divisor == 0U || out == NULL) {
        return 0;
    }

    p0 = (a & UINT64_C(0xffffffff)) * (b & UINT64_C(0xffffffff));
    p1 = (a & UINT64_C(0xffffffff)) * (b >> 32U);
    p2 = (a >> 32U) * (b & UINT64_C(0xffffffff));
    p3 = (a >> 32U) * (b >> 32U);

    {
        uint64_t carry;
        uint64_t middle;

        limbs[0] = (uint32_t)p0;
        carry = p0 >> 32U;
        middle = carry + (p1 & UINT64_C(0xffffffff)) +
                 (p2 & UINT64_C(0xffffffff));
        limbs[1] = (uint32_t)middle;
        carry = middle >> 32U;
        middle = (p1 >> 32U) + (p2 >> 32U) +
                 (p3 & UINT64_C(0xffffffff)) + carry;
        limbs[2] = (uint32_t)middle;
        carry = middle >> 32U;
        if ((p3 >> 32U) > UINT64_C(0xffffffff) - carry) {
            return 0;
        }
        limbs[3] = (uint32_t)((p3 >> 32U) + carry);
    }

    /* floor(divisor / 2), used with the incoming bit to avoid overflow. */
    half = divisor / 2U;

    for (bit_index = 128U; bit_index != 0U; --bit_index) {
        uint32_t source_bit_index = bit_index - 1U;
        uint32_t limb_index = source_bit_index / 32U;
        uint32_t limb_bit = source_bit_index % 32U;
        uint64_t bit = (uint64_t)((limbs[limb_index] >> limb_bit) & 1U);
        uint64_t quotient_bit = 0U;

        if (remainder > half ||
            (remainder == half &&
             (((divisor & 1U) == 0U) || bit != 0U))) {
            /* remainder*2 + bit - divisor, evaluated without overflow. */
            remainder = remainder - (divisor - remainder) + bit;
            quotient_bit = 1U;
        } else {
            remainder = remainder * 2U + bit;
        }

        if (source_bit_index >= 64U) {
            if (quotient_bit != 0U) {
                return 0;
            }
        } else {
            quotient = (quotient << 1U) | quotient_bit;
        }
    }

    *out = quotient;
    return 1;
}

gpu_trace_status_t gpu_trace_clock_mapping_validate(
    const gpu_trace_clock_mapping_t *mapping) {
    if (mapping == NULL ||
        mapping->size < (uint32_t)offsetof(gpu_trace_clock_mapping_t,
                                          uncertainty_ns) +
                           (uint32_t)sizeof(mapping->uncertainty_ns) ||
        mapping->version != 1U ||
        !clock_domain_valid(mapping->source_domain) ||
        !clock_domain_valid(mapping->destination_domain) ||
        mapping->numerator == 0U ||
        mapping->denominator == 0U) {
        return GPU_TRACE_ERROR_INVALID_ARGUMENT;
    }
    return GPU_TRACE_OK;
}

gpu_trace_status_t gpu_trace_clock_convert(
    const gpu_trace_clock_mapping_t *mapping,
    const gpu_trace_timestamp_t *source,
    gpu_trace_timestamp_t *destination) {
    uint64_t delta;
    uint64_t scaled;

    if (gpu_trace_clock_mapping_validate(mapping) != GPU_TRACE_OK ||
        source == NULL || destination == NULL) {
        return GPU_TRACE_ERROR_INVALID_ARGUMENT;
    }
    if (source->domain != mapping->source_domain) {
        return GPU_TRACE_ERROR_INVALID_ARGUMENT;
    }
    if (source->value < mapping->source_origin) {
        return GPU_TRACE_ERROR_INVALID_ARGUMENT;
    }

    delta = source->value - mapping->source_origin;
    if (!mul_div_u64(delta, mapping->numerator, mapping->denominator,
                     &scaled) ||
        scaled > UINT64_MAX - mapping->destination_origin) {
        return GPU_TRACE_ERROR_INTERNAL;
    }

    destination->value = mapping->destination_origin + scaled;
    destination->domain = mapping->destination_domain;
    destination->resolution_ns = source->resolution_ns;
    if (mapping->uncertainty_ns > UINT32_MAX - source->uncertainty_ns) {
        destination->uncertainty_ns = UINT32_MAX;
    } else {
        destination->uncertainty_ns =
            source->uncertainty_ns + mapping->uncertainty_ns;
    }
    return GPU_TRACE_OK;
}
