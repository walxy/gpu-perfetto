#include "gpu_perfetto/capabilities.h"

#include <stddef.h>

static gpu_trace_capability_mask_t capability_all_mask(void) {
    return (GPU_TRACE_CAPABILITY_BIT(GPU_TRACE_CAP_HOST_EVENTS) |
            GPU_TRACE_CAPABILITY_BIT(GPU_TRACE_CAP_GPU_EXECUTION) |
            GPU_TRACE_CAPABILITY_BIT(GPU_TRACE_CAP_GPU_TIMESTAMPS) |
            GPU_TRACE_CAPABILITY_BIT(GPU_TRACE_CAP_CLOCK_CALIBRATION) |
            GPU_TRACE_CAPABILITY_BIT(GPU_TRACE_CAP_HOST_GPU_CORRELATION) |
            GPU_TRACE_CAPABILITY_BIT(GPU_TRACE_CAP_DEVICE_IDENTITY) |
            GPU_TRACE_CAPABILITY_BIT(GPU_TRACE_CAP_QUEUE_IDENTITY) |
            GPU_TRACE_CAPABILITY_BIT(GPU_TRACE_CAP_COUNTERS) |
            GPU_TRACE_CAPABILITY_BIT(GPU_TRACE_CAP_MEMORY) |
            GPU_TRACE_CAPABILITY_BIT(GPU_TRACE_CAP_SYNCHRONIZATION) |
            GPU_TRACE_CAPABILITY_BIT(GPU_TRACE_CAP_MULTI_GPU) |
            GPU_TRACE_CAPABILITY_BIT(GPU_TRACE_CAP_GRAPH_CAPTURE) |
            GPU_TRACE_CAPABILITY_BIT(GPU_TRACE_CAP_ASYNC_RECORDING));
}

gpu_trace_status_t gpu_trace_capabilities_validate(
    const gpu_trace_capabilities_t *capabilities) {
    gpu_trace_capability_mask_t all;

    const uint32_t required_size =
        (uint32_t)offsetof(gpu_trace_capabilities_t, unavailable) +
        (uint32_t)sizeof(capabilities->unavailable);

    if (capabilities == NULL ||
        capabilities->size < required_size ||
        capabilities->version != 1U) {
        return GPU_TRACE_ERROR_INVALID_ARGUMENT;
    }

    all = capability_all_mask();
    if ((capabilities->supported & ~all) != 0U ||
        (capabilities->guaranteed & ~capabilities->supported) != 0U ||
        (capabilities->unavailable & ~all) != 0U ||
        (capabilities->unavailable & capabilities->supported) != 0U) {
        return GPU_TRACE_ERROR_INVALID_ARGUMENT;
    }
    return GPU_TRACE_OK;
}

gpu_trace_capability_mask_t gpu_trace_capability_all(void) {
    return capability_all_mask();
}
