# Contributing

Changes should preserve:

1. public ABI stability rules;
2. explicit timestamp semantics;
3. backend isolation;
4. no unnecessary hot-path allocation or blocking;
5. tests for observable behavior.

Do not add a third-party dependency to the core without a documented justification.
