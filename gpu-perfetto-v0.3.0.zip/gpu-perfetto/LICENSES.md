# Third-party licenses

The v0.1.0 baseline does not vendor third-party runtime libraries.

Optional backend dependencies must retain their upstream license terms and should be discovered from installed SDKs rather than copied into the core library.
