## [0.3.0] - Development

### Added
- Perfetto-compatible Chrome Trace JSON sink with bounded core integration.
- Explicit optional producer `thread_id` event metadata for trace track attribution.
- JSON sink documentation and unit/integration coverage.

### Changed
- Project version advanced to 0.3.0 development.
- Perfetto output scope is dependency-free JSON import rather than a vendored native SDK.

### Compatibility
- Existing event/config size-prefix extension semantics remain compatible.

## [0.2.0] - Development

### Added
- Formal semantic capability mask and validation API.
- Counter-unit metadata for trace events.
- Semantic invariants documenting host/GPU timing, ordering, correlation, identity, and capability rules.
- Capability API test coverage, including backward-compatible size-prefix validation.

### Changed
- Versioned public umbrella header and CMake project version advanced to 0.2.0 development.
- Event descriptor extension semantics now include an optional trailing counter-unit field.

### Compatibility
- Existing v0.1.x event/config prefixes remain accepted through size/version validation.

# Changelog

## [0.1.2] - Development

### Added
- Explicit event source provenance and correlation-domain metadata.
- Affine clock-mapping validation and timestamp conversion primitives.
- Clock uncertainty propagation during conversion.
- Public identity enums for device/queue metadata groundwork.
- Unit coverage for clock mapping and provenance extensions.

### Changed
- Public event descriptors retain backward-compatible size/version extension semantics while carrying optional provenance fields.
- Documentation now defines multi-producer transport, correlation provenance, and timestamp semantics explicitly.

## [0.1.1] - Development

### Added
- Bounded fixed-capacity multi-producer event transport.
- Thread-safe session state and event counters.
- Generic sink API with explicit flush semantics.
- Deterministic buffer-full reporting and dropped-event accounting.
- Safe deferred event-name ownership with truncation reporting.
- Recorded/flushed/dropped count introspection.
- Concurrency and performance test targets.

### Changed
- Core event recording now persists semantic events instead of only validating them.
- Configuration supports an optional power-of-two transport capacity.
- The event descriptor carries explicit flags for transport/timestamp semantics.

### Fixed
- Session lifecycle state is now atomic for concurrent recorders.
