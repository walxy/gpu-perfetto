# gpu-perfetto

Tiny vendor-neutral GPU tracing interoperability layer for Perfetto.

## Status

**v0.3.0 development Perfetto-output milestone.** The current tree implements the core semantic transport, bounded event buffering, sink interface, explicit event-source/correlation metadata, affine clock conversion primitives, and concurrency/sanitizer test foundation. The tree now includes a dependency-free Perfetto-compatible JSON sink; the native Perfetto C++ SDK backend and vendor adapters remain separate milestones and are not claimed to be runtime-validated yet.

## Design goals

- stable, small C API
- zero third-party runtime dependencies in the core
- explicit timestamp/clock semantics
- host/submission/execution distinction
- device/queue/correlation identity
- graceful capability-based degradation
- Perfetto-compatible output rather than a competing trace ecosystem

## Non-goals

Not a profiler, debugger, GPU scheduler, tracing daemon, profiler UI, or replacement for CUPTI, ROCprofiler, Intel PTI/unitrace, Kineto, Tracy, Nsight, or Perfetto itself.

## Timestamp and correlation foundation

The v0.1.2/v0.2 development milestones add explicit event-source and correlation-domain provenance, counter-unit metadata, capability reporting, semantic invariants, and an affine clock-mapping utility. The mapping utility is intentionally a conversion primitive rather than an automatic calibration system: backends must collect valid calibration samples and supply an uncertainty bound.

The public `device_id` and `queue_id` fields are opaque numeric identifiers whose interpretation is supplied by the event source. They are not assumed to be globally unique across processes, machines, or backend domains. Future adapters should attach stable native/UUID identity metadata without rewriting native identifiers.

## Current limitations

The core persists semantic events in a bounded in-memory transport and can flush them to a generic sink. v0.3 adds a dependency-free Chrome Trace JSON output path that Perfetto can open directly. Native Perfetto protobuf/TrackEvent SDK emission, backend-specific GPU clock calibration, and vendor adapters remain separate milestones; no GPU backend is claimed runtime-validated in this tree.

## Build

```bash
cmake -S . -B build
cmake --build build
ctest --test-dir build --output-on-failure
```


## Perfetto-compatible JSON output

The optional `gpu-perfetto-perfetto-json` library emits Chrome Trace JSON, which the Perfetto UI and Trace Processor can open directly. This keeps the output layer dependency-free while providing a practical bridge before the native Perfetto protobuf SDK backend. Perfetto documents Chrome JSON as a supported external format, while recommending its native SDK for applications that need the full native trace model. citeturn131444search0turn269560view1

Build it with:

```bash
cmake -S . -B build -DGPU_PERFETTO_BUILD_PERFETTO_JSON=ON
cmake --build build
```

The JSON sink accepts only host-monotonic or explicitly calibrated timestamps. GPU-clock events must be converted by a backend first; otherwise the sink returns `GPU_TRACE_ERROR_UNSUPPORTED`.

The sink writes `pid`, `tid`, event/correlation IDs, device/queue IDs, provenance and counter-unit metadata into event arguments. Set `thread_id` explicitly when the producer knows the original thread identity.

## Architecture

```text
application / framework
        |
        v
 gpu-perfetto core
        |
        +---- semantic events
        +---- timestamps/clocks
        +---- correlation/IDs
        +---- capabilities
        |
        +---- optional native adapters
        |      CUDA/CUPTI
        |      HIP/ROCm
        |      Level Zero/SYCL
        |      Vulkan
        |      WebGPU
        |
        +---- optional Perfetto backend
```

## Important semantic rule

An annotation around a host API call is not automatically the duration of GPU execution. Actual GPU execution timing must come from backend-observed GPU activity or explicit device timestamps. The implementation must not insert device synchronization merely to make a trace appear complete.

## License

Apache-2.0.
