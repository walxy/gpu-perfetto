# Security

Please report security-sensitive defects privately to the project maintainer before public disclosure.

The tracing library should not open network connections, execute subprocesses, or perform unbounded allocation as part of normal tracing.
