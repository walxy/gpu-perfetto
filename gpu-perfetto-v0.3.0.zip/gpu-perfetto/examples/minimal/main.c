#include "gpu_perfetto/gpu_perfetto.h"
#include <stdio.h>
#include <string.h>

int main(void) {
    gpu_trace_config_t config;
    gpu_trace_session_t *session = NULL;
    gpu_trace_event_desc_t event;

    memset(&config, 0, sizeof(config));
    config.size = (uint32_t)sizeof(config);
    config.version = 1U;
    config.enabled = 1U;

    if (gpu_trace_create(&config, &session) != GPU_TRACE_OK ||
        gpu_trace_start(session) != GPU_TRACE_OK) {
        return 1;
    }

    memset(&event, 0, sizeof(event));
    event.size = (uint32_t)sizeof(event);
    event.version = 1U;
    event.type = GPU_TRACE_EVENT_INSTANT;
    event.name = "checkpoint";

    (void)gpu_trace_record(session, &event);
    (void)gpu_trace_stop(session);
    (void)gpu_trace_flush(session);
    (void)gpu_trace_destroy(session);

    puts("gpu-perfetto core example completed");
    return 0;
}
