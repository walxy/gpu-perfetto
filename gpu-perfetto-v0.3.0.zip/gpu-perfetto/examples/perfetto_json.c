#include "gpu_perfetto/gpu_perfetto.h"

#include <stdio.h>
#include <string.h>

int main(void) {
    gpu_trace_config_t config;
    gpu_trace_session_t *session = NULL;
    gpu_trace_perfetto_json_sink_t sink;
    gpu_trace_event_desc_t event;
    FILE *file;

    memset(&config, 0, sizeof(config));
    config.size = (uint32_t)sizeof(config);
    config.version = 1U;
    config.enabled = 1U;
    config.capacity = 1024U;

    file = fopen("gpu-perfetto.json", "wb");
    if (file == NULL ||
        gpu_trace_perfetto_json_sink_init(&sink, file) != GPU_TRACE_OK ||
        gpu_trace_create(&config, &session) != GPU_TRACE_OK) {
        return 1;
    }

    if (gpu_trace_set_sink(session,
            gpu_trace_perfetto_json_sink_get_sink(&sink)) != GPU_TRACE_OK ||
        gpu_trace_start(session) != GPU_TRACE_OK) {
        return 1;
    }

    memset(&event, 0, sizeof(event));
    event.size = (uint32_t)sizeof(event);
    event.version = 1U;
    event.type = GPU_TRACE_EVENT_EXECUTION;
    event.name = "example_gpu_work";
    event.thread_id = 1U;
    event.device_id = 0U;
    event.queue_id = 0U;
    event.begin.value = 1000000000U;
    event.begin.domain = GPU_TRACE_CLOCK_HOST_MONOTONIC;
    event.end.value = 1000500000U;
    event.end.domain = GPU_TRACE_CLOCK_HOST_MONOTONIC;

    if (gpu_trace_record(session, &event) != GPU_TRACE_OK ||
        gpu_trace_flush(session) != GPU_TRACE_OK ||
        gpu_trace_stop(session) != GPU_TRACE_OK ||
        gpu_trace_destroy(session) != GPU_TRACE_OK ||
        gpu_trace_perfetto_json_sink_finalize(&sink) != GPU_TRACE_OK) {
        return 1;
    }

    return fclose(file) == 0 ? 0 : 1;
}
