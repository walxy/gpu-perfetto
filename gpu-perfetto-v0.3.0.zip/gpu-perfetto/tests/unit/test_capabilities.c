#include "gpu_perfetto/gpu_perfetto.h"

#include <stdint.h>
#include <stdio.h>
#include <string.h>

#define CHECK(expr)                                                               \
    do {                                                                          \
        if (!(expr)) {                                                            \
            fprintf(stderr, "CHECK failed: %s (%s:%d)\n", #expr, __FILE__,      \
                    __LINE__);                                                   \
            return 1;                                                             \
        }                                                                         \
    } while (0)

int main(void) {
    gpu_trace_capabilities_t capabilities;
    gpu_trace_capability_mask_t all;
    gpu_trace_capabilities_t legacy;

    memset(&capabilities, 0, sizeof(capabilities));
    capabilities.size = (uint32_t)sizeof(capabilities);
    capabilities.version = 1U;
    capabilities.supported =
        GPU_TRACE_CAPABILITY_BIT(GPU_TRACE_CAP_HOST_EVENTS) |
        GPU_TRACE_CAPABILITY_BIT(GPU_TRACE_CAP_GPU_EXECUTION) |
        GPU_TRACE_CAPABILITY_BIT(GPU_TRACE_CAP_COUNTERS);
    capabilities.guaranteed =
        GPU_TRACE_CAPABILITY_BIT(GPU_TRACE_CAP_HOST_EVENTS);
    capabilities.unavailable =
        GPU_TRACE_CAPABILITY_BIT(GPU_TRACE_CAP_GRAPH_CAPTURE);

    CHECK(gpu_trace_capabilities_validate(&capabilities) == GPU_TRACE_OK);

    all = gpu_trace_capability_all();
    CHECK((all & capabilities.supported) == capabilities.supported);
    CHECK((all & capabilities.unavailable) == capabilities.unavailable);

    capabilities.guaranteed |= GPU_TRACE_CAPABILITY_BIT(GPU_TRACE_CAP_MEMORY);
    CHECK(gpu_trace_capabilities_validate(&capabilities) ==
          GPU_TRACE_ERROR_INVALID_ARGUMENT);

    capabilities.guaranteed &=
        ~GPU_TRACE_CAPABILITY_BIT(GPU_TRACE_CAP_MEMORY);
    capabilities.unavailable |= capabilities.supported;
    CHECK(gpu_trace_capabilities_validate(&capabilities) ==
          GPU_TRACE_ERROR_INVALID_ARGUMENT);

    capabilities.unavailable &= ~capabilities.supported;
    capabilities.supported |= (UINT64_C(1) << 63);
    CHECK(gpu_trace_capabilities_validate(&capabilities) ==
          GPU_TRACE_ERROR_INVALID_ARGUMENT);

    memset(&legacy, 0, sizeof(legacy));
    legacy.size = (uint32_t)offsetof(gpu_trace_capabilities_t, unavailable) +
                   (uint32_t)sizeof(legacy.unavailable);
    legacy.version = 1U;
    legacy.supported = GPU_TRACE_CAPABILITY_BIT(GPU_TRACE_CAP_HOST_EVENTS);
    CHECK(gpu_trace_capabilities_validate(&legacy) == GPU_TRACE_OK);

    capabilities.supported = 0U;
    capabilities.guaranteed = 0U;
    capabilities.unavailable = 0U;
    capabilities.version = 2U;
    CHECK(gpu_trace_capabilities_validate(&capabilities) ==
          GPU_TRACE_ERROR_INVALID_ARGUMENT);

    CHECK(gpu_trace_capabilities_validate(NULL) ==
          GPU_TRACE_ERROR_INVALID_ARGUMENT);
    return 0;
}
