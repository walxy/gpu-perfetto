#include "gpu_perfetto/gpu_perfetto.h"

#include <stdint.h>
#include <stdio.h>
#include <string.h>

#define CHECK(expr)                                                               \
    do {                                                                          \
        if (!(expr)) {                                                            \
            fprintf(stderr, "CHECK failed: %s (%s:%d)\n", #expr, __FILE__,    \
                    __LINE__);                                                   \
            return 1;                                                             \
        }                                                                         \
    } while (0)

int main(void) {
    gpu_trace_clock_mapping_t mapping;
    gpu_trace_timestamp_t source;
    gpu_trace_timestamp_t destination;

    memset(&mapping, 0, sizeof(mapping));
    mapping.size = (uint32_t)sizeof(mapping);
    mapping.version = 1U;
    mapping.source_domain = GPU_TRACE_CLOCK_GPU;
    mapping.destination_domain = GPU_TRACE_CLOCK_HOST_MONOTONIC;
    mapping.source_origin = 1000U;
    mapping.destination_origin = 5000U;
    mapping.numerator = 1U;
    mapping.denominator = 1U;
    mapping.uncertainty_ns = 25U;

    CHECK(gpu_trace_clock_mapping_validate(&mapping) == GPU_TRACE_OK);

    memset(&source, 0, sizeof(source));
    source.value = 1300U;
    source.domain = GPU_TRACE_CLOCK_GPU;
    source.resolution_ns = 10U;
    source.uncertainty_ns = 5U;

    CHECK(gpu_trace_clock_convert(&mapping, &source, &destination) == GPU_TRACE_OK);
    CHECK(destination.value == 5300U);
    CHECK(destination.domain == GPU_TRACE_CLOCK_HOST_MONOTONIC);
    CHECK(destination.resolution_ns == 10U);
    CHECK(destination.uncertainty_ns == 30U);

    mapping.numerator = 1000U;
    mapping.denominator = 1U;
    source.value = 1001U;
    CHECK(gpu_trace_clock_convert(&mapping, &source, &destination) == GPU_TRACE_OK);
    CHECK(destination.value == 6000U);

    source.domain = GPU_TRACE_CLOCK_HOST_MONOTONIC;
    CHECK(gpu_trace_clock_convert(&mapping, &source, &destination) ==
          GPU_TRACE_ERROR_INVALID_ARGUMENT);

    source.domain = GPU_TRACE_CLOCK_GPU;
    source.value = 999U;
    CHECK(gpu_trace_clock_convert(&mapping, &source, &destination) ==
          GPU_TRACE_ERROR_INVALID_ARGUMENT);

    mapping.numerator = 0U;
    CHECK(gpu_trace_clock_mapping_validate(&mapping) == GPU_TRACE_ERROR_INVALID_ARGUMENT);

    mapping.numerator = 1U;
    mapping.uncertainty_ns = UINT32_MAX;
    source.uncertainty_ns = 1U;
    source.value = 1001U;
    CHECK(gpu_trace_clock_convert(&mapping, &source, &destination) == GPU_TRACE_OK);
    CHECK(destination.uncertainty_ns == UINT32_MAX);

    /* Exercise the full 64-bit timestamp range without floating-point loss. */
    mapping.source_origin = 0U;
    mapping.destination_origin = 0U;
    mapping.uncertainty_ns = 0U;
    mapping.numerator = 1U;
    mapping.denominator = 1U;
    source.value = UINT64_MAX;
    source.uncertainty_ns = 0U;
    CHECK(gpu_trace_clock_convert(&mapping, &source, &destination) == GPU_TRACE_OK);
    CHECK(destination.value == UINT64_MAX);

    /* A ratio whose result fits must still remain exact at high timestamps. */
    mapping.numerator = 2U;
    mapping.denominator = 3U;
    source.value = UINT64_C(9000000000000000000);
    CHECK(gpu_trace_clock_convert(&mapping, &source, &destination) == GPU_TRACE_OK);
    CHECK(destination.value == UINT64_C(6000000000000000000));

    /* Destination-origin addition overflow is rejected. */
    mapping.numerator = 1U;
    mapping.denominator = 1U;
    mapping.destination_origin = UINT64_MAX;
    source.value = 1U;
    CHECK(gpu_trace_clock_convert(&mapping, &source, &destination) ==
          GPU_TRACE_ERROR_INTERNAL);
    return 0;
}
