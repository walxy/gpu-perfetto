#include "gpu_perfetto/perfetto_json.h"

#include <stdio.h>
#include <stdint.h>
#include <string.h>
#include <stdlib.h>

#define CHECK(expr)                                                           \
    do {                                                                      \
        if (!(expr)) {                                                        \
            fprintf(stderr, "CHECK failed: %s (%s:%d)\n", #expr, __FILE__,  \
                    __LINE__);                                               \
            return 1;                                                         \
        }                                                                     \
    } while (0)

static gpu_trace_event_desc_t make_event(gpu_trace_event_type_t type,
                                         uint64_t id,
                                         const char *name,
                                         uint64_t begin,
                                         uint64_t end) {
    gpu_trace_event_desc_t event;
    memset(&event, 0, sizeof(event));
    event.size = (uint32_t)sizeof(event);
    event.version = 1U;
    event.type = type;
    event.name = name;
    event.event_id = id;
    event.correlation_id = 42U;
    event.device_id = 7U;
    event.queue_id = 9U;
    event.thread_id = 11U;
    event.value = 1234U;
    event.source = GPU_TRACE_SOURCE_USER;
    event.correlation_domain = GPU_TRACE_CORRELATION_LOCAL;
    event.counter_unit = GPU_TRACE_COUNTER_UNIT_COUNT;
    event.begin.value = begin;
    event.begin.domain = GPU_TRACE_CLOCK_HOST_MONOTONIC;
    event.end.value = end;
    event.end.domain = GPU_TRACE_CLOCK_HOST_MONOTONIC;
    return event;
}

static int read_file(FILE *file, char **out_text) {
    long size;
    char *text;
    size_t read_count;
    CHECK(file != NULL);
    CHECK(out_text != NULL);
    CHECK(fseek(file, 0L, SEEK_END) == 0);
    size = ftell(file);
    CHECK(size >= 0L);
    CHECK(fseek(file, 0L, SEEK_SET) == 0);
    text = (char *)malloc((size_t)size + 1U);
    CHECK(text != NULL);
    read_count = fread(text, 1U, (size_t)size, file);
    CHECK(read_count == (size_t)size);
    text[size] = '\0';
    *out_text = text;
    return 0;
}

int main(int argc, char **argv) {
    FILE *file;
    gpu_trace_perfetto_json_sink_t sink;
    gpu_trace_session_t *session = NULL;
    gpu_trace_config_t config;
    gpu_trace_sink_t const *generic_sink;
    gpu_trace_event_desc_t event;
    char *text = NULL;

    CHECK(argc == 2);
    file = fopen(argv[1], "wb+");
    CHECK(file != NULL);

    memset(&config, 0, sizeof(config));
    config.size = (uint32_t)sizeof(config);
    config.version = 1U;
    config.enabled = 1U;
    config.capacity = 8U;

    CHECK(gpu_trace_perfetto_json_sink_init(&sink, file) == GPU_TRACE_OK);
    CHECK(gpu_trace_perfetto_json_sink_set_process_id(&sink, 77U) == GPU_TRACE_OK);
    generic_sink = gpu_trace_perfetto_json_sink_get_sink(&sink);
    CHECK(generic_sink != NULL);
    CHECK(gpu_trace_perfetto_json_sink_set_process_id(&sink, 0U) ==
          GPU_TRACE_ERROR_INVALID_ARGUMENT);

    {
        gpu_trace_event_desc_t bad_clock =
            make_event(GPU_TRACE_EVENT_EXECUTION, 99U, "gpu-clock", 1000U, 2000U);
        bad_clock.begin.domain = GPU_TRACE_CLOCK_GPU;
        bad_clock.end.domain = GPU_TRACE_CLOCK_GPU;
        CHECK(generic_sink->emit(generic_sink->user_data, &bad_clock) ==
              GPU_TRACE_ERROR_UNSUPPORTED);
        CHECK(gpu_trace_perfetto_json_sink_finalize(&sink) == GPU_TRACE_OK);
        CHECK(fseek(file, 0L, SEEK_SET) == 0);
        CHECK(read_file(file, &text) == 0);
        CHECK(strstr(text, "traceEvents") != NULL);
        CHECK(strstr(text, "gpu-clock") == NULL);
        free(text);
        text = NULL;
        CHECK(fclose(file) == 0);
        file = fopen(argv[1], "wb+");
        CHECK(file != NULL);
        CHECK(gpu_trace_perfetto_json_sink_init(&sink, file) == GPU_TRACE_OK);
        CHECK(gpu_trace_perfetto_json_sink_set_process_id(&sink, 77U) == GPU_TRACE_OK);
        generic_sink = gpu_trace_perfetto_json_sink_get_sink(&sink);
        CHECK(generic_sink != NULL);
    }
    CHECK(gpu_trace_create(&config, &session) == GPU_TRACE_OK);
    CHECK(gpu_trace_set_sink(session, generic_sink) == GPU_TRACE_OK);
    CHECK(gpu_trace_start(session) == GPU_TRACE_OK);

    event = make_event(GPU_TRACE_EVENT_SCOPE, 1U, "matmul\"quoted", 1000000U, 2250000U);
    CHECK(gpu_trace_record(session, &event) == GPU_TRACE_OK);

    event = make_event(GPU_TRACE_EVENT_INSTANT, 2U, "checkpoint", 3000000U, 3000000U);
    CHECK(gpu_trace_record(session, &event) == GPU_TRACE_OK);

    event = make_event(GPU_TRACE_EVENT_COUNTER, 3U, "jobs", 4000000U, 4000000U);
    CHECK(gpu_trace_record(session, &event) == GPU_TRACE_OK);

    CHECK(gpu_trace_flush(session) == GPU_TRACE_OK);
    CHECK(gpu_trace_perfetto_json_sink_set_process_id(&sink, 88U) ==
          GPU_TRACE_ERROR_ALREADY_STARTED);
    CHECK(gpu_trace_get_pending_count(session) == 0U);
    CHECK(gpu_trace_stop(session) == GPU_TRACE_OK);
    CHECK(gpu_trace_destroy(session) == GPU_TRACE_OK);
    CHECK(gpu_trace_perfetto_json_sink_finalize(&sink) == GPU_TRACE_OK);

    CHECK(read_file(file, &text) == 0);
    CHECK(strstr(text, "\"traceEvents\":[") != NULL);
    CHECK(strstr(text, "matmul\\\"quoted") != NULL);
    CHECK(strstr(text, "\"ph\":\"X\"") != NULL);
    CHECK(strstr(text, "\"ph\":\"i\"") != NULL);
    CHECK(strstr(text, "\"ph\":\"C\"") != NULL);
    CHECK(strstr(text, "\"pid\":77") != NULL);
    CHECK(strstr(text, "\"thread_id\":11") != NULL);
    CHECK(strstr(text, "\"event_type\":\"scope\"") != NULL);
    CHECK(strstr(text, "\"counter_unit\":1") != NULL);
    CHECK(strstr(text, "]}") != NULL);

    free(text);
    CHECK(fclose(file) == 0);
    return 0;
}
