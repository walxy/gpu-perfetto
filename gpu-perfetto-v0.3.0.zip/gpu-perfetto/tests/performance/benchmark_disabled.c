#include "gpu_perfetto/gpu_perfetto.h"

#include <stdint.h>
#include <stdio.h>
#include <string.h>
#include <time.h>

static uint64_t monotonic_ns(void) {
    struct timespec ts;
    (void)clock_gettime(CLOCK_MONOTONIC, &ts);
    return (uint64_t)ts.tv_sec * 1000000000ULL + (uint64_t)ts.tv_nsec;
}

int main(void) {
    gpu_trace_config_t config;
    gpu_trace_session_t *session = NULL;
    gpu_trace_event_desc_t event;
    const uint64_t iterations = 1000000ULL;
    uint64_t start;
    uint64_t end;
    uint64_t i;

    memset(&config, 0, sizeof(config));
    config.size = (uint32_t)sizeof(config);
    config.version = 1U;
    config.enabled = 0U;
    config.capacity = 1024U;
    if (gpu_trace_create(&config, &session) != GPU_TRACE_OK ||
        gpu_trace_start(session) != GPU_TRACE_OK) {
        return 1;
    }

    memset(&event, 0, sizeof(event));
    event.size = (uint32_t)sizeof(event);
    event.version = 1U;
    event.type = GPU_TRACE_EVENT_INSTANT;
    event.name = "disabled";

    start = monotonic_ns();
    for (i = 0U; i < iterations; ++i) {
        event.event_id = i;
        if (gpu_trace_record(session, &event) != GPU_TRACE_OK) {
            (void)gpu_trace_stop(session);
            (void)gpu_trace_destroy(session);
            return 2;
        }
    }
    end = monotonic_ns();

    printf("iterations=%llu elapsed_ns=%llu ns_per_call=%.2f recorded=%llu dropped=%llu\n",
           (unsigned long long)iterations,
           (unsigned long long)(end - start),
           (double)(end - start) / (double)iterations,
           (unsigned long long)gpu_trace_get_recorded_count(session),
           (unsigned long long)gpu_trace_get_dropped_count(session));

    (void)gpu_trace_stop(session);
    (void)gpu_trace_destroy(session);
    return 0;
}
