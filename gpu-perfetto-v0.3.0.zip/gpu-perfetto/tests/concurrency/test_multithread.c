#include "gpu_perfetto/gpu_perfetto.h"

#include <stdatomic.h>
#include <stdio.h>
#include <pthread.h>
#include <stdint.h>
#include <string.h>

#define PRODUCER_COUNT 8U
#define EVENTS_PER_PRODUCER 400U
#define TOTAL_EVENTS ((uint64_t)PRODUCER_COUNT * (uint64_t)EVENTS_PER_PRODUCER)

typedef struct producer_args {
    gpu_trace_session_t *session;
    uint32_t producer_id;
    _Atomic uint32_t *error;
} producer_args_t;

typedef struct sink_state {
    uint64_t count;
} sink_state_t;

static gpu_trace_status_t sink_emit(void *user_data,
                                    const gpu_trace_event_desc_t *event) {
    sink_state_t *state = (sink_state_t *)user_data;
    (void)event;
    state->count += 1U;
    return GPU_TRACE_OK;
}

static gpu_trace_event_desc_t event_for(uint32_t producer, uint32_t index) {
    static const char name[] = "kernel";
    gpu_trace_event_desc_t event;
    memset(&event, 0, sizeof(event));
    event.size = (uint32_t)sizeof(event);
    event.version = 1U;
    event.type = GPU_TRACE_EVENT_EXECUTION;
    event.name = name;
    event.event_id = ((uint64_t)producer << 32) | (uint64_t)index;
    event.correlation_id = event.event_id;
    event.device_id = producer % 2U;
    event.queue_id = producer;
    return event;
}

static void *producer_main(void *arg) {
    producer_args_t *args = (producer_args_t *)arg;
    uint32_t i;
    for (i = 0U; i < EVENTS_PER_PRODUCER; ++i) {
        gpu_trace_event_desc_t event = event_for(args->producer_id, i);
        gpu_trace_status_t status = gpu_trace_record(args->session, &event);
        if (status != GPU_TRACE_OK) {
            atomic_store_explicit(args->error, 1U, memory_order_relaxed);
            return NULL;
        }
    }
    return NULL;
}

int main(void) {
    gpu_trace_config_t config;
    gpu_trace_session_t *session = NULL;
    gpu_trace_sink_t sink;
    sink_state_t sink_state = {0U};
    pthread_t threads[PRODUCER_COUNT];
    producer_args_t args[PRODUCER_COUNT];
    _Atomic uint32_t error = 0U;
    uint32_t i;

    memset(&config, 0, sizeof(config));
    config.size = (uint32_t)sizeof(config);
    config.version = 1U;
    config.enabled = 1U;
    config.capacity = 8192U;

    memset(&sink, 0, sizeof(sink));
    sink.size = (uint32_t)sizeof(sink);
    sink.version = 1U;
    sink.emit = sink_emit;
    sink.user_data = &sink_state;

    if (gpu_trace_create(&config, &session) != GPU_TRACE_OK ||
        gpu_trace_set_sink(session, &sink) != GPU_TRACE_OK ||
        gpu_trace_start(session) != GPU_TRACE_OK) {
        fprintf(stderr, "session setup failed\n");
        return 1;
    }

    for (i = 0U; i < PRODUCER_COUNT; ++i) {
        args[i].session = session;
        args[i].producer_id = i;
        args[i].error = &error;
        if (pthread_create(&threads[i], NULL, producer_main, &args[i]) != 0) {
            fprintf(stderr, "pthread_create failed\n");
            return 1;
        }
    }
    for (i = 0U; i < PRODUCER_COUNT; ++i) {
        if (pthread_join(threads[i], NULL) != 0) {
            fprintf(stderr, "pthread_join failed\n");
            return 1;
        }
    }

    if (atomic_load_explicit(&error, memory_order_relaxed) != 0U) {
        fprintf(stderr, "producer reported record failure\n");
        return 1;
    }
    if (gpu_trace_get_recorded_count(session) != TOTAL_EVENTS ||
        gpu_trace_get_dropped_count(session) != 0U ||
        gpu_trace_flush(session) != GPU_TRACE_OK ||
        gpu_trace_get_flushed_count(session) != TOTAL_EVENTS ||
        sink_state.count != TOTAL_EVENTS ||
        gpu_trace_stop(session) != GPU_TRACE_OK ||
        gpu_trace_destroy(session) != GPU_TRACE_OK) {
        fprintf(stderr, "concurrency test failed\n");
        return 1;
    }
    return 0;
}
