# Installation

## From source

```bash
cmake -S . -B build -DGPU_PERFETTO_BUILD_TESTS=ON
cmake --build build
ctest --test-dir build --output-on-failure
```

The core currently has no third-party runtime dependency.

Vendor SDKs are intentionally optional and are not bundled.
