#include "gpu_perfetto/trace.h"

#include "src/internal/event.h"
#include "src/internal/session.h"

#include <stdatomic.h>
#include <stdlib.h>
#include <string.h>

static int power_of_two(uint32_t value) {
    return value >= GPU_TRACE_MIN_CAPACITY && (value & (value - 1U)) == 0U;
}

static int config_valid(const gpu_trace_config_t *config) {
    return config != NULL &&
           config->size >= (uint32_t)offsetof(gpu_trace_config_t, capacity) &&
           config->version == 1U;
}

static uint32_t requested_capacity(const gpu_trace_config_t *config) {
    const uint32_t capacity_offset = (uint32_t)offsetof(gpu_trace_config_t, capacity);
    const uint32_t capacity_size = (uint32_t)sizeof(config->capacity);
    if (config->size < capacity_offset + capacity_size) {
        return 0U;
    }
    return config->capacity;
}

static int event_type_valid(gpu_trace_event_type_t type) {
    switch (type) {
        case GPU_TRACE_EVENT_SCOPE:
        case GPU_TRACE_EVENT_INSTANT:
        case GPU_TRACE_EVENT_COUNTER:
        case GPU_TRACE_EVENT_SUBMISSION:
        case GPU_TRACE_EVENT_EXECUTION:
        case GPU_TRACE_EVENT_MEMORY:
        case GPU_TRACE_EVENT_SYNC:
        case GPU_TRACE_EVENT_METADATA:
            return 1;
        default:
            return 0;
    }
}

static int clock_domain_valid(gpu_trace_clock_domain_t domain) {
    switch (domain) {
        case GPU_TRACE_CLOCK_HOST_MONOTONIC:
        case GPU_TRACE_CLOCK_GPU:
        case GPU_TRACE_CLOCK_CALIBRATED:
        case GPU_TRACE_CLOCK_UNKNOWN:
            return 1;
        default:
            return 0;
    }
}

static int event_source_valid(gpu_trace_event_source_t source) {
    switch (source) {
        case GPU_TRACE_SOURCE_USER:
        case GPU_TRACE_SOURCE_CUDA:
        case GPU_TRACE_SOURCE_CUPTI:
        case GPU_TRACE_SOURCE_HIP:
        case GPU_TRACE_SOURCE_ROCPROFILER:
        case GPU_TRACE_SOURCE_LEVEL_ZERO:
        case GPU_TRACE_SOURCE_SYCL:
        case GPU_TRACE_SOURCE_VULKAN:
        case GPU_TRACE_SOURCE_WEBGPU:
        case GPU_TRACE_SOURCE_SYNTHETIC:
            return 1;
        default:
            return 0;
    }
}

static int correlation_domain_valid(gpu_trace_correlation_domain_t domain) {
    switch (domain) {
        case GPU_TRACE_CORRELATION_NONE:
        case GPU_TRACE_CORRELATION_LOCAL:
        case GPU_TRACE_CORRELATION_CUDA:
        case GPU_TRACE_CORRELATION_ROCM:
        case GPU_TRACE_CORRELATION_LEVEL_ZERO:
        case GPU_TRACE_CORRELATION_VULKAN:
        case GPU_TRACE_CORRELATION_WEBGPU:
        case GPU_TRACE_CORRELATION_USER:
            return 1;
        default:
            return 0;
    }
}

static int counter_unit_valid(gpu_trace_counter_unit_t unit) {
    switch (unit) {
        case GPU_TRACE_COUNTER_UNIT_UNKNOWN:
        case GPU_TRACE_COUNTER_UNIT_COUNT:
        case GPU_TRACE_COUNTER_UNIT_BYTES:
        case GPU_TRACE_COUNTER_UNIT_NANOSECONDS:
        case GPU_TRACE_COUNTER_UNIT_HERTZ:
        case GPU_TRACE_COUNTER_UNIT_PERCENT:
            return 1;
        default:
            return 0;
    }
}

static int event_valid(const gpu_trace_event_desc_t *event) {
    const uint32_t required_size = (uint32_t)offsetof(gpu_trace_event_desc_t, flags);
    return event != NULL && event->size >= required_size &&
           event->version == 1U && event_type_valid(event->type);
}

static uint32_t normalized_capacity(uint32_t capacity) {
    return capacity == 0U ? GPU_TRACE_DEFAULT_CAPACITY : capacity;
}

static gpu_trace_status_t internal_event_from_desc(
    const gpu_trace_event_desc_t *event,
    gpu_trace_internal_event_t *internal) {
    size_t length;
    uint32_t copy_length;

    if (!event_valid(event) || internal == NULL) {
        return GPU_TRACE_ERROR_INVALID_ARGUMENT;
    }

    memset(internal, 0, sizeof(*internal));
    if (!clock_domain_valid(event->begin.domain) ||
        !clock_domain_valid(event->end.domain)) {
        return GPU_TRACE_ERROR_INVALID_ARGUMENT;
    }
    internal->event_id = event->event_id;
    internal->correlation_id = event->correlation_id;
    internal->device_id = event->device_id;
    internal->queue_id = event->queue_id;
    internal->begin = event->begin.value;
    internal->end = event->end.value;
    internal->value = event->value;
    internal->flags = 0U;
    if (event->size >= (uint32_t)offsetof(gpu_trace_event_desc_t, flags) +
                           (uint32_t)sizeof(event->flags)) {
        internal->flags = event->flags;
    }

    internal->source = (uint8_t)GPU_TRACE_SOURCE_USER;
    internal->correlation_domain = (uint8_t)GPU_TRACE_CORRELATION_NONE;

    {
        const uint32_t source_offset =
            (uint32_t)offsetof(gpu_trace_event_desc_t, source);
        const uint32_t source_end =
            source_offset + (uint32_t)sizeof(event->source);
        const uint32_t correlation_offset =
            (uint32_t)offsetof(gpu_trace_event_desc_t, correlation_domain);
        const uint32_t correlation_end =
            correlation_offset + (uint32_t)sizeof(event->correlation_domain);
        if (event->size >= source_end) {
            if (!event_source_valid(event->source)) {
                return GPU_TRACE_ERROR_INVALID_ARGUMENT;
            }
            internal->source = (uint8_t)event->source;
        }
        if (event->size >= correlation_end) {
            if (!correlation_domain_valid(event->correlation_domain)) {
                return GPU_TRACE_ERROR_INVALID_ARGUMENT;
            }
            internal->correlation_domain =
                (uint8_t)event->correlation_domain;
        }
        {
            const uint32_t counter_unit_offset =
                (uint32_t)offsetof(gpu_trace_event_desc_t, counter_unit);
            const uint32_t counter_unit_end =
                counter_unit_offset + (uint32_t)sizeof(event->counter_unit);
            if (event->size >= counter_unit_end) {
                if (!counter_unit_valid(event->counter_unit)) {
                    return GPU_TRACE_ERROR_INVALID_ARGUMENT;
                }
                internal->counter_unit = (uint8_t)event->counter_unit;
            }
        }
    }
    internal->type = (uint8_t)event->type;
    internal->begin_domain = (uint8_t)event->begin.domain;
    internal->end_domain = (uint8_t)event->end.domain;
    internal->begin_resolution_ns = event->begin.resolution_ns;
    internal->end_resolution_ns = event->end.resolution_ns;
    internal->begin_uncertainty_ns = event->begin.uncertainty_ns;
    internal->end_uncertainty_ns = event->end.uncertainty_ns;

    if (event->name == NULL) {
        internal->name[0] = '\0';
        return GPU_TRACE_OK;
    }

    length = strlen(event->name);
    copy_length = (uint32_t)length;
    if (copy_length > GPU_TRACE_MAX_NAME_LENGTH) {
        copy_length = GPU_TRACE_MAX_NAME_LENGTH;
        internal->flags |= GPU_TRACE_FLAG_TRUNCATED_NAME;
    }
    if (copy_length != 0U) {
        memcpy(internal->name, event->name, (size_t)copy_length);
    }
    internal->name[copy_length] = '\0';
    internal->name_length = copy_length;
    return GPU_TRACE_OK;
}

static void event_desc_from_internal(const gpu_trace_internal_event_t *internal,
                                     gpu_trace_event_desc_t *event) {
    memset(event, 0, sizeof(*event));
    event->size = (uint32_t)sizeof(*event);
    event->version = 1U;
    event->type = (gpu_trace_event_type_t)internal->type;
    event->name = internal->name;
    event->event_id = internal->event_id;
    event->correlation_id = internal->correlation_id;
    event->device_id = internal->device_id;
    event->queue_id = internal->queue_id;
    event->value = internal->value;
    event->begin.value = internal->begin;
    event->begin.domain = (gpu_trace_clock_domain_t)internal->begin_domain;
    event->begin.resolution_ns = internal->begin_resolution_ns;
    event->begin.uncertainty_ns = internal->begin_uncertainty_ns;
    event->end.value = internal->end;
    event->end.domain = (gpu_trace_clock_domain_t)internal->end_domain;
    event->end.resolution_ns = internal->end_resolution_ns;
    event->end.uncertainty_ns = internal->end_uncertainty_ns;
    event->flags = internal->flags;
    event->source = (gpu_trace_event_source_t)internal->source;
    event->correlation_domain =
        (gpu_trace_correlation_domain_t)internal->correlation_domain;
    event->counter_unit = (gpu_trace_counter_unit_t)internal->counter_unit;
}

gpu_trace_status_t gpu_trace_create(const gpu_trace_config_t *config,
                                    gpu_trace_session_t **out_session) {
    gpu_trace_session_t *session;
    uint32_t capacity;

    if (!config_valid(config) || out_session == NULL) {
        return GPU_TRACE_ERROR_INVALID_ARGUMENT;
    }
    *out_session = NULL;

    capacity = normalized_capacity(requested_capacity(config));
    if (!power_of_two(capacity)) {
        return GPU_TRACE_ERROR_INVALID_ARGUMENT;
    }

    session = (gpu_trace_session_t *)calloc(1U, sizeof(*session));
    if (session == NULL) {
        return GPU_TRACE_ERROR_NO_MEMORY;
    }

    memset(&session->config, 0, sizeof(session->config));
    {
        size_t copy_size = (size_t)config->size;
        if (copy_size > sizeof(session->config)) {
            copy_size = sizeof(session->config);
        }
        memcpy(&session->config, config, copy_size);
    }
    session->config.capacity = capacity;
    atomic_init(&session->state, (uint32_t)GPU_TRACE_STATE_CREATED);
    atomic_init(&session->recorded_count, 0U);
    atomic_init(&session->flushed_count, 0U);
    atomic_init(&session->dropped_count, 0U);

    if (!gpu_trace_ring_init(&session->ring, capacity)) {
        free(session);
        return GPU_TRACE_ERROR_NO_MEMORY;
    }

    *out_session = session;
    return GPU_TRACE_OK;
}

gpu_trace_status_t gpu_trace_set_sink(gpu_trace_session_t *session,
                                       const gpu_trace_sink_t *sink) {
    uint32_t state;

    if (session == NULL || sink == NULL ||
        sink->size < (uint32_t)sizeof(gpu_trace_sink_t) ||
        sink->version != 1U || sink->emit == NULL) {
        return GPU_TRACE_ERROR_INVALID_ARGUMENT;
    }

    state = atomic_load_explicit(&session->state, memory_order_acquire);
    if (state != (uint32_t)GPU_TRACE_STATE_CREATED) {
        return GPU_TRACE_ERROR_ALREADY_STARTED;
    }

    session->sink = *sink;
    session->has_sink = 1U;
    return GPU_TRACE_OK;
}

gpu_trace_status_t gpu_trace_start(gpu_trace_session_t *session) {
    uint32_t expected;
    if (session == NULL) {
        return GPU_TRACE_ERROR_INVALID_ARGUMENT;
    }
    expected = (uint32_t)GPU_TRACE_STATE_CREATED;
    if (!atomic_compare_exchange_strong_explicit(
            &session->state, &expected, (uint32_t)GPU_TRACE_STATE_RUNNING,
            memory_order_acq_rel, memory_order_acquire)) {
        return GPU_TRACE_ERROR_ALREADY_STARTED;
    }
    return GPU_TRACE_OK;
}

gpu_trace_status_t gpu_trace_stop(gpu_trace_session_t *session) {
    uint32_t expected;
    if (session == NULL) {
        return GPU_TRACE_ERROR_INVALID_ARGUMENT;
    }
    expected = (uint32_t)GPU_TRACE_STATE_RUNNING;
    if (!atomic_compare_exchange_strong_explicit(
            &session->state, &expected, (uint32_t)GPU_TRACE_STATE_STOPPED,
            memory_order_acq_rel, memory_order_acquire)) {
        return expected == (uint32_t)GPU_TRACE_STATE_CREATED
                   ? GPU_TRACE_ERROR_NOT_INITIALIZED
                   : GPU_TRACE_ERROR_ALREADY_STARTED;
    }
    return GPU_TRACE_OK;
}

gpu_trace_status_t gpu_trace_flush(gpu_trace_session_t *session) {
    gpu_trace_internal_event_t internal;
    gpu_trace_event_desc_t event;
    gpu_trace_status_t status;
    if (session == NULL) {
        return GPU_TRACE_ERROR_INVALID_ARGUMENT;
    }
    if (!session->has_sink) {
        return GPU_TRACE_ERROR_NOT_INITIALIZED;
    }

    while (gpu_trace_ring_try_peek(&session->ring, &internal)) {
        event_desc_from_internal(&internal, &event);
        status = session->sink.emit(session->sink.user_data, &event);
        if (status != GPU_TRACE_OK) {
            return status;
        }
        gpu_trace_ring_consume(&session->ring);
        atomic_fetch_add_explicit(&session->flushed_count, 1U,
                                  memory_order_relaxed);
    }
    return GPU_TRACE_OK;
}

gpu_trace_status_t gpu_trace_record(gpu_trace_session_t *session,
                                    const gpu_trace_event_desc_t *event) {
    gpu_trace_internal_event_t internal;
    uint32_t state;
    gpu_trace_status_t status;

    if (session == NULL || !event_valid(event)) {
        return GPU_TRACE_ERROR_INVALID_ARGUMENT;
    }

    state = atomic_load_explicit(&session->state, memory_order_acquire);
    if (state != (uint32_t)GPU_TRACE_STATE_RUNNING) {
        return GPU_TRACE_ERROR_NOT_INITIALIZED;
    }
    if (session->config.enabled == 0U) {
        return GPU_TRACE_OK;
    }

    status = internal_event_from_desc(event, &internal);
    if (status != GPU_TRACE_OK) {
        return status;
    }

    if (!gpu_trace_ring_try_push(&session->ring, &internal)) {
        atomic_fetch_add_explicit(&session->dropped_count, 1U,
                                  memory_order_relaxed);
        return GPU_TRACE_ERROR_BUFFER_FULL;
    }

    atomic_fetch_add_explicit(&session->recorded_count, 1U,
                              memory_order_relaxed);
    return GPU_TRACE_OK;
}

gpu_trace_status_t gpu_trace_destroy(gpu_trace_session_t *session) {
    uint64_t recorded;
    uint64_t flushed;

    if (session == NULL) {
        return GPU_TRACE_ERROR_INVALID_ARGUMENT;
    }
    if (atomic_load_explicit(&session->state, memory_order_acquire) ==
        (uint32_t)GPU_TRACE_STATE_RUNNING) {
        return GPU_TRACE_ERROR_ALREADY_STARTED;
    }

    recorded = atomic_load_explicit(&session->recorded_count, memory_order_acquire);
    flushed = atomic_load_explicit(&session->flushed_count, memory_order_acquire);
    if (recorded != flushed) {
        return GPU_TRACE_ERROR_PENDING_EVENTS;
    }

    gpu_trace_ring_destroy(&session->ring);
    free(session);
    return GPU_TRACE_OK;
}

uint64_t gpu_trace_get_recorded_count(const gpu_trace_session_t *session) {
    return session == NULL
               ? 0U
               : atomic_load_explicit(&session->recorded_count,
                                      memory_order_relaxed);
}

uint64_t gpu_trace_get_flushed_count(const gpu_trace_session_t *session) {
    return session == NULL
               ? 0U
               : atomic_load_explicit(&session->flushed_count,
                                      memory_order_relaxed);
}

uint64_t gpu_trace_get_dropped_count(const gpu_trace_session_t *session) {
    return session == NULL
               ? 0U
               : atomic_load_explicit(&session->dropped_count,
                                      memory_order_relaxed);
}

uint64_t gpu_trace_get_pending_count(const gpu_trace_session_t *session) {
    uint64_t recorded;
    uint64_t flushed;
    if (session == NULL) {
        return 0U;
    }
    recorded = atomic_load_explicit(&session->recorded_count, memory_order_relaxed);
    flushed = atomic_load_explicit(&session->flushed_count, memory_order_relaxed);
    return recorded >= flushed ? recorded - flushed : 0U;
}

uint32_t gpu_trace_get_capacity(const gpu_trace_session_t *session) {
    return session == NULL ? 0U : gpu_trace_ring_capacity(&session->ring);
}
