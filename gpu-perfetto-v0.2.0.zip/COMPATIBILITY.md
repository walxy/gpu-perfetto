# Compatibility

This document distinguishes **build support** from **runtime validation**.

| Component | Status |
|---|---|
| ISO C11 core | Development target |
| C++ wrapper | Planned |
| Perfetto backend | Optional / not yet implemented in baseline |
| CUDA/CUPTI | Adapter planned |
| HIP/ROCm | Adapter planned |
| Level Zero | Adapter planned |
| SYCL | Adapter planned |
| Vulkan | Adapter planned |
| WebGPU | Adapter planned |
| Linux | CI target |
| Windows | CI target |
| macOS | CI target |

No entry marked "planned" should be interpreted as runtime support.


## v0.2.0 development foundation

- C11 core API.
- C++17 public-header inclusion smoke-tested.
- Public structures use `size`/`version` extension semantics where explicitly documented.
- Event-source and correlation-domain fields are optional trailing extensions; callers using the v0.1.1 descriptor prefix remain valid.
- Clock mapping is a host-side utility and has no backend-specific timing guarantees.
- Real GPU/backend validation is not claimed until the corresponding adapters are implemented and tested on hardware.
