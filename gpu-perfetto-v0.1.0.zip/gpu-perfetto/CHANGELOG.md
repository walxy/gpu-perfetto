# Changelog

## [0.1.0] - 2026-09-02

### Added
- Initial zero-dependency C11 core baseline.
- Versioned public descriptors.
- Explicit timestamp clock-domain type.
- Event taxonomy for scopes, instants, counters, submissions, execution, memory, synchronization and metadata.
- Session lifecycle API.
- Initial unit test and minimal example.
- CMake install/export scaffolding.

### Not yet implemented
- Perfetto sink.
- CUDA/CUPTI adapter.
- HIP/ROCm adapter.
- Level Zero/SYCL adapter.
- Vulkan adapter.
- WebGPU adapter.
- buffering, correlation storage, clock calibration and hardware validation.
