#include "gpu_perfetto/trace.h"

#include <stdlib.h>

struct gpu_trace_session {
    gpu_trace_config_t config;
    uint32_t started;
};

static int config_valid(const gpu_trace_config_t *config) {
    return config != NULL && config->size >= (uint32_t)sizeof(gpu_trace_config_t) && config->version == 1U;
}

static int event_valid(const gpu_trace_event_desc_t *event) {
    return event != NULL && event->size >= (uint32_t)sizeof(gpu_trace_event_desc_t) &&
           event->version == 1U && event->type >= GPU_TRACE_EVENT_SCOPE &&
           event->type <= GPU_TRACE_EVENT_METADATA;
}

gpu_trace_status_t gpu_trace_create(const gpu_trace_config_t *config,
                                    gpu_trace_session_t **out_session) {
    gpu_trace_session_t *session;
    if (!config_valid(config) || out_session == NULL) {
        return GPU_TRACE_ERROR_INVALID_ARGUMENT;
    }
    *out_session = NULL;
    session = (gpu_trace_session_t *)calloc(1U, sizeof(*session));
    if (session == NULL) {
        return GPU_TRACE_ERROR_NO_MEMORY;
    }
    session->config = *config;
    *out_session = session;
    return GPU_TRACE_OK;
}

gpu_trace_status_t gpu_trace_start(gpu_trace_session_t *session) {
    if (session == NULL) return GPU_TRACE_ERROR_INVALID_ARGUMENT;
    if (session->started != 0U) return GPU_TRACE_ERROR_ALREADY_STARTED;
    session->started = 1U;
    return GPU_TRACE_OK;
}

gpu_trace_status_t gpu_trace_stop(gpu_trace_session_t *session) {
    if (session == NULL) return GPU_TRACE_ERROR_INVALID_ARGUMENT;
    if (session->started == 0U) return GPU_TRACE_ERROR_NOT_INITIALIZED;
    session->started = 0U;
    return GPU_TRACE_OK;
}

gpu_trace_status_t gpu_trace_flush(gpu_trace_session_t *session) {
    if (session == NULL) return GPU_TRACE_ERROR_INVALID_ARGUMENT;
    return GPU_TRACE_OK;
}

gpu_trace_status_t gpu_trace_record(const gpu_trace_session_t *session,
                                    const gpu_trace_event_desc_t *event) {
    if (session == NULL || !event_valid(event)) return GPU_TRACE_ERROR_INVALID_ARGUMENT;
    if (session->started == 0U) return GPU_TRACE_ERROR_NOT_INITIALIZED;
    if (session->config.enabled == 0U) return GPU_TRACE_OK;
    /* v0.1 core validates and accepts the semantic event only. The Perfetto
     * sink is deliberately separated from the core and is not a dependency. */
    return GPU_TRACE_OK;
}

gpu_trace_status_t gpu_trace_destroy(gpu_trace_session_t *session) {
    if (session == NULL) return GPU_TRACE_ERROR_INVALID_ARGUMENT;
    free(session);
    return GPU_TRACE_OK;
}
