#include "gpu_perfetto/gpu_perfetto.h"
#include <assert.h>
#include <string.h>

int main(void) {
    gpu_trace_config_t config;
    gpu_trace_session_t *session = NULL;
    gpu_trace_event_desc_t event;

    memset(&config, 0, sizeof(config));
    config.size = (uint32_t)sizeof(config);
    config.version = 1U;
    config.enabled = 1U;

    assert(gpu_trace_create(&config, &session) == GPU_TRACE_OK);
    assert(session != NULL);
    assert(gpu_trace_start(session) == GPU_TRACE_OK);
    assert(gpu_trace_start(session) == GPU_TRACE_ERROR_ALREADY_STARTED);

    memset(&event, 0, sizeof(event));
    event.size = (uint32_t)sizeof(event);
    event.version = 1U;
    event.type = GPU_TRACE_EVENT_SUBMISSION;
    event.name = "matmul";
    event.event_id = 1U;
    event.correlation_id = 10U;
    event.device_id = 20U;
    event.queue_id = 30U;

    assert(gpu_trace_record(session, &event) == GPU_TRACE_OK);
    assert(strcmp(gpu_trace_status_string(GPU_TRACE_OK), "ok") == 0);
    assert(gpu_trace_stop(session) == GPU_TRACE_OK);
    assert(gpu_trace_record(session, &event) == GPU_TRACE_ERROR_NOT_INITIALIZED);
    assert(gpu_trace_destroy(session) == GPU_TRACE_OK);
    return 0;
}
