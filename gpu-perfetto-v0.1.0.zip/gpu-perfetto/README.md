# gpu-perfetto

Tiny vendor-neutral GPU tracing interoperability layer for Perfetto.

## Status

**v0.1.0 development baseline.** The current tree defines the core semantic API and build/test structure. Vendor adapters and the Perfetto sink are intentionally optional and are not claimed to be runtime-validated yet.

## Design goals

- stable, small C API
- zero third-party runtime dependencies in the core
- explicit timestamp/clock semantics
- host/submission/execution distinction
- device/queue/correlation identity
- graceful capability-based degradation
- Perfetto-native output rather than a competing trace ecosystem

## Non-goals

Not a profiler, debugger, GPU scheduler, tracing daemon, profiler UI, or replacement for CUPTI, ROCprofiler, Intel PTI/unitrace, Kineto, Tracy, Nsight, or Perfetto itself.

## Current limitations

The v0.1 baseline validates event descriptors but does not yet persist events, emit Perfetto packets, calibrate GPU clocks, or implement vendor adapters. Those are deliberately separate milestones.

## Build

```bash
cmake -S . -B build
cmake --build build
ctest --test-dir build --output-on-failure
```

## Architecture

```text
application / framework
        |
        v
 gpu-perfetto core
        |
        +---- semantic events
        +---- timestamps/clocks
        +---- correlation/IDs
        +---- capabilities
        |
        +---- optional native adapters
        |      CUDA/CUPTI
        |      HIP/ROCm
        |      Level Zero/SYCL
        |      Vulkan
        |      WebGPU
        |
        +---- optional Perfetto backend
```

## Important semantic rule

An annotation around a host API call is not automatically the duration of GPU execution. Actual GPU execution timing must come from backend-observed GPU activity or explicit device timestamps. The implementation must not insert device synchronization merely to make a trace appear complete.

## License

Apache-2.0.
