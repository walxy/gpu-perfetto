#ifndef GPU_PERFETTO_TRACE_H
#define GPU_PERFETTO_TRACE_H

#include <stddef.h>
#include <stdint.h>
#include "gpu_perfetto/status.h"
#include "gpu_perfetto/timestamp.h"

#ifdef __cplusplus
extern "C" {
#endif

typedef struct gpu_trace_session gpu_trace_session_t;

typedef enum gpu_trace_event_type {
    GPU_TRACE_EVENT_SCOPE = 0,
    GPU_TRACE_EVENT_INSTANT = 1,
    GPU_TRACE_EVENT_COUNTER = 2,
    GPU_TRACE_EVENT_SUBMISSION = 3,
    GPU_TRACE_EVENT_EXECUTION = 4,
    GPU_TRACE_EVENT_MEMORY = 5,
    GPU_TRACE_EVENT_SYNC = 6,
    GPU_TRACE_EVENT_METADATA = 7
} gpu_trace_event_type_t;

typedef struct gpu_trace_config {
    uint32_t size;
    uint32_t version;
    uint32_t enabled;
    uint32_t reserved0;
} gpu_trace_config_t;

typedef struct gpu_trace_event_desc {
    uint32_t size;
    uint32_t version;
    gpu_trace_event_type_t type;
    const char *name;
    uint64_t event_id;
    uint64_t correlation_id;
    uint64_t device_id;
    uint64_t queue_id;
    uint64_t value;
    gpu_trace_timestamp_t begin;
    gpu_trace_timestamp_t end;
} gpu_trace_event_desc_t;

gpu_trace_status_t gpu_trace_create(const gpu_trace_config_t *config,
                                    gpu_trace_session_t **out_session);

gpu_trace_status_t gpu_trace_start(gpu_trace_session_t *session);
gpu_trace_status_t gpu_trace_stop(gpu_trace_session_t *session);
gpu_trace_status_t gpu_trace_flush(gpu_trace_session_t *session);

gpu_trace_status_t gpu_trace_record(const gpu_trace_session_t *session,
                                    const gpu_trace_event_desc_t *event);

gpu_trace_status_t gpu_trace_destroy(gpu_trace_session_t *session);

#ifdef __cplusplus
}
#endif

#endif
